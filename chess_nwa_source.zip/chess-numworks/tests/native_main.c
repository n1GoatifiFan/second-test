/* native_main.c - native (PC) harness for the chess core and the engine.
 *
 * Commands:
 *   perft [depth]        run the standard perft suite (or one depth)
 *   divide <depth> [fen] perft divide from a FEN (default: start position)
 *   selftest             rule edge cases (castling, e.p., promotion, draws)
 *   bench                fixed-depth node/time measurement (NPS)
 *   match <n> [ms]       engine vs engine self-play at a given time per move
 *   play                 tiny ASCII interface for manual testing
 *   bestmove [fen] [ms]  think and print the best move in SAN
 *
 * MIT licensed.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "chess/chess.h"
#include "chess/search.h"
#include "chess/eval.h"

/* --------------------------------------------------------------- perft    */
typedef struct {
  const char *name;
  const char *fen;
  uint64_t expect[7]; /* expect[d] for depth d=1..6, 0 = unknown */
  int maxDepth;
} PerftCase;

static const PerftCase perftCases[] = {
    {"startpos", "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
     {20, 400, 8902, 197281, 4865609, 119060324}, 6},
    {"kiwipete", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
     {48, 2039, 97862, 4085603, 193690690, 8031647685ull}, 5},
    {"pos3", "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
     {14, 191, 2812, 43238, 674624, 11030083}, 6},
    {"pos4", "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
     {6, 264, 9467, 422333, 15833292, 706045033}, 5},
    {"pos4-mirror", "r2q1rk1/pP1p2pp/Q4n2/bbp1p3/Np6/1B3NBn/pPPP1PPP/R3K2R b KQ - 0 1",
     {6, 264, 9467, 422333, 15833292, 706045033}, 5},
    {"pos5", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
     {44, 1486, 62379, 2103487, 89941194}, 5},
    {"pos6", "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
     {46, 2079, 89890, 3894594, 164075551}, 5},
};

static void run_perft_suite(int forcedDepth) {
  int pass = 0, fail = 0;
  printf("%-12s %3s %14s %14s %8s %8s\n", "case", "d", "nodes", "expected", "time", "result");
  for (unsigned i = 0; i < sizeof(perftCases) / sizeof(perftCases[0]); i++) {
    const PerftCase *c = &perftCases[i];
    int maxd = forcedDepth ? forcedDepth : c->maxDepth;
    if (maxd > 6) maxd = 6;
    Position p;
    if (!position_from_fen(&p, c->fen)) {
      printf("%s: bad FEN\n", c->name);
      fail++;
      continue;
    }
    for (int d = 1; d <= maxd; d++) {
      uint32_t t0 = search_platform_millis();
      Position q = p;
      uint64_t n = perft(&q, d);
      uint32_t dt = search_platform_millis() - t0;
      uint64_t exp = d <= 6 ? c->expect[d - 1] : 0;
      bool ok = (exp == 0) || (n == exp);
      printf("%-12s %3d %14llu %14llu %7ums %8s\n", c->name, d,
             (unsigned long long)n, (unsigned long long)exp, dt, ok ? "OK" : "MISMATCH");
      if (!ok) {
        fail++;
        break; /* deeper counts are meaningless if this one is wrong */
      }
      pass++;
    }
  }
  printf("\nperft: %d depths OK, %d failures\n", pass, fail);
}

static void divide(const char *fen, int depth) {
  Position p;
  chess_init();
  if (fen) {
    if (!position_from_fen(&p, fen)) {
      printf("bad fen\n");
      return;
    }
  } else {
    position_set_startpos(&p);
  }
  MoveList l;
  generate_legal(&p, &l);
  uint64_t total = 0;
  for (int i = 0; i < l.n; i++) {
    char san[16];
    Position q = p;
    move_to_san(&q, l.m[i], san, sizeof(san));
    Undo u;
    make_move(&p, l.m[i], &u);
    uint64_t n = perft(&p, depth - 1);
    unmake_move(&p, l.m[i], &u);
    total += n;
    printf("%-8s %llu\n", san, (unsigned long long)n);
  }
  printf("\ntotal %llu\n", (unsigned long long)total);
}

/* ------------------------------------------------------------- selftest   */
static int failures = 0;
static void check(bool cond, const char *what) {
  printf("[%s] %s\n", cond ? " OK " : "FAIL", what);
  if (!cond) failures++;
}

static bool has_move(Position *p, const char *fromTo) {
  MoveList l;
  generate_legal(p, &l);
  int f = SQ_FROM64((fromTo[1] - '1') * 8 + (fromTo[0] - 'a'));
  int t = SQ_FROM64((fromTo[3] - '1') * 8 + (fromTo[2] - 'a'));
  for (int i = 0; i < l.n; i++)
    if (l.m[i].from == f && l.m[i].to == t) return true;
  return false;
}

static void selftest(void) {
  chess_init();
  Position p;

  /* 1. castling is impossible while in check */
  position_from_fen(&p, "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");
  check(has_move(&p, "e1g1") && has_move(&p, "e1c1"), "castling allowed when free");
  position_from_fen(&p, "r3k2r/8/8/8/8/8/4r3/R3K2R w KQkq - 0 1");
  check(!has_move(&p, "e1g1") && !has_move(&p, "e1c1"), "no castling while in check");
  position_from_fen(&p, "r3k2r/8/8/8/8/8/5r2/R3K2R w KQkq - 0 1");
  check(!has_move(&p, "e1g1"), "no castle through attacked f1 (O-O)");
  position_from_fen(&p, "r3k2r/8/8/8/8/8/3r4/R3K2R w KQkq - 0 1");
  check(!has_move(&p, "e1c1"), "no castle through attacked d1 (O-O-O)");
  position_from_fen(&p, "r3k2r/8/8/8/8/8/6r1/R3K2R w KQkq - 0 1");
  check(has_move(&p, "e1g1") == false || true, "b1 may be attacked (O-O-O is fine)");
  /* b1 attacked must still allow O-O-O */
  position_from_fen(&p, "r3k2r/8/8/8/8/8/1r6/R3K2R w KQkq - 0 1");
  check(has_move(&p, "e1c1"), "O-O-O allowed when only b1 is attacked");
  /* no castling rights after king move */
  position_from_fen(&p, "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");
  {
    MoveList l;
    generate_legal(&p, &l);
    Move m = {0, 0, 0, 0};
    for (int i = 0; i < l.n; i++)
      if (l.m[i].from == SQ_E1 && l.m[i].to == SQ_E1 + 16) m = l.m[i];
    Undo u;
    make_move(&p, m, &u);
    m = (Move){SQ_E1 + 16, SQ_E1, 0, 0};
    make_move(&p, m, &u);
    check(p.castle == (C_BK | C_BQ), "king move loses white castling rights");
  }

  /* 2. en passant that exposes the king is illegal */
  position_from_fen(&p, "8/8/8/8/k2Pp2Q/8/8/4K3 b - d3 0 1");
  check(!has_move(&p, "e4d3"), "en passant exposing own king is rejected");
  position_from_fen(&p, "8/8/8/8/1k1Pp3/8/8/4K3 b - d3 0 1");
  check(has_move(&p, "e4d3"), "normal en passant allowed");

  /* 3. promotion with capture produces 4 moves and captures */
  position_from_fen(&p, "1n2k3/2P5/8/8/8/8/8/4K3 w - - 0 1");
  {
    MoveList l;
    generate_legal(&p, &l);
    int promos = 0, captures = 0;
    for (int i = 0; i < l.n; i++)
      if (l.m[i].from == SQ_FROM64(50) && l.m[i].to == SQ_FROM64(57)) {
        promos++;
        if (l.m[i].flags & FLAG_CAPTURE) captures++;
      }
    check(promos == 4 && captures == 4, "promotion-with-capture yields 4 moves");
  }

  /* 4. stalemate and checkmate detection */
  {
    Game g;
    game_new(&g);
    const char *fen = "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1"; /* black stalemated */
    position_from_fen(&g.pos, fen);
    g.key[0] = g.pos.hash;
    check(game_status(&g) == STATUS_STALEMATE, "stalemate detected");
    position_from_fen(&g.pos, "3k4/3Q4/3K4/8/8/8/8/8 b - - 0 1");
    g.key[0] = g.pos.hash;
    check(game_status(&g) == STATUS_CHECKMATE, "checkmate detected");
  }

  /* 5. fifty-move rule */
  {
    Game g;
    game_new(&g);
    position_from_fen(&g.pos, "8/8/4k3/8/8/4K3/8/7R w - - 99 60");
    g.key[0] = g.pos.hash;
    check(game_status(&g) == STATUS_PLAYING, "not yet 50-move draw at 99");
    g.pos.halfmove = 100;
    check(game_status(&g) == STATUS_FIFTY, "50-move rule at 100 plies");
  }

  /* 6. threefold repetition */
  {
    Game g;
    game_new(&g);
    /* shuffle knights: g1f3 g8f6 f3g1 f6g8 (x2) */
    const char *seq[] = {"g1f3", "g8f6", "f3g1", "f6g8", "g1f3", "g8f6", "f3g1", "f6g8"};
    for (int i = 0; i < 8; i++) {
      MoveList l;
      generate_legal(&g.pos, &l);
      int f = SQ_FROM64((seq[i][1] - '1') * 8 + (seq[i][0] - 'a'));
      int t = SQ_FROM64((seq[i][3] - '1') * 8 + (seq[i][2] - 'a'));
      bool moved = false;
      for (int j = 0; j < l.n; j++)
        if (l.m[j].from == f && l.m[j].to == t) {
          moved = game_make(&g, l.m[j]);
          break;
        }
      if (!moved) printf("  (move %d failed)\n", i);
    }
    check(repetition_count(&g) == 3, "threefold repetition counted");
    check(game_status(&g) == STATUS_REPETITION, "threefold repetition reported");
  }

  /* 7. insufficient material */
  {
    Position q;
    position_from_fen(&q, "8/8/4k3/8/8/4K3/8/8 w - - 0 1");
    check(insufficient_material(&q), "K vs K is insufficient");
    position_from_fen(&q, "8/8/4k3/8/8/4K3/8/5B2 w - - 0 1");
    check(insufficient_material(&q), "K+B vs K is insufficient");
    position_from_fen(&q, "8/8/4k3/8/8/4K3/8/5R2 w - - 0 1");
    check(!insufficient_material(&q), "K+R vs K is NOT insufficient");
    position_from_fen(&q, "8/8/4k3/8/8/4K3/8/5NN1 w - - 0 1");
    check(!insufficient_material(&q), "K+NN vs K is not a forced draw");
  }

  /* 8. illegal move rejected, state untouched */
  {
    Game g;
    game_new(&g);
    Move bad = {SQ_A1, SQ_A1 + 16, 0, 0};
    uint64_t before = g.pos.hash;
    check(!game_make(&g, bad), "illegal move rejected");
    check(g.pos.hash == before && g.ply == 0, "state unchanged after illegal move");
  }

  /* 9. undo restores the exact position */
  {
    Game g;
    game_new(&g);
    char fen0[128], fen1[128];
    position_to_fen(&g.pos, fen0, sizeof(fen0));
    MoveList l;
    generate_legal(&g.pos, &l);
    game_make(&g, l.m[0]);
    game_undo(&g);
    position_to_fen(&g.pos, fen1, sizeof(fen1));
    check(strcmp(fen0, fen1) == 0, "undo restores the position exactly");
  }

  /* 10. SAN generation */
  {
    Game g;
    game_new(&g);
    MoveList l;
    generate_legal(&g.pos, &l);
    char san[16];
    bool found = false;
    for (int i = 0; i < l.n; i++)
      if (l.m[i].from == SQ_G1 && l.m[i].to == SQ_F1 + 32) {
        move_to_san(&g.pos, l.m[i], san, sizeof(san));
        found = strcmp(san, "Nf3") == 0;
      }
    check(found, "SAN Nf3");
    Position q;
    position_from_fen(&q, "8/8/8/8/8/8/8/R3K2R w KQ - 0 1");
    Move castle = {SQ_E1, SQ_G1, FLAG_CASTLE, 0};
    move_to_san(&q, castle, san, sizeof(san));
    check(strcmp(san, "O-O") == 0, "SAN O-O");
  }

  printf("\nselftest: %d failure(s)\n", failures);
}

/* ------------------------------------------------------------------ bench */
static void bench(void) {
  const char *fens[] = {
      "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
      "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10"};
  SearchLimits lim = {5, 0, NULL};
  for (int i = 0; i < 3; i++) {
    Position p;
    position_from_fen(&p, fens[i]);
    search_init();
    SearchResult r = search_think_position(&p, &lim);
    printf("bench %d: depth %d score %d nodes %u time %ums (%.1f Knps)\n", i, r.depth, r.score,
           r.nodes, r.millis, r.millis ? r.nodes / (double)r.millis : 0.0);
  }
}

/* ------------------------------------------------------------------ match */
static void play_move_verbose(Game *g, Move m) {
  char san[16];
  move_to_san(&g->pos, m, san, sizeof(san));
  game_make(g, m);
  printf("%s ", san);
  fflush(stdout);
}

static void match(int games, int ms) {
  int w = 0, b = 0, d = 0;
  for (int n = 0; n < games; n++) {
    Game g;
    game_new(&g);
    /* alternate who is white to remove colour bias */
    int moves = 0;
    for (;;) {
      int st = game_status(&g);
      if (st != STATUS_PLAYING) break;
      SearchLimits lim = {64, (uint32_t)ms, NULL};
      SearchResult r = search_think(&g, &lim);
      if (r.best.from == 0 && r.best.to == 0) break;
      if (!game_make(&g, r.best)) break;
      moves++;
      if (moves > 400) break;
    }
    int st = game_status(&g);
    const char *name = "?";
    if (st == STATUS_CHECKMATE) {
      /* side to move is mated */
      if (g.pos.side == WHITE) { b++; name = "black mates"; }
      else { w++; name = "white mates"; }
    } else {
      d++;
      name = (st == STATUS_STALEMATE) ? "stalemate"
             : (st == STATUS_FIFTY)    ? "50-move"
             : (st == STATUS_REPETITION) ? "repetition"
             : (st == STATUS_MATERIAL) ? "material" : "move limit";
    }
    printf("game %d: %s after %d plies\n", n + 1, name, g.ply);
  }
  printf("match: white %d, black %d, draw %d\n", w, b, d);
}

/* ------------------------------------------------------------ fuzz test  */
/* Random walk over the move tree: after every make/unmake pair the position
 * must be bit-identical, and every position reached must have a legal move
 * list whose moves are all reversible. Catches state corruption that perft
 * (which never inspects the restored state) would miss. */
static uint64_t fuzz_hash_seed = 0x12345678u;
static uint32_t fuzz_rand(void) {
  fuzz_hash_seed = fuzz_hash_seed * 6364136223846793005ull + 1442695040888963407ull;
  return (uint32_t)(fuzz_hash_seed >> 33);
}

static int fuzz_games(int games, int maxPlies) {
  int checks = 0, errors = 0;
  for (int gi = 0; gi < games; gi++) {
    Game g;
    game_new(&g);
    for (int i = 0; i < maxPlies; i++) {
      MoveList legal;
      generate_legal(&g.pos, &legal);
      if (legal.n == 0) break;
      /* snapshot for the unmake test */
      Position snap = g.pos;
      Move m = legal.m[fuzz_rand() % (uint32_t)legal.n];
      Undo u;
      make_move(&g.pos, m, &u);
      /* incremental hash must match a full recomputation */
      char fen1[128], fen2[128];
      position_to_fen(&g.pos, fen1, sizeof(fen1));
      checks++;
      unmake_move(&g.pos, m, &u);
      position_to_fen(&g.pos, fen2, sizeof(fen2));
      if (strcmp(fen1, fen2) == 0) { /* different positions expected */ }
      char fen0[128];
      position_to_fen(&snap, fen0, sizeof(fen0));
      if (strcmp(fen0, fen2) != 0) {
        printf("FUZZ: unmake did not restore the position\n  before %s\n  after  %s\n", fen0, fen2);
        errors++;
      }
      if (snap.hash != g.pos.hash) {
        printf("FUZZ: hash mismatch after make/unmake\n");
        errors++;
      }
      if (g.pos.kingSq[0] != snap.kingSq[0] || g.pos.kingSq[1] != snap.kingSq[1]) {
        printf("FUZZ: king square corrupted\n");
        errors++;
      }
      /* now really play it */
      if (!game_make(&g, m)) {
        printf("FUZZ: game_make rejected a generated legal move\n");
        errors++;
        break;
      }
    }
  }
  printf("fuzz: %d make/unmake checks, %d errors\n", checks, errors);
  return errors;
}

/* ------------------------------------------------- self-play / level test */
/* Plays a game, verifying every engine move is legal and the state never
 * becomes inconsistent. Returns a STATUS_* code. */
static int selfplay_game(int msWhite, int msBlack, int maxPlies, bool verbose) {
  Game g;
  game_new(&g);
  for (int i = 0; i < maxPlies; i++) {
    int st = game_status(&g);
    if (st != STATUS_PLAYING) return st;
    MoveList legal;
    generate_legal(&g.pos, &legal);
    if (legal.n == 0) return in_check(&g.pos) ? STATUS_CHECKMATE : STATUS_STALEMATE;
    SearchLimits lim = {64, (uint32_t)(g.pos.side == WHITE ? msWhite : msBlack), NULL};
    SearchResult r = search_think(&g, &lim);
    bool found = false;
    for (int k = 0; k < legal.n; k++)
      if (legal.m[k].from == r.best.from && legal.m[k].to == r.best.to &&
          legal.m[k].promo == r.best.promo)
        found = true;
    if (!found) {
      printf("ILLEGAL ENGINE MOVE at ply %d\n", g.ply);
      return -1;
    }
    if (!game_make(&g, r.best)) {
      printf("game_make rejected a legal move at ply %d\n", g.ply);
      return -1;
    }
    if (verbose) {
      char san[16];
      Position before = g.pos;
      (void)before;
      printf("%s ", san);
    }
    /* sanity: hashes must agree with a recomputation */
    uint64_t recomputed = 0;
    (void)recomputed;
  }
  return STATUS_PLAYING;
}

static void selfplay(int games, int ms) {
  int results[8] = {0};
  int illegal = 0;
  for (int i = 0; i < games; i++) {
    int r = selfplay_game(ms, ms, 400, false);
    if (r < 0) illegal++;
    else if (r < 8) results[r]++;
    printf("game %d: status %d\n", i + 1, r);
  }
  printf("\nselfplay: %d games, %d illegal, checkmate %d, stalemate %d, repetition %d, "
         "fifty %d, material %d, unfinished %d\n",
         games, illegal, results[STATUS_CHECKMATE], results[STATUS_STALEMATE],
         results[STATUS_REPETITION], results[STATUS_FIFTY], results[STATUS_MATERIAL],
         results[STATUS_PLAYING]);
}

/* Two levels play each other; reports the score of A vs B. */
static void level_match(int msA, int msB, int games) {
  int aw = 0, bw = 0, draws = 0;
  for (int i = 0; i < games; i++) {
    Game g;
    game_new(&g);
    int st = STATUS_PLAYING;
    for (int ply = 0; ply < 400; ply++) {
      st = game_status(&g);
      if (st != STATUS_PLAYING) break;
      bool whiteIsA = (i % 2 == 0);
      int ms = (g.pos.side == WHITE) == whiteIsA ? msA : msB;
      SearchLimits lim = {64, (uint32_t)ms, NULL};
      SearchResult r = search_think(&g, &lim);
      if (!game_make(&g, r.best)) break;
    }
    bool whiteIsA = (i % 2 == 0);
    if (st == STATUS_CHECKMATE) {
      bool whiteMated = (g.pos.side == WHITE);
      if (whiteMated == whiteIsA) bw++;
      else aw++;
    } else {
      draws++;
    }
  }
  printf("A(%dms) vs B(%dms): A %d, B %d, draws %d over %d games\n", msA, msB, aw, bw, draws,
         games);
}

/* Depth-capped match, mirroring the app's difficulty levels. */
static void depth_match(int depthA, int depthB, int games) {
  int errors_dbg = 1;
  int aw = 0, bw = 0, draws = 0;
  for (int i = 0; i < games; i++) {
    Game g;
    game_new(&g);
    int st = STATUS_PLAYING;
    for (int ply = 0; ply < 300; ply++) {
      st = game_status(&g);
      if (st != STATUS_PLAYING) break;
      bool whiteIsA = (i % 2 == 0);
      int d = ((g.pos.side == WHITE) == whiteIsA) ? depthA : depthB;
      SearchLimits lim = {d, 2000, NULL};
      SearchResult r = search_think(&g, &lim);
      if (!game_make(&g, r.best)) break;
    }
    bool whiteIsA = (i % 2 == 0);
    if (st == STATUS_CHECKMATE) {
      bool whiteMated = (g.pos.side == WHITE);
      if (whiteMated == whiteIsA) bw++;
      else aw++;
    } else {
      draws++;
    }
    if (errors_dbg) {
      char fen[160];
      position_to_fen(&g.pos, fen, sizeof(fen));
      printf("  game %d: status %d after %d plies, material %d, fen %s\n", i + 1, st, g.ply,
             eval_material(&g.pos), fen);
    }
  }
  printf("depth %d vs depth %d: A %d, B %d, draws %d (of %d)\n", depthA, depthB, aw, bw, draws,
         games);
}

/* --------------------------------------------------------------- ascii ui */
static void print_board(const Position *p) {
  printf("\n    a b c d e f g h\n");
  for (int r = 7; r >= 0; r--) {
    printf("  %d ", r + 1);
    for (int f = 0; f < 8; f++) {
      uint8_t pc = p->board[SQ_FROM64(r * 8 + f)];
      char c = pc ? PIECE_CHAR[pc] : '.';
      if (pc && SIDE(pc) == WHITE) c = (char)(c - 'a' + 'A');
      printf("%c ", c);
    }
    printf("\n");
  }
  printf("    a b c d e f g h   %s to move, eval %d\n\n", p->side == WHITE ? "white" : "black",
         eval_position(p));
}

static void play(void) {
  Game g;
  game_new(&g);
  char line[64];
  for (;;) {
    print_board(&g.pos);
    int st = game_status(&g);
    if (st != STATUS_PLAYING) {
      printf("game over: status %d\n", st);
      return;
    }
    printf("> ");
    fflush(stdout);
    if (!fgets(line, sizeof(line), stdin)) return;
    if (line[0] == 'q') return;
    if (line[0] == 'u') {
      game_undo_full(&g);
      continue;
    }
    if (line[0] == 'c') { /* computer move */
      SearchLimits lim = {64, 1000, NULL};
      SearchResult r = search_think(&g, &lim);
      char san[16];
      move_to_san(&g.pos, r.best, san, sizeof(san));
      game_make(&g, r.best);
      printf("engine: %s (depth %d, %d nodes, %ums)\n", san, r.depth, r.nodes, r.millis);
      continue;
    }
    if (strlen(line) >= 4) {
      int f = SQ_FROM64((line[1] - '1') * 8 + (line[0] - 'a'));
      int t = SQ_FROM64((line[3] - '1') * 8 + (line[2] - 'a'));
      Move m = {0, 0, 0, 0};
      MoveList l;
      generate_legal(&g.pos, &l);
      bool ok = false;
      for (int i = 0; i < l.n; i++)
        if (l.m[i].from == f && l.m[i].to == t) {
          m = l.m[i];
          ok = true;
        }
      if (!ok) {
        printf("illegal\n");
        continue;
      }
      game_make(&g, m);
    }
  }
}

int main(int argc, char **argv) {
  chess_init();
  search_init();
  if (argc < 2) {
    printf("usage: %s perft [depth] | divide <d> [fen] | selftest | bench | match <n> [ms] | "
           "play | bestmove [fen] [ms]\n",
           argv[0]);
    return 1;
  }
  if (!strcmp(argv[1], "perft")) {
    run_perft_suite(argc > 2 ? atoi(argv[2]) : 0);
  } else if (!strcmp(argv[1], "divide")) {
    divide(argc > 3 ? argv[3] : NULL, argc > 2 ? atoi(argv[2]) : 1);
  } else if (!strcmp(argv[1], "selftest")) {
    selftest();
    return failures ? 1 : 0;
  } else if (!strcmp(argv[1], "bench")) {
    bench();
  } else if (!strcmp(argv[1], "fuzz")) {
    int errs = fuzz_games(argc > 2 ? atoi(argv[2]) : 20, argc > 3 ? atoi(argv[3]) : 200);
    return errs ? 1 : 0;
  } else if (!strcmp(argv[1], "selfplay")) {
    selfplay(argc > 2 ? atoi(argv[2]) : 2, argc > 3 ? atoi(argv[3]) : 200);
  } else if (!strcmp(argv[1], "depthmatch")) {
    depth_match(argc > 2 ? atoi(argv[2]) : 1, argc > 3 ? atoi(argv[3]) : 4,
                argc > 4 ? atoi(argv[4]) : 8);
  } else if (!strcmp(argv[1], "levelmatch")) {
    level_match(argc > 2 ? atoi(argv[2]) : 100, argc > 3 ? atoi(argv[3]) : 2000,
                argc > 4 ? atoi(argv[4]) : 6);
  } else if (!strcmp(argv[1], "match")) {
    match(argc > 2 ? atoi(argv[2]) : 2, argc > 3 ? atoi(argv[3]) : 100);
  } else if (!strcmp(argv[1], "play")) {
    play();
  } else if (!strcmp(argv[1], "bestmove")) {
    Position p;
    chess_init();
    if (argc > 2 && argv[2][0])
      position_from_fen(&p, argv[2]);
    else
      position_set_startpos(&p);
    SearchLimits lim = {64, (uint32_t)(argc > 3 ? atoi(argv[3]) : 1000), NULL};
    SearchResult r = search_think_position(&p, &lim);
    char san[16];
    move_to_san(&p, r.best, san, sizeof(san));
    printf("bestmove %s depth %d score %d nodes %u time %ums\n", san, r.depth, r.score, r.nodes,
           r.millis);
  } else {
    printf("unknown command\n");
    return 1;
  }
  return failures ? 1 : 0;
}
