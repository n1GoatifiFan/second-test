# Epsilon simulator scenarios

`.nwt` state files replayed by the Epsilon **simulator** build (`chess.nwb`).
Each file lists one key name per line after the 5-line header; the names must
come from Epsilon's `events_names.inc` (`OK`, `Back`, `Up`, `Down`, `Left`,
`Right`, `EXE`, `Home`, `Backspace`, `Toolbox`, `Shift`, `Alpha`, ...).

A misspelt key name makes *the simulator* segfault inside
`Ion::Simulator::StateFile::load` - it is not an app crash (verified with gdb).

| file | what it exercises |
|---|---|
| `s0_start.nwt` | start position renders |
| `s1_select.nwt` | cursor select, legal-move dots |
| `s2_engine_reply.nwt` | 1.e4 + engine reply, move list |
| `s3_menu_flip.nwt` | menu, "play as black", board flipped |
| `s4_level.nwt` | menu highlight on "Level" (Right changes the value 3 -> 4 in place) |
| `s7_resign.nwt` | Resign -> "Game over / White resigned" |
| `s8_draw_refused.nwt` | Draw in the opening -> "Draw refused" |
| `s5_exit_prompt.nwt` | "leave the game?" confirmation |
| `s6_exit_confirm.nwt` | OK on the prompt: app returns, simulator exits 0 |

Run them from a writable directory:

```sh
for s in s0_start s1_select s2_engine_reply s3_menu_flip s4_level s5_exit_prompt; do
  xvfb-run -a /path/to/epsilon.bin --nwb ../output/chess.nwb --headless \
      --load-state-file $s.nwt --take-screenshot $s.png
done
xvfb-run -a /path/to/epsilon.bin --nwb ../output/chess.nwb --headless \
    --load-state-file s6_exit_confirm.nwt --take-screenshot exit.png   # no file: app exited
```

`--headless` needs an X server, hence `xvfb-run`; always wrap in `timeout`.
