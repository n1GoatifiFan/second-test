/* ui_main.c - native harness for the UI: renders the real screens to PPM files
 * and drives them with a scripted key sequence.
 *
 *   ui_main render <out.ppm> [keys...]   replay keys then dump the frame
 *   ui_main tour <outdir>                render screens: play, menu, promo,
 *                                        game over, sandbox position
 *
 * Keys are given as names: up down left right ok back home
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "app/game.h"
#include "chess/search_platform.h"
#include "app/ui.h"

void native_set_script(const int *keys, int n);

/* provided by platform_native.c */

static int key_from_name(const char *n) {
  if (!strcmp(n, "up")) return KEY_UP;
  if (!strcmp(n, "down")) return KEY_DOWN;
  if (!strcmp(n, "left")) return KEY_LEFT;
  if (!strcmp(n, "right")) return KEY_RIGHT;
  if (!strcmp(n, "ok")) return KEY_OK;
  if (!strcmp(n, "back")) return KEY_BACK;
  if (!strcmp(n, "home")) return KEY_HOME;
  return KEY_NONE;
}

static void write_ppm(const char *path) {
  Canvas *c = platform_screen();
  FILE *f = fopen(path, "wb");
  if (!f) {
    printf("cannot write %s\n", path);
    return;
  }
  fprintf(f, "P6\n%d %d\n255\n", c->w, c->h);
  for (int i = 0; i < c->w * c->h; i++) {
    color_t p = c->px[i];
    fputc((int)(((p >> 11) & 0x1F) * 255 / 31), f);
    fputc((int)(((p >> 5) & 0x3F) * 255 / 63), f);
    fputc((int)((p & 0x1F) * 255 / 31), f);
  }
  fclose(f);
  printf("wrote %s\n", path);
}

static void run_script(ChessApp *a, const int *keys, int n) {
  for (int i = 0; i < n; i++) {
    app_handle_key(a, keys[i]);
    ui_render(platform_screen(), a);
  }
}

int main(int argc, char **argv) {
  static ChessApp app;
  app_init(&app);

  if (argc < 3) {
    printf("usage: %s render <out.ppm> [keys...] | tour <outdir>\n", argv[0]);
    return 1;
  }

  if (!strcmp(argv[1], "render")) {
    int keys[128];
    int n = 0;
    for (int i = 3; i < argc && n < 128; i++) keys[n++] = key_from_name(argv[i]);
    /* keys are consumed by the app loop, not by platform_poll_key */
    for (int i = 0; i < n; i++) app_handle_key(&app, keys[i]);
    ui_render(platform_screen(), &app);
    write_ppm(argv[2]);
    return 0;
  }

  if (!strcmp(argv[1], "game")) {
    /* Play a full human-vs-human game through the UI layer with the scripted
     * keys, then let the engine (as black) answer, to prove the wiring. */
    char path[256];
    ChessApp g = app;
    g.humanSide = WHITE;   /* engine plays black */
    g.level = 1;
    /* e2-e4 via cursor moves: cursor starts on e2 */
    app_handle_key(&g, KEY_OK);      /* select e2 pawn */
    app_handle_key(&g, KEY_UP);      /* cursor e3 */
    app_handle_key(&g, KEY_UP);      /* cursor e4 */
    app_handle_key(&g, KEY_OK);      /* play e2e4 */
    ui_render(platform_screen(), &g);
    snprintf(path, sizeof(path), "%s/10_after_e4.ppm", argv[2]);
    write_ppm(path);
    printf("after human move: ply=%d movetext=%s status=%d\n", g.g.ply, g.movetext, g.status);
    /* engine answers */
    bool ok = app_engine_think(&g);
    ui_render(platform_screen(), &g);
    snprintf(path, sizeof(path), "%s/11_after_engine.ppm", argv[2]);
    write_ppm(path);
    printf("engine ok=%d ply=%d movetext=%s depth=%d nodes=%u\n", (int)ok, g.g.ply, g.movetext,
           g.thinkDepth, (unsigned)g.thinkNodes);
    /* undo the full move pair */
    app_undo_full(&g);
    printf("after undo: ply=%d movetext=%s\n", g.g.ply, g.movetext);
    /* exercise the menu: play as black, level up, flip */
    app_handle_key(&g, KEY_HOME);
    app_handle_key(&g, KEY_DOWN);           /* Play as */
    app_handle_key(&g, KEY_RIGHT);          /* black */
    printf("side now=%d flip=%d ply=%d\n", g.humanSide, g.flip, g.g.ply);
    app_handle_key(&g, KEY_DOWN);           /* level (index 1 -> 2) */
    app_handle_key(&g, KEY_RIGHT);
    printf("after right: side=%d level=%d screen=%d\n", g.humanSide, g.level, g.screen);
    app_handle_key(&g, KEY_DOWN);           /* level row */
    app_handle_key(&g, KEY_RIGHT);          /* level +1 */
    printf("level now=%d (screen %d menuIndex %d)\n", g.level, g.screen, g.menuIndex);
    ui_render(platform_screen(), &g);
    snprintf(path, sizeof(path), "%s/12_menu_black.ppm", argv[2]);
    write_ppm(path);
    return 0;
  }

  if (!strcmp(argv[1], "enginegame")) {
    /* Play 12 full moves: human (level-1 engine driving both sides via the
     * app's own engine path is not possible in human-vs-human mode, so drive
     * chess directly and render through the app's renderer) */
    ChessApp s = app;
    s.humanSide = WHITE;
    s.level = 1;
    int plies = 0;
    while (s.status == STATUS_PLAYING && plies < 24) {
      if (s.g.pos.side == WHITE) {
        /* deterministic "human" move: a random legal move through the UI */
        MoveList l;
        generate_legal(&s.g.pos, &l);
        Move m = l.m[rand() % l.n];
        char san[SAN_MAX];
        move_to_san(&s.g.pos, m, san, sizeof(san));
        /* find and click it with the cursor, as a player would */
        int row, col;
        app_display_pos(&s, m.from, &row, &col);
        s.cursor = m.from;
        app_handle_key(&s, KEY_OK);
        if (s.screen == SCREEN_PLAY && s.hasSelection) {
          app_display_pos(&s, m.to, &row, &col);
          s.cursor = m.to;
          app_handle_key(&s, KEY_OK);
        }
        /* promotions show the picker: choose queen */
        if (s.screen == SCREEN_PROMO) app_handle_key(&s, KEY_OK);
      } else {
        if (!app_engine_think(&s)) break;
      }
      plies++;
      if (s.g.ply != plies) {
        printf("ERROR: expected ply %d, got %d (screen %d)\n", plies, s.g.ply, s.screen);
        return 1;
      }
    }
    printf("enginegame: %d plies, movelist '%s', status %d\n", s.g.ply, s.movetext, s.status);
    ui_render(platform_screen(), &s);
    write_ppm("build/tour/30_enginegame.ppm");
    return 0;
  }

  if (!strcmp(argv[1], "draws")) {
    /* A draw offer must be refused in the opening, and accepted when the
     * position is genuinely drawish. Threefold repetition ends the game
     * automatically, before any offer is needed. */
    ChessApp s = app;
    s.humanSide = -1;
    app_agree_draw(&s);
    int refused = (s.screen == SCREEN_MESSAGE) && strstr(s.message, "refused") != NULL;

    app_new_game(&s);
    s.humanSide = -1; /* two players: both colours are human */
    const char *shuffle[] = {"g1f3", "g8f6", "f3g1", "f6g8"};
    for (int i = 0; i < 12 && s.status == STATUS_PLAYING; i++) {
      const char *m = shuffle[i % 4];
      s.cursor = SQ_FROM64((m[1] - '1') * 8 + (m[0] - 'a'));
      app_handle_key(&s, KEY_OK);
      s.cursor = SQ_FROM64((m[3] - '1') * 8 + (m[2] - 'a'));
      app_handle_key(&s, KEY_OK);
    }
    int auto_repetition = (s.status == STATUS_REPETITION);
    int reps = repetition_count(&s.g);

    /* Now the offer-accepted path: a game that is drawish by the 50-move
     * counter must accept the offer. */
    ChessApp d = app;
    d.humanSide = -1;
    d.g.pos.halfmove = 85;
    app_agree_draw(&d);
    int accepted = (d.screen == SCREEN_GAME_OVER) && d.status == STATUS_DRAW_AGREED;

    printf("draws: opening offer %s | threefold auto-detected %s (repetition %d, ply %d) | "
           "50-move offer %s\n",
           refused ? "refused OK" : "ACCEPTED (BUG)",
           auto_repetition ? "OK" : "MISSED (BUG)", reps, s.g.ply,
           accepted ? "accepted OK" : "REFUSED (BUG)");
    return (refused && auto_repetition && accepted) ? 0 : 1;
  }

  if (!strcmp(argv[1], "saveload")) {
    /* play a few moves, save, disturb the state, load, compare */
    ChessApp s = app;
    s.humanSide = -1;
    const char *moves[] = {"e2e4", "e7e5", "g1f3", "b8c6", "f1b5"};
    for (int i = 0; i < 5; i++) {
      int f = SQ_FROM64((moves[i][1] - '1') * 8 + (moves[i][0] - 'a'));
      int t = SQ_FROM64((moves[i][3] - '1') * 8 + (moves[i][2] - 'a'));
      s.cursor = f;
      app_handle_key(&s, KEY_OK);
      s.cursor = t;
      app_handle_key(&s, KEY_OK);
      if (s.screen == SCREEN_PROMO) app_handle_key(&s, KEY_OK);
    }
    char fenBefore[160], fenAfter[160];
    position_to_fen(&s.g.pos, fenBefore, sizeof(fenBefore));
    if (!app_save(&s)) {
      printf("save FAILED\n");
      return 1;
    }
    app_new_game(&s); /* wipe */
    if (!app_load(&s)) {
      printf("load FAILED\n");
      return 1;
    }
    position_to_fen(&s.g.pos, fenAfter, sizeof(fenAfter));
    int ok = strcmp(fenBefore, fenAfter) == 0;
    printf("saveload: %s (%d plies)\n  before %s\n  after  %s\n  movetext %s\n",
           ok ? "OK" : "MISMATCH", s.g.ply, fenBefore, fenAfter, s.movetext);
    /* corrupt-file robustness */
    {
      FILE *f = fopen("build/native_save.bin", "wb");
      if (f) {
        const char junk[8] = {1, 2, 3, 4, 5, 6, 7, 8};
        fwrite(junk, 1, sizeof(junk), f);
        fclose(f);
      }
      int rejected = !app_load(&s);
      printf("corrupt save rejected: %s\n", rejected ? "yes" : "NO");
      ok = ok && rejected;
    }
    return ok ? 0 : 1;
  }

  if (!strcmp(argv[1], "stress")) {
    /* Random key soup for many iterations: the app must never crash, never
     * produce an invalid position, and always stay in a known screen. */
    ChessApp s = app;
    s.humanSide = -1; /* human vs human: the engine is not involved */
    srand(12345);
    int screens[8] = {0};
    for (int i = 0; i < 20000; i++) {
      int r = rand() % 100;
      Key k;
      if (r < 45) k = (Key)(KEY_LEFT + (rand() % 4));
      else if (r < 75) k = KEY_OK;
      else if (r < 92) k = KEY_BACK;
      else k = KEY_MENU;
      app_handle_key(&s, k);
      if (s.screen > SCREEN_MESSAGE) {
        printf("ERROR: invalid screen %d at iteration %d\n", s.screen, i);
        return 1;
      }
      screens[s.screen]++;
      /* invariants */
      if (s.selFrom != NO_SQUARE && !s.hasSelection) {
        printf("ERROR: selection desync at %d\n", i);
        return 1;
      }
      if (s.g.ply < 0 || s.g.ply >= MAX_HISTORY) {
        printf("ERROR: ply out of range %d\n", s.g.ply);
        return 1;
      }
      if (s.cursor == NO_SQUARE) {
        printf("ERROR: cursor off board at %d\n", i);
        return 1;
      }
      Position check = s.g.pos;
      char fen[160];
      position_to_fen(&check, fen, sizeof(fen));
      if (strlen(fen) < 20) {
        printf("ERROR: corrupt position at %d: '%s'\n", i, fen);
        return 1;
      }
    }
    /* promotion-dialog stress: every key inside the picker */
    {
      ChessApp q = app;
      q.humanSide = -1;
      position_from_fen(&q.g.pos, "4k3/2P5/8/8/8/8/8/4K3 w - - 0 1");
      q.g.ply = 0;
      q.g.key[0] = q.g.pos.hash;
      q.hasSelection = true;
      q.selFrom = SQ_FROM64(50);
      q.cursor = SQ_FROM64(58);
      srand(999);
      int promosDone = 0;
      for (int i = 0; i < 3000; i++) {
        int r = rand() % 100;
        Key k;
        if (r < 40) k = KEY_UP;
        else if (r < 80) k = KEY_DOWN;
        else if (r < 95) k = KEY_OK;
        else k = KEY_BACK;
        app_handle_key(&q, k);
        if (q.g.ply > 0) { /* a promotion was played */
          promosDone++;
          char fen[128];
          position_to_fen(&q.g.pos, fen, sizeof(fen));
          if (strstr(fen, "Q") == NULL && strstr(fen, "R") == NULL &&
              strstr(fen, "B") == NULL && strstr(fen, "N") == NULL) {
            printf("ERROR: promotion produced no piece: %s\n", fen);
            return 1;
          }
          /* reset the position to promote again */
          q = app;
          q.humanSide = -1;
          position_from_fen(&q.g.pos, "4k3/2P5/8/8/8/8/8/4K3 w - - 0 1");
          q.g.ply = 0;
          q.g.key[0] = q.g.pos.hash;
          q.hasSelection = true;
          q.selFrom = SQ_FROM64(50);
          q.cursor = SQ_FROM64(58);
        }
      }
      printf("promotion stress: %d promotions played, all produced a piece\n", promosDone);
    }
    printf("stress: 20000 random key events OK\n");
    printf("  screens visited: play %d, menu %d, promo %d, exit %d, over %d, msg %d\n",
           screens[SCREEN_PLAY], screens[SCREEN_MENU], screens[SCREEN_PROMO],
           screens[SCREEN_CONFIRM_EXIT], screens[SCREEN_GAME_OVER], screens[SCREEN_MESSAGE]);
    ui_render(platform_screen(), &s);
    write_ppm("build/tour/20_stress_final.ppm");
    return 0;
  }

  if (!strcmp(argv[1], "tour")) {
    char path[256];
    snprintf(path, sizeof(path), "%s/01_play.ppm", argv[2]);
    ui_render(platform_screen(), &app);
    write_ppm(path);

    /* cursor to e4-ish and select: 4 down (e2 -> e4 after selecting) */
    int sel[] = {KEY_OK};
    run_script(&app, sel, 1);
    ui_render(platform_screen(), &app);
    snprintf(path, sizeof(path), "%s/02_selected.ppm", argv[2]);
    write_ppm(path);

    /* move e2-e4 then open the menu */
    ChessApp m = app;
    int mv[] = {KEY_UP, KEY_UP, KEY_OK};
    run_script(&m, mv, 3);
    app_handle_key(&m, KEY_HOME);
    ui_render(platform_screen(), &m);
    snprintf(path, sizeof(path), "%s/03_menu.ppm", argv[2]);
    write_ppm(path);

    /* promotion dialog */
    ChessApp p = app;
    position_from_fen(&p.g.pos, "4k3/2P5/8/8/8/8/8/4K3 w - - 0 1");
    p.g.key[0] = p.g.pos.hash;
    p.g.ply = 0;
    p.hasSelection = true;
    p.selFrom = SQ_FROM64(50); /* c7 */
    p.cursor = SQ_FROM64(58);  /* c8 */
    p.screen = SCREEN_PROMO;
    p.promoIndex = 0;
    ui_render(platform_screen(), &p);
    snprintf(path, sizeof(path), "%s/04_promo.ppm", argv[2]);
    write_ppm(path);

    /* game over */
    ChessApp o = app;
    position_from_fen(&o.g.pos, "3k4/3Q4/3K4/8/8/8/8/8 b - - 0 1");
    o.g.key[0] = o.g.pos.hash;
    o.g.ply = 0;
    o.status = game_status(&o.g);
    o.screen = SCREEN_GAME_OVER;
    ui_render(platform_screen(), &o);
    snprintf(path, sizeof(path), "%s/05_gameover.ppm", argv[2]);
    write_ppm(path);
    return 0;
  }
  return 1;
}
