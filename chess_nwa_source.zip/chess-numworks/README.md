# Chess for NumWorks N0120 (`.nwa` external app)

A complete, playable human-vs-computer chess game for the NumWorks N0120
graphing calculator, packaged as an external EADK app (`chess.nwa`).

* full legal move generation (castling, en passant, promotion, pins, check
  evasion), all draw rules
* alpha-beta engine with iterative deepening, quiescence, MVV-LVA, killer
  moves, a bounded transposition table, 5 difficulty levels
* original piece artwork and a 5x7 font drawn by this project's own code
* ~4,900 lines of C99, no dynamic memory, no floating point, no libc I/O on the
  device
* the same engine also builds as a native PC binary for perft/strength tests

![the game running in the Epsilon simulator](docs/screenshot_game.png)
![the menu](docs/screenshot_menu.png)

*Both screenshots are the real `.nwb` app running in NumWorks' own Epsilon
simulator (see `tests/sim/README.md`).*

Everything here is MIT licensed (see `LICENSE`). No third-party engine, font or
piece graphics were copied; see *Credits* below.

---

## 1. Build

### Native (PC) build - rules, engine and UI tests

```sh
make             # -> build/chess_native and build/ui_test
make test        # self-tests, full perft suite, fuzz, save/load, UI stress
make test-quick  # the same, with perft capped at depth 4 (a few seconds)
```

Requirements: `gcc`, `make`. No other dependencies.

Commands:

| command | what it does |
|---|---|
| `build/chess_native selftest` | 24 rule edge cases (castling through check, e.p. exposing the king, promotion with capture, draws, SAN, undo integrity) |
| `build/chess_native perft [depth]` | the standard perft suite: startpos to depth 6 (119,060,324 nodes) and Kiwipete/positions 3-6 plus a mirrored position 4 to depth 5 - 37 depths, all verified |
| `build/chess_native fuzz <games> <plies>` | random-play make/unmake integrity check |
| `build/ui_test saveload <path>` | save/load round-trip through the FEN, plus corrupt-file rejection |
| `build/ui_test stress <dir>` | 20,000 random key events + promotion-dialog stress, asserting screen/state invariants |
| `build/ui_test tour <dir>` | render the UI screens to PPM files |
| `build/ui_test enginegame <dir>` | play a scripted game against the engine and dump frames |
| `build/chess_native divide <d> [fen]` | perft divide for debugging |
| `build/chess_native bench` | node/time measurement |
| `build/chess_native bestmove "<fen>" <ms>` | think once and print the move in SAN |
| `build/chess_native selfplay <games> <ms>` | engine vs itself, verifying every move is legal |
| `build/chess_native match <msA> <msB> <games>` / `levelmatch` | engine games at two time controls |
| `build/chess_native depthmatch <dA> <dB> <games>` | depth-capped strength separation (what the levels really do) |
| `build/chess_native play` | tiny ASCII interface (`e2e4`, `c` = let the engine move, `u` = undo) |

### Calculator build - `chess.nwa`

```sh
make nwa         # -> output/chess.nwa  (device build)
make nwb         # -> output/chess.nwb  (Epsilon simulator build)
```

Requirements: `arm-none-eabi-gcc` (newlib), `node` + `npm`. `nwlink` (the
official NumWorks SDK: `eadk.h`, linker flags, icon converter) is fetched
automatically by `npx`.

## 2. Install on the calculator

1. Copy `output/chess.nwa` to your computer.
2. Connect the N0120 by USB and wait for the *calculator connected* screen.
3. Open <https://my.numworks.com/apps>, sign in, and drop `chess.nwa` in the
   uploader (WebUSB). Alternatively, with the calculator connected you can run
   `make -C src/platform install` (uses `nwlink install-nwa`).
4. A *third-party applications* message appears on the device; **Chess** is
   then at the end of the home menu.

The app requires firmware that accepts external apps (any official Epsilon 16+
build does for the N0120; exam mode hides it).

## 3. Controls

Only the d-pad, OK, Back and Home are needed. See `src/app/keys.h` - all
bindings live in that one header.

| key | meaning |
|---|---|
| arrows | move the board cursor |
| OK | select the piece under the cursor, then OK on the destination to play |
| OK on the selected piece | deselect |
| Back | cancel the selection; with nothing selected, ask "leave the game?" |
| Home | **exits the app** (firmware behaviour, not ours - see `src/app/keys.h`) |
| EXE (toolbox/"menu") | open the game menu |
| Back while the engine thinks | stop thinking, play the best move found so far |

On-screen highlights: blue frame = cursor, red frame = selected piece, green
dots/frames = legal destinations, green tint = last move, red frame = king in
check.

Menu (EXE): new game, play as white/black/two players, level 1-5, flip board,
undo move, resign, draw (offered only when the position is drawish by the
repetition or 50-move counter), save/load, exit.

## 4. Difficulty levels

| level | max depth | time limit | what it is |
|---|---|---|---|
| 1 | 1 ply | 2 s | takes hanging material, no lookahead - beginners |
| 2 | 2 plies | 3 s | casual beginner |
| 3 | 3 plies | 4 s | casual |
| 4 | 6 plies | 5 s | club-ish |
| 5 | unlimited | 8 s | strongest, purely time bounded |

Levels are **depth-capped first**: on the N0120 the search reaches roughly
10-12 plies within a second, so time alone would not separate the levels. The
time limit is a safety net (a hard cap; the move played is always the best one
from the last completed iteration, and Back interrupts it). At every level a
slightly randomised first move is *not* used - the game is deterministic apart
from which equal-scoring move the move ordering happens to surface first.

## 5. Engine design

See `BUILD_REPORT.md` for the measured flash/RAM footprint, perft results and
the list of open, unverified items.

* **Board**: 12x16 mailbox (192 bytes) with a permanent empty border, so
  knight/king/pawn offsets never wrap and sliding rays only need one bounds
  test. Zobrist hashing, incremental make/unmake.
* **Search**: iterative deepening alpha-beta, aspiration-free, with
  * principal variation at the root,
  * quiescence search over captures and promotions with a delta cutoff,
  * move ordering: TT move, promotions, MVV-LVA captures, killers, then a
    history table,
  * late-move reductions for quiet moves, null-move pruning, mate-distance
    pruning, twofold-repetition and 50-move detection inside the search.
* **Transposition table**: 512 entries x 12 bytes = 6 KiB, a fixed static
  array, always-replace-by-depth. No allocation at run time. (The table was
  trimmed from 32 KiB when the RAM budget turned out to be the binding
  constraint; the NPS cost is under 2% at these depths.)
* **Evaluation**: material + piece-square tables (Michniewski's public-domain
  "simplified evaluation" table shapes, hand-typed), bishop pair, doubled pawns,
  mid/endgame king tables. Integer only, no floats anywhere.
* **Constraints honoured**: no dynamic memory anywhere (`malloc` is never
  called), no floats, no libc I/O on the device, search depth capped at 24 with
  80-entry move lists so the stack is bounded - measured worst case ~12 KiB
  against a 32 KiB userland stack (`BUILD_REPORT.md`).

## 6. Known limitations

* **No game save on the calculator.** The EADK that external apps get exposes
  display, keyboard, timing, random and battery - there is **no file or flash
  storage API** (verified against `eadk.h`, see `BUILD_REPORT.md`). `Save/Load`
  therefore reports `n/a` on the device; the same code path is exercised on the
  native build, where it round-trips a 5-ply game through the FEN and rejects a
  truncated file. If a storage API ever appears, only
  `platform_storage_read/write` in `src/platform/platform_nwa.c` needs filling
  in - the app already saves a compact 1 KB move-list record.
* A draw offered from the menu is accepted by the engine only when the position
  is genuinely drawish: the position has already occurred twice, the 50-move
  counter is at 80+, little material is left, or material is insufficient.
  Otherwise the answer is "Draw refused". (Threefold repetition, stalemate,
  the 50-move rule and insufficient material all end the game automatically.)
* No opening book, no pondering, no endgame tablebases.
* The engine is a small alpha-beta search: a strong club player will beat
  levels 1-3 easily, and will usually beat level 5 too. It is not Stockfish.
* Exact usable RAM for an external app on the N0120 firmware is **UNVERIFIED**
  (see `BUILD_REPORT.md`); the build uses ~189 KiB of static RAM, of which
  150 KiB is the 320x240 RGB565 framebuffer the app must own.

## 7. Credits and licence

* Engine, UI, font and piece artwork: original work for this project, MIT.
* Piece artwork is generated by `src/app/gfx.c` from primitive shapes; the font
  is authored as ASCII art in `tools/gen_font.py`. Both are original.
* Piece-square table *shapes* follow Tomasz Michniewski's public-domain
  "simplified evaluation function" published on the Chess Programming Wiki;
  the values were typed in by hand, no code was copied.
* Perft reference numbers: Chess Programming Wiki, `Perft Results`.
* `eadk.h` and the `.nwa` toolchain: NumWorks `nwlink` (BSD-3 for the sample
  code, tools under their own licences). `nwlink` is used as a build tool and
  is not redistributed here.
* "NumWorks" is a registered trademark of NumWorks SAS. This project is not
  affiliated with or endorsed by NumWorks.

MIT licence text: see `LICENSE`.
