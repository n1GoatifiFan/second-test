/* preview_pieces.c - renders every piece to a PPM image so the artwork can be
 * inspected (and converted to PNG) without touching a calculator.
 * Build: cc -O2 -Isrc tools/preview_pieces.c src/app/gfx.c -o build/preview_pieces
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "app/gfx.h"

#define CELL 96
#define PAD 6

static void to_ppm(Canvas *c, const char *path) {
  FILE *f = fopen(path, "wb");
  if (!f) return;
  fprintf(f, "P6\n%d %d\n255\n", c->w, c->h);
  for (int i = 0; i < c->w * c->h; i++) {
    color_t p = c->px[i];
    unsigned char r = (unsigned char)(((p >> 11) & 0x1F) * 255 / 31);
    unsigned char g = (unsigned char)(((p >> 5) & 0x3F) * 255 / 63);
    unsigned char b = (unsigned char)((p & 0x1F) * 255 / 31);
    fputc(r, f);
    fputc(g, f);
    fputc(b, f);
  }
  fclose(f);
}

int main(void) {
  const int N = 8;
  Canvas board = {0, CELL * N + PAD * 2, CELL * N + PAD * 2};
  board.px = malloc(sizeof(color_t) * board.w * board.h);
  canvas_clear(&board, RGB565(60, 60, 60));

  #define TRANSPARENT RGB565(255, 0, 255)
  color_t lightSq = RGB565(240, 217, 181);
  color_t darkSq = RGB565(181, 136, 99);

  Canvas cell = {0, 90, 90};
  static color_t cellpx[90 * 90];
  cell.px = cellpx;

  for (int side = 0; side < 2; side++) {
    for (int type = 1; type <= 6; type++) {
      int idx = (side * 6) + (type - 1);
      int cx = (idx % 6) * CELL + PAD;
      int cy = (idx / 6) * CELL + PAD;
      /* checkerboard background so both colours can be judged */
      for (int y = 0; y < CELL; y++)
        for (int x = 0; x < CELL; x++)
          board.px[(cy + y) * board.w + cx + x] = ((idx + side) & 1) ? lightSq : darkSq;
      for (int i = 0; i < 90 * 90; i++) cellpx[i] = TRANSPARENT;
      canvas_piece(&cell, type, side, side == 0 ? COL_WHITE : COL_BLACK,
                   side == 0 ? COL_BLACK : COL_WHITE);
      for (int y = 0; y < 90; y++)
        for (int x = 0; x < 90; x++) {
          color_t p = cellpx[y * 90 + x];
          if (p != TRANSPARENT) board.px[(cy + y) * board.w + cx + x] = p;
        }
    }
  }
  to_ppm(&board, "build/pieces.ppm");
  printf("wrote build/pieces.ppm (%dx%d)\n", board.w, board.h);
  free(board.px);
  return 0;
}
