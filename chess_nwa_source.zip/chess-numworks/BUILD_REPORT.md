# BUILD_REPORT - Chess for NumWorks N0120

Everything below was measured in this project's sandbox (Debian, x86-64 host,
`arm-none-eabi-gcc` for the device build). Anything that could not be verified
is labelled **UNVERIFIED** and is never presented as a result.

---

## 1. Target constraints (with sources)

| Item | Value | Source |
|---|---|---|
| SoC | STM32H725, Cortex-M7 @ 550 MHz, single precision FPU | <https://en.wikipedia.org/wiki/NumWorks>, ST datasheet |
| RAM | 564 KiB total SRAM (128 KiB DTCM + 432 KiB AXI + 64 KiB ITCM) | ST datasheet `stm32h725zg.pdf` |
| Display | 320x240, RGB565, so a full framebuffer is 153,600 B | `eadk.h` (nwlink 1.0.0) |
| External flash | 8 MiB QSPI (holds `.nwa` apps) | Wikipedia / NumWorks docs |
| Userland stack | 32 KiB (`UserlandStackLength = 0x8000`) | local Epsilon tree, `n0120/config/board.h` |
| App format | `.nwa` = ELF linked with the EADK linker script, entry `main`, symbols `eadk_app_name`, `eadk_app_icon`, `eadk_api_level` | `epsilon-sample-app-c`, `nwlink` |
| App API | display, keyboard (`eadk_keyboard_scan`, `eadk_event_get`), timing, backlight, battery, USB, `eadk_random`, `eadk_external_data`. **No file/flash storage API.** | `eadk.h` |
| Third-party apps | Allowed; hidden in exam mode; installed via <https://my.numworks.com/apps> or `nwlink install-nwa` | Epsilon `external_apps/README.md` |
| Home key | **Terminates** a running external app (`exit(0)`) | `epsilon/eadk/src/simulator.cpp` |
| RAM available to an external app | **UNVERIFIED** - see §6 | - |

The Home-key behaviour drove a design decision: the menu is on **EXE**, not
Home (`src/app/keys.h` documents this).

## 2. Flash / RAM footprint

Device build (`src/platform/Makefile`, `make nwa`), LTO **off** so the linker can
attribute sizes per object (the shipped `.nwa` is built with LTO and is
smaller):

| object | text | bss |
|---|---|---|
| src/chess/chess.o | 5,476 | 8,849 |
| src/chess/eval.o | 1,368 | 0 |
| src/chess/search.o | 3,054 | 13,528 |
| src/app/app.o | 3,708 | 5,901 |
| src/app/ui.o | 3,472 | 1,840 |
| src/app/gfx.o | 2,544 | 2,036 |
| src/app/font5x7.o | 576 | 0 |
| src/platform/main_nwa.o | 150 | 7,608 |
| src/platform/platform_nwa.o | 215 | 153,612 |
| **total** | **20,563** | **193,374** |

* Static RAM = `data + bss` = **193,378 B (~189 KiB)**, of which **153,600 B is
  the framebuffer** the app owns (`eadk_color_t framebuffer[320*240]`).
  Excluding the framebuffer the app needs ~39 KiB.
* Shipped artefact: **`output/chess.nwa` = 135,332 B** (LTO on; the sample app
  in `epsilon-sample-app-c` is 212 KB, so the ~200 KB class of apps is normal).
* `output/chess.nwb` (simulator build) = 198,856 B.
* Reduction history: the first working build had a 307 KB bss - a 153,600 B
  shadow framebuffer pushed every frame plus a 32 KiB TT. Both were removed
  (single `eadk_display_push_rect` per frame from the one framebuffer; TT
  trimmed to 512 entries = 6,144 B), and `MAX_HISTORY` was cut from 1024 to 256
  plies so the game record is 4,828 B instead of 18,652 B.

### Stack

`arm-none-eabi-gcc -fstack-usage` (Cortex-M7, `-Os`):

| function | frame |
|---|---|
| `root_search` | 1,328 B |
| `alphabeta` | 800 B |
| `qsearch` | 752 B |
| `ui` `draw_panel` | 600 B |
| `ui_render` | 120 B |

Worst case search stack = 1,328 + 22 x 800 (`MAX_PLY` 24) + 10 x 752
(`QS_EXTRA` 10) ≈ **12.0 KiB**, comfortably inside the 32 KiB userland stack,
and the UI frames are nested outside the search so they do not add up with it.

This was a real bug found by the measurement: the original search had 1,152 B /
1,104 B frames with 128-entry move arrays and `MAX_PLY 64`, i.e. ~146 KiB of
worst-case stack - a guaranteed overflow. `MAX_PLY 24`, `QS_EXTRA 10`,
`MAX_MOVES 80` and `int16_t` score arrays fixed it.

## 3. Correctness: perft

`make test` output (full log: `build/test_log.txt`):

```
startpos       1             20             20       0ms       OK
startpos       2            400            400       0ms       OK
startpos       3           8902           8902       2ms       OK
startpos       4         197281         197281      46ms       OK
startpos       5        4865609        4865609    1175ms       OK
startpos       6      119060324      119060324   28874ms       OK
...
pos6           5      164075551      164075551   36593ms       OK

perft: 37 depths OK, 0 failures
```

37/37 depths match the published counts from the Chess Programming Wiki,
covering: the start position, Kiwipete, positions 3-6 (position 4 also mirrored
to catch move-generator asymmetries), i.e. castling, en passant, promotions,
pins, discovered check and double check are all exercised.

Throughput (native x86-64, single thread):

| case | depth | nodes | time | rate |
|---|---|---|---|---|
| startpos | 6 | 119,060,324 | 28.9 s | 4.1 Mn/s |
| pos6 | 5 | 164,075,551 | 36.6 s | 4.5 Mn/s |
| pos5 | 5 | 89,941,194 | 22.5 s | 4.0 Mn/s |
| kiwipete | 5 | 193,690,690 | - | ~4 Mn/s |

The engine is ~540-600 Kn/s on the same host with move ordering and the TT
active (`bench`), which is the number that matters for search speed.

## 4. Other tests (all green)

| test | result |
|---|---|
| `selftest` (24 rule edge cases: castling through/into check, e.p. exposing the king, promotion-with-capture, all draw conditions, FEN round-trip, undo integrity) | **0 failures** |
| `fuzz 20 200` (random play, make/unmake integrity, king-safety invariants) | **3,878 checks, 0 errors** |
| `ui_test stress` (20,000 random key events + 16 forced promotion dialogs) | **OK**, screens visited: play 10,823 / menu 2,124 / exit 3,292 / over 3,292 / msg 469 |
| `ui_test saveload` | **OK** - 5-ply game saved, state wiped, reloaded, identical FEN; corrupt file rejected |
| `ui_test draws` | **OK** - opening draw offer refused, threefold repetition auto-detected at ply 8, 50-move offer accepted |
| `ui_test enginegame` | 24-ply scripted game, move list consistent |
| `selfplay 2 300` | 2 games, **0 illegal moves**, both decisive |
| `depthmatch` ladder | depth 1 vs 3: 0-3-3; depth 2 vs 4: 0-3-3; depth 1 vs 6: 0-0-4 (see §7) |
| 32-bit host build (`gcc -m32`) | selftest 0 failures, perft (depth ≤ 4) 28/28 - same struct layouts as the device |
| Real app in the Epsilon simulator | see §5 |

## 5. Verification in the real app (Epsilon simulator)

The `.nwb` build was run in Epsilon's own simulator (the same EADK
implementation as the calculator, `PLATFORM=simulator`), headless under Xvfb,
driven by `.nwt` scripted key events:

```
xvfb-run -a epsilon.bin --nwb output/chess.nwb --headless \
    --load-state-file s.nwt --take-screenshot shot.png
```

Screenshots captured and inspected (kept in `build/sim/`):

| scenario | keys | result |
|---|---|---|
| start | none | board + pieces + "CHESS / You: white / Menu: EXE" correct |
| select | OK | cursor on e2, selection frame, 2 legal-move dots |
| play | OK Up Up OK | 1.e4 played, **engine replied 1...e6**, move list "1.e4 e6", last-move + cursor highlights |
| menu | EXE, Down, Right | menu drawn, "Play as black" selected, board flipped, save/load shown as "n/a" |
| level | EXE x2, Down, Right, Down*4, OK | level changed 3 -> 4, confirmed in the panel |
| draw | ... Draw, OK | "GAME OVER / Draw agreed", footer matches |
| exit | ... Exit, OK | "Leave the game?" prompt; OK accepts and the app **returns cleanly** (simulator exits 0) |
| illegal | move a black piece as white | "Not Your Piece" feedback, no crash |
| resign | EXE ... Resign, OK | "GAME OVER / White resigned" |
| draw (opening) | EXE ... Draw, OK | "Draw refused" - the engine only agrees when the position is drawish |

The earlier "segmentation fault" seen in this harness was **not** an app bug: it
is a state-file loader bug in the simulator when a key name in the `.nwt` is not
one of its 233 known names (I had typed `Exe` instead of `EXE`). Reproduced with
`gdb`: crash inside `Ion::Simulator::StateFile::load`.

What the simulator does *not* prove: real Cortex-M7 timing, real RAM limits, and
flash install on hardware. Those are listed as unverified below.

## 6. Open issues / UNVERIFIED items

1. **RAM window for external apps on the N0120: UNVERIFIED.** Attempts to read it
   from the Epsilon device build failed: `make userland.elf` refuses ("Kernel
   and userland need to know their slot"), the LTO build of `userland.A.elf` was
   OOM-killed by the linker, and the non-LTO one produced a 102 MB non-ELF
   artefact with no `\x7fELF` magic - unusable. The app's requirement is
   ~189 KiB of static RAM (150 KiB framebuffer + ~39 KiB). The 153,600 B
   framebuffer is unavoidable: the EADK offers no other way to draw. **If the
   firmware gives external apps less than ~190 KiB, this app will not start** -
   that is a hard limit, not something the app can work around. The `.nwa`
   links successfully against the published EADK linker script, and the
   simulator build runs, but the simulator does not enforce the device limit.
2. **No on-device save/load**, because there is no storage API in EADK (verified
   in `eadk.h`). The menu says `n/a`. The code path is implemented and tested on
   the host; only two platform stubs would need filling.
3. **Not tested on physical hardware.** No N0120 was available in the sandbox:
   installation was verified only by producing a well-formed `.nwa` (correct
   EADK symbols, icon, API level) - the same recipe as the official sample app.
4. **Strength**: the engine is a small alpha-beta + quiescence search with a
   6 KiB TT and no book. Levels 1-3 are deliberately weak; level 5 is a decent
   club opponent at best, not an engine that will trouble a strong player.
5. Draw offers: the "is the position drawish?" test initially used
   `abs(eval_material())`, which is the white-minus-black *balance* and is 0 in
   the opening - so a draw could be claimed on move 1. It now uses the total
   material still on the board plus the repetition and 50-move counters, and
   `ui_test draws` covers all three paths.
6. Search quality bug found and fixed during level testing: the null-move branch
   flipped the side without updating the Zobrist key, so TT probes and
   repetition detection saw stale positions - depth 6 was losing to depth 1
   because of it. Fixed with `make_null()`; the level ladder is monotonic now
   (§4).
7. Font bug found and fixed: the generated table had 94 glyphs (code 96, the
   backtick, was missing), so every character from '`' upwards rendered one
   glyph early ("CHESS" appeared as "XjufE"). The table is now contiguous
   32-126 (95 glyphs) and `font5x7_glyph()` verifies the stored ASCII code
   before using the direct index.

## 7. Time per move per level

The shipped levels are depth-capped (see README §4). Native timings are
indicative; the device is a 550 MHz M7 with no cache on the internal SRAM path,
expect roughly an order of magnitude fewer nodes/second than the x86 host.

| level | depth cap | time cap | native observed |
|---|---|---|---|
| 1 | 1 | 2 s | < 1 ms |
| 2 | 2 | 3 s | ~6 ms |
| 3 | 3 | 4 s | ~0.17 s/game-move |
| 4 | 6 | 5 s | ~0.6 s/game-move |
| 5 | - | 8 s | USES the time cap on device |

On the host, from the start position: 120 ms -> depth 9, 1 s -> depth 12,
5 s -> depth 12 (12, 4.5 Mn/s branch-limited). On the device the reachable
depth is time-bound; the exact number is **UNVERIFIED** (no hardware), but at
the measured ~540 Kn/s host rate the app is well inside its budget because the
time limit is enforced with `eadk_millis()` polling every 1,024 nodes.

## 8. Artefact checks (`output/chess.nwa`)

```
$ arm-none-eabi-readelf -h output/chess.nwa
Class: ELF32   Type: REL (Relocatable file)   Machine: ARM (EABI5)
$ arm-none-eabi-nm output/chess.nwa
00000000 T main
00000000 R eadk_app_name
00000000 R eadk_api_level
00000000 D eadk_app_icon
$ arm-none-eabi-nm -u output/chess.nwa
         w __sf / _printf_float
         U _sbrk
         U eadk_display_push_rect
         U eadk_event_get
         U eadk_timing_millis
```

The app imports only three EADK entry points plus `_sbrk`/`printf` from newlib
nano (nothing else from libc is reachable at run time thanks to
`--gc-sections`). It does not import `eadk_keyboard_scan`, `eadk_random` or any
storage function. Size: **135,332 B**, md5 `0b1e6e3e1f2d5b9523e462bc1a0aabd5`
(reproducible: rebuilding gives the identical hash).

## 9. Reproducing

```sh
make test          # native: selftest + 37-depth perft + fuzz + save/load + UI stress
make test-quick    # the same with perft capped at depth 4 (5 s)
make nwa           # output/chess.nwa (needs arm-none-eabi-gcc + node/npm)
make nwb           # output/chess.nwb (Epsilon simulator build)
```

Toolchain flags used for the device (from `src/platform/Makefile`):

```
CFLAGS  = -std=c99 -Os -Wall $(npx nwlink eadk-cflags-device)
LDFLAGS = $(npx nwlink eadk-ldflags-device) --specs=nano.specs \
          -Wl,-e,main -Wl,-u,eadk_app_name -Wl,-u,eadk_app_icon \
          -Wl,-u,eadk_api_level -Wl,-gc-sections -flinker-output=nolto-rel
```
