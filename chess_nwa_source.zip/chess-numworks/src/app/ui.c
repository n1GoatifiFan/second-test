/* ui.c - all drawing for the chess app.
 *
 * Layout (320x240, RGB565):
 *
 *   +------------------------------------------------------+
 *   | title bar                                            |
 *   | +----------------------+ +-------------------------+ |
 *   | |                      | | side panel              | |
 *   | |   8 x 8 board        | | - side to move          | |
 *   | |   (28 px squares)    | | - level / thinking      | |
 *   | |                      | | - move list (scroll)    | |
 *   | |                      | | - captured pieces       | |
 *   | +----------------------+ +-------------------------+ |
 *   | status bar                                           |
 *   +------------------------------------------------------+
 *
 * MIT licensed. All geometry is integer arithmetic.
 */
#include "ui.h"
#include "gfx.h"
#include "keys.h"

#include <string.h>
#include <stdio.h>

/* ---- palette ------------------------------------------------------------ */
static const color_t C_HDR_BG = RGB565(24, 32, 54);
static const color_t C_HDR_FG = RGB565(238, 238, 246);
static const color_t C_LIGHT = RGB565(238, 220, 190);
static const color_t C_DARK = RGB565(160, 112, 76);
static const color_t C_LIGHT_HI = RGB565(196, 214, 128); /* last move / selection on light */
static const color_t C_DARK_HI = RGB565(150, 172, 70);
static const color_t C_CURSOR = RGB565(40, 90, 220);
static const color_t C_LEGAL = RGB565(70, 150, 90);
static const color_t C_PANEL_BG = RGB565(232, 230, 224);
static const color_t C_PANEL_FG = RGB565(20, 20, 24);
static const color_t C_ACCENT = RGB565(170, 30, 40);
static const color_t C_CHECK = RGB565(216, 60, 46);
static const color_t C_STATUS_BG = RGB565(36, 44, 64);
static const color_t C_STATUS_FG = RGB565(240, 240, 240);
static const color_t C_WHITE_PIECE = RGB565(250, 250, 250);
static const color_t C_BLACK_PIECE = RGB565(24, 24, 28);

static Canvas *g_c;

/* menu labels, shared with app.c through a tiny accessor */
static const char *kMenuLabelTable[9] = {"New game", "Play as", "Level", "Flip board", "Undo move",
                                         "Resign", "Draw", "Save game", "Exit"};
static const char *kMenuLabel(int i) { return kMenuLabelTable[i]; }
static color_t g_cellbuf[CELL * CELL];

/* ---- small helpers ------------------------------------------------------ */
static void fill(Canvas *c, int x, int y, int w, int h, color_t col) {
  canvas_rect(c, x, y, w, h, col);
}

/* Text with a background colour (5x7 font, scale 1 or 2). */
static void text_bg(Canvas *c, int x, int y, const char *s, color_t fg, color_t bg, int sc) {
  int w = canvas_text_width(s, sc);
  fill(c, x - 1, y - 2, w + 2, 7 * sc + 4, bg);
  canvas_text(c, x, y, s, fg, sc);
}

static void text(Canvas *c, int x, int y, const char *s, color_t fg, int sc) {
  canvas_text(c, x, y, s, fg, sc);
}

static void piece_into_cell(Canvas *c, int x, int y, int type, int side) {
  Canvas cell;
  cell.px = g_cellbuf;
  cell.w = CELL;
  cell.h = CELL;
  memset(g_cellbuf, 0, sizeof(g_cellbuf));
  canvas_piece(&cell, type, side, side == WHITE ? C_WHITE_PIECE : C_BLACK_PIECE,
               side == WHITE ? C_BLACK_PIECE : C_WHITE_PIECE);
  for (int yy = 0; yy < CELL; yy++) {
    for (int xx = 0; xx < CELL; xx++) {
      color_t p = g_cellbuf[yy * CELL + xx];
      if (p) c->px[(y + yy) * c->w + (x + xx)] = p;
    }
  }
}

/* ---- board -------------------------------------------------------------- */
static void draw_square_bg(const ChessApp *a, int sq, int x, int y) {
  int f = FILE_OF(sq), r = RANK_OF(sq);
  bool light = ((f + r) & 1) != 0;
  color_t base = light ? C_LIGHT : C_DARK;
  /* highlight last move */
  if (a->hasLast && (sq == a->lastFrom || sq == a->lastTo))
    base = light ? C_LIGHT_HI : C_DARK_HI;
  fill(g_c, x, y, CELL, CELL, base);
  /* king in check */
  if (a->checkKingSq != NO_SQUARE && sq == a->checkKingSq) {
    for (int i = 0; i < CELL; i += 2) {
      fill(g_c, x + i, y, 1, CELL, C_CHECK);
      fill(g_c, x, y + i, CELL, 1, C_CHECK);
    }
  }
  /* selection */
  if (a->hasSelection && sq == a->selFrom) {
    for (int i = 0; i < CELL; i += 2) {
      fill(g_c, x, y + i, CELL, 1, C_ACCENT);
      fill(g_c, x + i, y, 1, CELL, C_ACCENT);
    }
  }
  /* legal destination marker */
  if (a->hasSelection && app_legal_dest(a, sq)) {
    bool occupied = a->g.pos.board[sq] != 0;
    if (occupied) {
      for (int i = 0; i < CELL; i += 2) {
        fill(g_c, x + i, y, 1, CELL, C_LEGAL);
        fill(g_c, x, y + i, CELL, 1, C_LEGAL);
      }
    } else {
      for (int dy = -3; dy <= 3; dy++)
        for (int dx = -3; dx <= 3; dx++)
          if (dx * dx + dy * dy <= 9) fill(g_c, x + CELL / 2 + dx, y + CELL / 2 + dy, 1, 1, C_LEGAL);
    }
  }
  /* cursor */
  if (sq == a->cursor) {
    for (int i = 0; i < CELL; i++) {
      fill(g_c, x + i, y, 1, 2, C_CURSOR);
      fill(g_c, x + i, y + CELL - 2, 1, 2, C_CURSOR);
      fill(g_c, x, y + i, 2, 1, C_CURSOR);
      fill(g_c, x + CELL - 2, y + i, 2, 1, C_CURSOR);
    }
  }
}

static void draw_board(const ChessApp *a) {
  /* thin frame */
  fill(g_c, BOARD_ORIGIN_X - 1, BOARD_ORIGIN_Y - 1, BOARD_PX + 2, BOARD_PX + 2, C_HDR_BG);
  for (int row = 0; row < 8; row++) {
    for (int col = 0; col < 8; col++) {
      int sq = app_square_at(a, row, col);
      draw_square_bg(a, sq, BOARD_ORIGIN_X + col * CELL, BOARD_ORIGIN_Y + row * CELL);
    }
  }
  /* pieces */
  for (int row = 0; row < 8; row++) {
    for (int col = 0; col < 8; col++) {
      int sq = app_square_at(a, row, col);
      uint8_t pc = a->g.pos.board[sq];
      if (!pc) continue;
      piece_into_cell(g_c, BOARD_ORIGIN_X + col * CELL, BOARD_ORIGIN_Y + row * CELL, TYPE(pc),
                      SIDE(pc));
    }
  }
  /* file / rank labels */
  for (int i = 0; i < 8; i++) {
    char s[2] = {0, 0};
    /* files below the board */
    int f = a->flip ? (7 - i) : i;
    s[0] = (char)('a' + f);
    text(g_c, BOARD_ORIGIN_X + i * CELL + CELL / 2 - 3, FILE_LABEL_Y, s, C_HDR_FG, 1);
    /* ranks to the left */
    int r = a->flip ? i : (7 - i);
    s[0] = (char)('1' + r);
    text(g_c, 2, BOARD_ORIGIN_Y + i * CELL + CELL / 2 - 3, s, C_HDR_FG, 1);
  }
}

/* ---- side panel --------------------------------------------------------- */
static void draw_panel(const ChessApp *a) {
  const int x = PANEL_X, w = PANEL_W;
  fill(g_c, x, BOARD_ORIGIN_Y, w, STATUS_Y - BOARD_ORIGIN_Y, C_PANEL_BG);
  int y = BOARD_ORIGIN_Y + 3;
  char buf[24];

  /* side to move */
  const char *turn = a->g.pos.side == WHITE ? "WHITE" : "BLACK";
  text(g_c, x + 3, y, turn, C_ACCENT, 1);
  text(g_c, x + 3 + canvas_text_width(turn, 1) + 3, y, "to move", C_PANEL_FG, 1);
  y += 11;

  /* opponent / level / thinking */
  if (a->humanSide < 0) {
    text(g_c, x + 3, y, "2 players", C_PANEL_FG, 1);
  } else if (a->thinking) {
    text(g_c, x + 3, y, "Thinking", C_ACCENT, 1);
    int dots = (int)((a->thinkNodes >> 9) % 4);
    for (int i = 0; i < dots; i++) fill(g_c, x + 3 + 44 + i * 4, y + 6, 2, 2, C_ACCENT);
    snprintf(buf, sizeof(buf), "d%d", a->thinkDepth);
    text(g_c, x + 3, y + 9, buf, C_PANEL_FG, 1);
  } else {
    snprintf(buf, sizeof(buf), "Level %d", a->level);
    text(g_c, x + 3, y, buf, C_PANEL_FG, 1);
    if (a->thinkMillis) {
      snprintf(buf, sizeof(buf), "d%d %u.%us", a->thinkDepth, (unsigned)(a->thinkMillis / 1000),
               (unsigned)((a->thinkMillis % 1000) / 100));
      text(g_c, x + 3, y + 9, buf, C_PANEL_FG, 1);
    }
  }
  y += 21;

  /* captured pieces */
  fill(g_c, x, y - 3, w, 1, C_DARK);
  text(g_c, x + 3, y, "CAPTURED", C_PANEL_FG, 1);
  y += 10;
  for (int side = 0; side < 2; side++) {
    int n = side == WHITE ? a->capturedByWhiteN : a->capturedByBlackN;
    const uint8_t *list = side == WHITE ? a->capturedByWhite : a->capturedByBlack;
    text(g_c, x + 3, y + 2, side == WHITE ? "Y:" : "O:", C_PANEL_FG, 1);
    int px = x + 13;
    for (int i = 0; i < n && i < 10; i++) {
      if (px + 11 > x + w - 2) break;
      Canvas cell;
      static color_t buf[11 * 11];
      cell.px = buf;
      cell.w = 11;
      cell.h = 11;
      memset(buf, 0, sizeof(buf));
      uint8_t pc = list[i];
      canvas_piece(&cell, TYPE(pc), SIDE(pc), SIDE(pc) == WHITE ? C_WHITE_PIECE : C_BLACK_PIECE,
                   SIDE(pc) == WHITE ? C_BLACK_PIECE : C_WHITE_PIECE);
      for (int yy = 0; yy < 11; yy++)
        for (int xx = 0; xx < 11; xx++) {
          color_t p = buf[yy * 11 + xx];
          if (p) g_c->px[(y + yy) * g_c->w + (px + xx)] = p;
        }
      px += 10;
    }
    y += 12;
  }

  /* move list */
  fill(g_c, x, y - 2, w, 1, C_DARK);
  y += 1;
  const int maxLines = (STATUS_Y - 1 - y) / 9;
  char lines[28][18];
  int nLines = 0;
  {
    int i = 0;
    while (i < a->movetextLen && nLines < 28) {
      int j = 0;
      while (i < a->movetextLen && j < 14) {
        if (a->movetext[i] == ' ' && j > 11) break;
        lines[nLines][j++] = a->movetext[i++];
      }
      lines[nLines][j] = 0;
      nLines++;
    }
  }
  int first = nLines - maxLines;
  if (first < 0) first = 0;
  for (int i = 0; i < maxLines && first + i < nLines; i++)
    text(g_c, x + 3, y + i * 9, lines[first + i], C_PANEL_FG, 1);
  if (nLines == 0) text(g_c, x + 3, y, "1.", C_PANEL_FG, 1);
}

/* ---- header / status ---------------------------------------------------- */
static void draw_header(const ChessApp *a) {
  fill(g_c, 0, 0, SCREEN_W, 13, C_HDR_BG);
  text(g_c, 3, 3, "CHESS", C_HDR_FG, 1);
  const char *lv = a->humanSide < 0 ? "2 players" : a->humanSide == WHITE ? "You: white" : "You: black";
  text(g_c, 46, 3, lv, C_HDR_FG, 1);
  char buf[16];
  snprintf(buf, sizeof(buf), "Menu: " KEYMAP_MENU_LABEL);
  text(g_c, SCREEN_W - canvas_text_width(buf, 1) - 3, 3, buf, C_HDR_FG, 1);
  (void)lv;
}

static void draw_status(const ChessApp *a) {
  fill(g_c, 0, STATUS_Y, SCREEN_W, SCREEN_H - STATUS_Y, C_STATUS_BG);
  char buf[40];
  if (a->thinking) {
    snprintf(buf, sizeof(buf), "Thinking... %s stops (d%d %u n)", KEYMAP_CANCEL_LABEL,
             a->thinkDepth, (unsigned)a->thinkNodes);
  } else {
    snprintf(buf, sizeof(buf), "%s", app_status_text(a));
  }
  text(g_c, 3, STATUS_Y + 2, buf, C_STATUS_FG, 1);
}

/* ---- overlays ----------------------------------------------------------- */
static void window_box(int x, int y, int w, int h, color_t bg, color_t border) {
  fill(g_c, x - 1, y - 1, w + 2, h + 2, border);
  fill(g_c, x - 2, y - 2, w + 4, h + 4, C_HDR_BG);
  fill(g_c, x, y, w, h, bg);
}

static void draw_menu(const ChessApp *a) {
  const int w = 156, h = 14 + 9 * 11 + 14;
  const int x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
  window_box(x, y, w, h, C_PANEL_BG, C_HDR_BG);
  text(g_c, x + 4, y + 4, "MENU", C_ACCENT, 1);
  for (int i = 0; i < 9; i++) {
    int yy = y + 14 + i * 11;
    bool sel = (i == a->menuIndex);
    if (sel) fill(g_c, x + 2, yy - 2, w - 4, 11, C_CURSOR);
    color_t fg = sel ? C_WHITE_PIECE : C_PANEL_FG;
    char label[28];
    /* value column for the settable entries */
    if (i == 1)
      snprintf(label, sizeof(label), "%-8s %s", kMenuLabel(i),
               a->humanSide < 0 ? "both" : a->humanSide == WHITE ? "white" : "black");
    else if (i == 2)
      snprintf(label, sizeof(label), "%-8s %d", kMenuLabel(i), a->level);
    else if (i == 7)
      snprintf(label, sizeof(label), "%-8s %s", "Save/Load", a->storageOk ? "ok" : "n/a");
    else
      snprintf(label, sizeof(label), "%s", kMenuLabel(i));
    text(g_c, x + 5, yy, label, fg, 1);
  }
  text(g_c, x + 4, y + h - 10, "OK do/change  Back", C_PANEL_FG, 1);
}

static void draw_promo(const ChessApp *a) {
  const int w = 96, h = 74;
  const int x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
  window_box(x, y, w, h, C_PANEL_BG, C_HDR_BG);
  text(g_c, x + 4, y + 4, "PROMOTE TO", C_ACCENT, 1);
  static const int order[4] = {QUEEN, ROOK, BISHOP, KNIGHT};
  static const char *names[4] = {"Queen", "Rook", "Bishop", "Knight"};
  for (int i = 0; i < 4; i++) {
    int yy = y + 16 + i * 13;
    bool sel = (i == a->promoIndex);
    if (sel) fill(g_c, x + 2, yy - 2, w - 4, 13, C_CURSOR);
    color_t fg = sel ? C_WHITE_PIECE : C_PANEL_FG;
    Canvas cell;
    static color_t buf[11 * 11];
    cell.px = buf;
    cell.w = 11;
    cell.h = 11;
    memset(buf, 0, sizeof(buf));
    int side = a->g.pos.side;
    canvas_piece(&cell, order[i], side, side == WHITE ? C_WHITE_PIECE : C_BLACK_PIECE,
                 side == WHITE ? C_BLACK_PIECE : C_WHITE_PIECE);
    for (int yy2 = 0; yy2 < 11; yy2++)
      for (int xx = 0; xx < 11; xx++) {
        color_t p = buf[yy2 * 11 + xx];
        if (p) g_c->px[(yy + 1 + yy2) * g_c->w + (x + 6 + xx)] = p;
      }
    text(g_c, x + 22, yy + 2, names[i], fg, 1);
  }
}

static void draw_confirm_exit(const ChessApp *a) {
  const int w = 150, h = 46;
  const int x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
  window_box(x, y, w, h, C_PANEL_BG, C_HDR_BG);
  text(g_c, x + 6, y + 8, "Leave the game?", C_PANEL_FG, 1);
  text(g_c, x + 6, y + 20, "OK = exit, " KEYMAP_CANCEL_LABEL " = keep", C_ACCENT, 1);
  text(g_c, x + 6, y + 32, "playing", C_ACCENT, 1);
  (void)a;
}

static void draw_game_over(const ChessApp *a) {
  const int w = 190, h = 60;
  const int x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
  window_box(x, y, w, h, C_PANEL_BG, C_HDR_BG);
  text(g_c, x + 6, y + 7, "GAME OVER", C_ACCENT, 2);
  text(g_c, x + 6, y + 26, app_status_text(a), C_PANEL_FG, 1);
  text(g_c, x + 6, y + 40, "OK new game  " KEYMAP_CANCEL_LABEL " menu", C_PANEL_FG, 1);
}

static void draw_message(const ChessApp *a) {
  const int w = 130, h = 30;
  const int x = (SCREEN_W - w) / 2, y = (SCREEN_H - h) / 2;
  window_box(x, y, w, h, C_PANEL_BG, C_HDR_BG);
  text(g_c, x + 6, y + 6, a->message, C_ACCENT, 1);
  text(g_c, x + 6, y + 18, "any key", C_PANEL_FG, 1);
}

void ui_render(Canvas *c, const ChessApp *a) {
  g_c = c;
  fill(c, 0, 0, SCREEN_W, SCREEN_H, C_HDR_BG);
  draw_header(a);
  draw_board(a);
  draw_panel(a);
  draw_status(a);
  switch (a->screen) {
    case SCREEN_MENU: draw_menu(a); break;
    case SCREEN_PROMO: draw_promo(a); break;
    case SCREEN_CONFIRM_EXIT: draw_confirm_exit(a); break;
    case SCREEN_GAME_OVER: draw_game_over(a); break;
    case SCREEN_MESSAGE: draw_message(a); break;
    default: break;
  }
}
