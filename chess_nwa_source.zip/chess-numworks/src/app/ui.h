/* ui.h - renderer for the chess app. Pure function of ChessApp state. */
#ifndef UI_H
#define UI_H

#include "game.h"
#include "../platform/platform.h"

void ui_render(Canvas *c, const ChessApp *a);

/* Geometry, shared with the input code and with the tests. */
#define BOARD_ORIGIN_X 9   /* leaves room for the rank labels */
#define BOARD_ORIGIN_Y 13
#define CELL 26
#define BOARD_PX (CELL * 8)                      /* 208 */
#define PANEL_X (BOARD_ORIGIN_X + BOARD_PX + 5)  /* 222 */
#define PANEL_W (SCREEN_W - PANEL_X - 3)         /* 95  */
#define STATUS_Y (SCREEN_H - 11)                 /* 229 */
#define FILE_LABEL_Y (BOARD_ORIGIN_Y + BOARD_PX + 1)
#endif
