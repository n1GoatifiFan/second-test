/* gfx.h - tiny software rasteriser and original piece artwork.
 *
 * All piece graphics in this project are drawn programmatically from the
 * primitives below (circles, rectangles, triangles). No bitmap or vector art
 * was copied from any other program: the shapes are original to this project
 * and are MIT licensed together with the rest of the code.
 */
#ifndef GFX_H
#define GFX_H

#include <stdint.h>
#include <stdbool.h>

typedef uint16_t color_t;

#define RGB565(r, g, b) ((color_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3)))

#define COL_BLACK RGB565(0, 0, 0)
#define COL_WHITE RGB565(255, 255, 255)

typedef struct {
  color_t *px;
  int w;
  int h;
} Canvas;

/* Canvas primitives (no clipping against the screen; the canvas bounds are
 * honoured). */
void canvas_clear(Canvas *c, color_t col);
void canvas_rect(Canvas *c, int x, int y, int w, int h, color_t col);
void canvas_circle(Canvas *c, int cx, int cy, int r, color_t col);
void canvas_triangle(Canvas *c, int x0, int y0, int x1, int y1, int x2, int y2, color_t col);
void canvas_trapezoid(Canvas *c, int y0, int y1, int xTopL, int xTopR, int xBotL, int xBotR,
                      color_t col);

/* Render one chess piece (type 1..6, side 0/1) into a size x size canvas.
 * `outline` is drawn around the silhouette, `fill` inside it. */
void canvas_piece(Canvas *c, int type, int side, color_t fill, color_t outline);

/* Text: 5x7 bitmap font (see tools/gen_font.py), scale 1 or 2. */
void canvas_char(Canvas *c, int x, int y, char ch, color_t col, int sc);
void canvas_text(Canvas *c, int x, int y, const char *s, color_t col, int sc);
int canvas_text_width(const char *s, int sc);

#endif
