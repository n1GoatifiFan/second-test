/* keys.h - THE keymap of the game. All bindings live in this one header.
 *
 * Verified constraint: on official Epsilon firmware, pressing Home while an
 * external app runs TERMINATES that app (epsilon/eadk/src/simulator.cpp calls
 * exit(0) on Ion::Events::Home). Home therefore cannot be the menu key, and
 * the UI is designed around the d-pad, OK, Back and EXE.
 *
 * --- in game -------------------------------------------------------------
 *   UP DOWN LEFT RIGHT   move the board cursor
 *   OK                   select the piece under the cursor, then OK on the
 *                        destination to play the move (OK on the selected
 *                        piece deselects it)
 *   BACK                 cancel the selection; with nothing selected it opens
 *                        the "leave the game?" confirmation
 *   EXE                  open the game menu
 *
 * --- in menus -------------------------------------------------------------
 *   UP DOWN              move the highlight
 *   LEFT RIGHT           change the value of the highlighted entry in place
 *   OK                   choose the highlighted entry
 *   BACK                 leave the menu
 *
 * --- promotion picker -----------------------------------------------------
 *   UP DOWN              cycle Q / R / B / N
 *   OK                   confirm
 *   BACK                 cancel the move
 *
 * --- while the engine thinks ---------------------------------------------
 *   BACK                 stop thinking and play the best move found so far
 *   EXE                  open the menu (the search is paused)
 */
#ifndef KEYS_H
#define KEYS_H

#define KEYMAP_CURSOR_UP KEY_UP
#define KEYMAP_CURSOR_DOWN KEY_DOWN
#define KEYMAP_CURSOR_LEFT KEY_LEFT
#define KEYMAP_CURSOR_RIGHT KEY_RIGHT
#define KEYMAP_SELECT KEY_OK
#define KEYMAP_CANCEL KEY_BACK
#define KEYMAP_MENU KEY_MENU /* EXE on the calculator */
#define KEYMAP_STOP_THINKING KEY_BACK

/* Labels shown on screen / in the README. */
#define KEYMAP_MENU_LABEL "EXE"
#define KEYMAP_CANCEL_LABEL "Back"
#define KEYMAP_SELECT_LABEL "OK"

#endif
