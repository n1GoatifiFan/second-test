/* app.c - UI state machine: cursor, selection, menus, engine hand-off.
 * No platform calls here except storage (guarded) and millis (for stats).
 * MIT licensed.
 */
#include "game.h"
#include "keys.h"
#include "../platform/platform.h"
#include "chess/search.h"
#include "chess/eval.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define MENU_ITEMS 9

/* `plyBefore` is the number of plies played before this move, so the move
 * number is plyBefore/2 + 1. */
static void append_san(ChessApp *a, const char *san, bool blackMove, int plyBefore) {
  int n = (int)strlen(san);
  int need = n + 2;
  if (a->movetextLen + need >= MAX_MOVETEXT - 1) return;
  /* keep the panel small: the move list is only a convenience read-out */
  if (a->movetextLen > 0) a->movetext[a->movetextLen++] = ' ';
  if (a->movetextLen > 0) a->movetext[a->movetextLen++] = ' ';
  if (!blackMove) {
    int moveNo = plyBefore / 2 + 1;
    if (moveNo >= 100) {
      a->movetext[a->movetextLen++] = (char)('0' + moveNo / 100);
      a->movetext[a->movetextLen++] = (char)('0' + (moveNo / 10) % 10);
      a->movetext[a->movetextLen++] = (char)('0' + moveNo % 10);
    } else if (moveNo >= 10) {
      a->movetext[a->movetextLen++] = (char)('0' + moveNo / 10);
      a->movetext[a->movetextLen++] = (char)('0' + moveNo % 10);
    } else {
      a->movetext[a->movetextLen++] = (char)('0' + moveNo);
    }
    a->movetext[a->movetextLen++] = '.';
  }
  memcpy(&a->movetext[a->movetextLen], san, (size_t)n);
  a->movetextLen += n;
  a->movetext[a->movetextLen] = 0;
}

static void update_check_square(ChessApp *a) {
  if (in_check(&a->g.pos)) a->checkKingSq = a->g.pos.kingSq[a->g.pos.side];
  else a->checkKingSq = NO_SQUARE;
}

static void set_status(ChessApp *a) {
  a->status = game_status(&a->g);
  if (a->status != STATUS_PLAYING) {
    a->screen = SCREEN_GAME_OVER;
  }
  update_check_square(a);
}

void app_init(ChessApp *a) {
  chess_init();
  search_init();
  memset(a, 0, sizeof(*a));
  a->humanSide = WHITE;
  a->level = 3;
  a->flip = 0;
  a->selFrom = NO_SQUARE;
  a->checkKingSq = NO_SQUARE;
  a->screen = SCREEN_PLAY;
  a->storageOk = platform_storage_available();
  app_new_game(a);
}

void app_new_game(ChessApp *a) {
  game_new(&a->g);
  a->status = STATUS_PLAYING;
  a->cursor = SQ_E2;
  a->selFrom = NO_SQUARE;
  a->hasSelection = false;
  a->hasLast = false;
  a->lastFrom = a->lastTo = 0;
  a->movetextLen = 0;
  a->movetext[0] = 0;
  a->movetextScroll = 0;
  a->capturedByWhiteN = 0;
  a->capturedByBlackN = 0;
  a->thinking = false;
  a->thinkDepth = 0;
  a->thinkScore = 0;
  a->thinkNodes = 0;
  a->thinkMillis = 0;
  a->thinkLine[0] = 0;
  a->screen = SCREEN_PLAY;
  a->menuIndex = 0;
  a->promoIndex = 0;
  a->undoUsed = 0;
  a->message[0] = 0;
  update_check_square(a);
  a->flip = (a->humanSide == BLACK);
}

void app_flip(ChessApp *a) { a->flip = !a->flip; }
void app_set_level(ChessApp *a, int level) {
  if (level < 1) level = 1;
  if (level > 5) level = 5;
  a->level = level;
}
void app_set_side(ChessApp *a, int side) {
  a->humanSide = side;
  a->flip = (side == BLACK);
}
void app_resign(ChessApp *a) {
  if (a->status != STATUS_PLAYING) return;
  a->g.sixteenStatus = STATUS_RESIGN;
  set_status(a);
  a->screen = SCREEN_GAME_OVER;
}
void app_agree_draw(ChessApp *a) {
  /* Draws are only offered under the repetition rules, as specified: the
   * two players agree to a draw, the engine accepts when the current
   * position has already occurred twice or the game is otherwise drawn. */
  if (a->status != STATUS_PLAYING) return;
  /* `eval_material` is the white-minus-black *balance*, so it is 0 in the
   * opening too - the "little material left" test must look at the total
   * amount on the board, not at the balance. */
  int total = 0;
  for (int sq = 0; sq < 128; sq++) {
    if (sq & 0x88) continue;
    int pc = a->g.pos.board[sq];
    if (pc == EMPTY) continue;
    switch (pc & 7) {
      case PAWN: total += 1; break;
      case KNIGHT: case BISHOP: total += 3; break;
      case ROOK: total += 5; break;
      case QUEEN: total += 9; break;
      default: break;
    }
  }
  bool drawish = repetition_count(&a->g) >= 2 || a->g.pos.halfmove >= 80 ||
                 insufficient_material(&a->g.pos) || total <= 6;
  if (drawish) {
    a->g.sixteenStatus = STATUS_DRAW_AGREED;
    set_status(a);
    a->screen = SCREEN_GAME_OVER;
  } else {
    snprintf(a->message, sizeof(a->message), "Draw refused");
    a->screen = SCREEN_MESSAGE;
  }
}

/* Levels are primarily depth limited: on the N0120 the engine reaches ~10-12
 * plies in a second, so a pure depth cap is what makes the weak levels weak
 * (and deterministic). The time limit is a safety net, generous enough not to
 * bind at the low levels. Level 5 is time limited only. */
int app_level_millis(int level) {
  switch (level) {
    case 1: return 2000;
    case 2: return 3000;
    case 3: return 4000;
    case 4: return 5000;
    case 5: return 8000;
    default: return 4000;
  }
}

int app_level_maxdepth(int level) {
  switch (level) {
    case 1: return 1;
    case 2: return 2;
    case 3: return 3;
    case 4: return 6;
    case 5: return 40; /* effectively unlimited: time decides */
    default: return 3;
  }
}

/* ---------------------------------------------------------------- helpers */
int app_display_pos(const ChessApp *a, int sq, int *row, int *col) {
  int f = FILE_OF(sq), r = RANK_OF(sq);
  if (f < 0 || f > 7 || r < 0 || r > 7) return 0;
  if (a->flip) {
    *row = f;
    *col = 7 - r;
  } else {
    *row = 7 - r;
    *col = f;
  }
  return 1;
}

int app_square_at(const ChessApp *a, int row, int col) {
  if (row < 0 || row > 7 || col < 0 || col > 7) return NO_SQUARE;
  if (a->flip) return SQ_FROM64((7 - col) * 8 + row);
  return SQ_FROM64((7 - row) * 8 + col);
}

bool app_legal_dest(const ChessApp *a, int sq) {
  if (!a->hasSelection) return false;
  MoveList l;
  generate_legal((Position *)&a->g.pos, &l);
  for (int i = 0; i < l.n; i++)
    if (l.m[i].from == a->selFrom && l.m[i].to == sq) return true;
  return false;
}

static bool is_promotion(const ChessApp *a, int from, int to) {
  MoveList l;
  generate_legal((Position *)&a->g.pos, &l);
  for (int i = 0; i < l.n; i++)
    if (l.m[i].from == from && l.m[i].to == to && (l.m[i].flags & FLAG_PROMO)) return true;
  return false;
}

static void record_capture(ChessApp *a, uint8_t captured) {
  if (!captured) return;
  if (SIDE(captured) == BLACK) {
    if (a->capturedByWhiteN < 16) a->capturedByWhite[a->capturedByWhiteN++] = captured;
  } else {
    if (a->capturedByBlackN < 16) a->capturedByBlack[a->capturedByBlackN++] = captured;
  }
}

/* Play a move in the app, updating every derived field. */
static bool app_play(ChessApp *a, Move m) {
  Position before = a->g.pos;
  char san[SAN_MAX];
  bool blackMove = (a->g.pos.side == BLACK);
  if (!move_to_san(&before, m, san, sizeof(san))) return false;
  /* find the capture in the legal list to know what was taken */
  MoveList l;
  generate_legal(&a->g.pos, &l);
  uint8_t captured = 0;
  for (int i = 0; i < l.n; i++)
    if (l.m[i].from == m.from && l.m[i].to == m.to && l.m[i].promo == m.promo) {
      m = l.m[i];
      captured = a->g.pos.board[m.to];
      if (m.flags & FLAG_EP) captured = MK(a->g.pos.side ^ 1, PAWN);
      break;
    }
  if (!game_make(&a->g, m)) return false;
  record_capture(a, captured);
  for (int s2 = 0; s2 < 2; s2++)
    for (int t2 = 0; t2 < 7; t2++) a->material[s2][t2] = 0;
  for (int sq = 0; sq < BOARD_AREA; sq++) {
    uint8_t pc = a->g.pos.board[sq];
    if (pc) a->material[SIDE(pc)][TYPE(pc)]++;
  }
  append_san(a, san, blackMove, a->g.ply - 1);
  a->hasLast = true;
  a->lastFrom = m.from;
  a->lastTo = m.to;
  a->hasSelection = false;
  a->selFrom = NO_SQUARE;
  set_status(a);
  return true;
}

/* Rebuild every derived field from scratch (used after undo and load).
 * The replay game is static: ChessApp itself is a large object and must not be
 * duplicated on the stack. */
static void rebuild_derived(ChessApp *a) {
  a->movetextLen = 0;
  a->movetext[0] = 0;
  a->capturedByWhiteN = 0;
  a->capturedByBlackN = 0;
  a->hasLast = false;
  static Game replay;
  game_new(&replay);
  for (int i = 0; i < a->g.ply; i++) {
    Position before = replay.pos;
    char san[SAN_MAX];
    Move m = a->g.played[i];
    move_to_san(&before, m, san, sizeof(san));
    uint8_t captured = 0;
    if (m.flags & FLAG_EP) captured = MK(replay.pos.side ^ 1, PAWN);
    else captured = replay.pos.board[m.to];
    game_make(&replay, m);
    record_capture(a, captured);
    append_san(a, san, replay.pos.side == WHITE, replay.ply - 1);
    a->hasLast = true;
    a->lastFrom = m.from;
    a->lastTo = m.to;
  }
  a->g.sixteenStatus = STATUS_PLAYING;
  set_status(a);
  if (a->status != STATUS_PLAYING) a->screen = SCREEN_GAME_OVER;
  else a->screen = SCREEN_PLAY;
}

void app_undo_full(ChessApp *a) {
  if (a->g.ply == 0) return;
  game_undo_full(&a->g);
  if (a->g.ply > 0 && a->g.pos.side != a->humanSide && a->humanSide >= 0) game_undo(&a->g);
  rebuild_derived(a);
  a->undoUsed++;
}

/* ------------------------------------------------------------- engine     */
bool app_engine_to_move(const ChessApp *a) {
  if (a->status != STATUS_PLAYING) return false;
  if (a->humanSide < 0) return false; /* human vs human */
  return a->g.pos.side != a->humanSide;
}

static volatile bool g_stopThinking;
static bool engine_tick(void) { return g_stopThinking; }
void app_request_stop_thinking(void) { g_stopThinking = true; }

static bool engine_run(ChessApp *a, uint32_t millis) {
  if (!app_engine_to_move(a)) return false;
  a->thinking = true;
  a->thinkDepth = 0;
  g_stopThinking = false;
  SearchLimits lim;
  lim.maxDepth = app_level_maxdepth(a->level);
  lim.maxMillis = millis;
  lim.tick = engine_tick;
  SearchResult r = search_think(&a->g, &lim);
  a->thinking = false;
  a->thinkDepth = r.depth;
  a->thinkScore = r.score;
  a->thinkNodes = r.nodes;
  a->thinkMillis = r.millis;
  if (r.best.from == 0 && r.best.to == 0) return false;
  char san[SAN_MAX];
  move_to_san(&a->g.pos, r.best, san, sizeof(san));
  snprintf(a->thinkLine, sizeof(a->thinkLine), "%s", san);
  return app_play(a, r.best);
}

bool app_engine_think(ChessApp *a) {
  return engine_run(a, (uint32_t)app_level_millis(a->level));
}

bool app_engine_think_limited(ChessApp *a, uint32_t millis) {
  return engine_run(a, millis ? millis : (uint32_t)app_level_millis(a->level));
}

/* ---------------------------------------------------------------- input   */
static void move_cursor(ChessApp *a, int dRow, int dCol) {
  int row, col;
  if (!app_display_pos(a, a->cursor, &row, &col)) {
    row = col = 4;
  }
  row += dRow;
  col += dCol;
  if (row < 0) row = 0;
  if (row > 7) row = 7;
  if (col < 0) col = 0;
  if (col > 7) col = 7;
  a->cursor = app_square_at(a, row, col);
}

static void cycle_menu_value(ChessApp *a, int delta) {
  switch (a->menuIndex) {
    case 1: { /* play as */
      int order[3] = {WHITE, BLACK, -1};
      int cur = 0;
      for (int i = 0; i < 3; i++)
        if (order[i] == a->humanSide) cur = i;
      cur = (cur + delta + 3) % 3;
      app_set_side(a, order[cur]);
      app_new_game(a);
      /* a side change starts a fresh game, but stay where the user is */
      a->screen = SCREEN_MENU;
      a->menuIndex = 1;
      break;
    }
    case 2:
      app_set_level(a, a->level + delta);
      break;
    default:
      break;
  }
}

static const int kPromoOrder[4] = {QUEEN, ROOK, BISHOP, KNIGHT};

static bool handle_play_key(ChessApp *a, int k) {
  int row, col;
  app_display_pos(a, a->cursor, &row, &col);
  switch (k) {
    case KEYMAP_CURSOR_UP: move_cursor(a, -1, 0); return true;
    case KEYMAP_CURSOR_DOWN: move_cursor(a, 1, 0); return true;
    case KEYMAP_CURSOR_LEFT: move_cursor(a, 0, -1); return true;
    case KEYMAP_CURSOR_RIGHT: move_cursor(a, 0, 1); return true;
    case KEYMAP_SELECT: {
      if (a->status != STATUS_PLAYING) {
        a->screen = SCREEN_GAME_OVER;
        return true;
      }
      if (a->engineToMove) return false;
      if (app_engine_to_move(a)) return false;
      if (!a->hasSelection) {
        uint8_t pc = a->g.pos.board[a->cursor];
        if (pc && SIDE(pc) == a->g.pos.side) {
          a->hasSelection = true;
          a->selFrom = a->cursor;
          return true;
        }
        snprintf(a->message, sizeof(a->message), "Not your piece");
        a->screen = SCREEN_MESSAGE;
        return true;
      }
      if (a->cursor == a->selFrom) { /* deselect */
        a->hasSelection = false;
        a->selFrom = NO_SQUARE;
        return true;
      }
      /* selecting another own piece retargets */
      uint8_t pc = a->g.pos.board[a->cursor];
      if (pc && SIDE(pc) == a->g.pos.side) {
        a->selFrom = a->cursor;
        return true;
      }
      if (!app_legal_dest(a, a->cursor)) {
        snprintf(a->message, sizeof(a->message), "Illegal move");
        a->screen = SCREEN_MESSAGE;
        return true;
      }
      if (is_promotion(a, a->selFrom, a->cursor)) {
        a->promoIndex = 0;
        a->promoSq = a->cursor;
        a->screen = SCREEN_PROMO;
        return true;
      }
      Move m;
      m.from = (uint8_t)a->selFrom;
      m.to = (uint8_t)a->cursor;
      m.flags = 0;
      m.promo = 0;
      if (!app_play(a, m)) {
        snprintf(a->message, sizeof(a->message), "Illegal move");
        a->screen = SCREEN_MESSAGE;
      }
      return true;
    }
    case KEYMAP_CANCEL:
      if (a->hasSelection) {
        a->hasSelection = false;
        a->selFrom = NO_SQUARE;
      } else {
        a->screen = SCREEN_CONFIRM_EXIT;
      }
      return true;
    case KEYMAP_MENU:
      a->screen = SCREEN_MENU;
      a->menuIndex = 0;
      return true;
    default:
      return false;
  }
}

static bool handle_menu_key(ChessApp *a, int k) {
  switch (k) {
    case KEYMAP_CURSOR_UP:
      a->menuIndex = (a->menuIndex + MENU_ITEMS - 1) % MENU_ITEMS;
      return true;
    case KEYMAP_CURSOR_DOWN:
      a->menuIndex = (a->menuIndex + 1) % MENU_ITEMS;
      return true;
    case KEYMAP_CURSOR_LEFT:
      if (a->menuIndex == 7) { /* Save game slot: left loads */
        if (app_load(a)) snprintf(a->message, sizeof(a->message), "Game loaded");
        else snprintf(a->message, sizeof(a->message), "Nothing to load");
        a->screen = SCREEN_MESSAGE;
        return true;
      }
      cycle_menu_value(a, -1);
      return true;
    case KEYMAP_CURSOR_RIGHT:
      cycle_menu_value(a, +1);
      return true;
    case KEYMAP_SELECT:
      switch (a->menuIndex) {
        case 0: app_new_game(a); return true;
        case 1: cycle_menu_value(a, +1); return true;
        case 2: app_set_level(a, a->level == 5 ? 1 : a->level + 1); return true;
        case 3: app_flip(a); return true;
        case 4: app_undo_full(a); a->screen = SCREEN_PLAY; return true;
        case 5: app_resign(a); return true;
        case 6: app_agree_draw(a); a->screen = (a->screen == SCREEN_MESSAGE) ? a->screen : a->screen; return true;
        case 7:
          if (app_save(a)) snprintf(a->message, sizeof(a->message), "Game saved");
          else snprintf(a->message, sizeof(a->message), "No storage");
          a->screen = SCREEN_MESSAGE;
          return true;
        case 8: a->screen = SCREEN_CONFIRM_EXIT; return true;
        default: return false;
      }
    case KEYMAP_CANCEL: a->screen = SCREEN_PLAY; return true;
    default: return false;
  }
}

static bool handle_promo_key(ChessApp *a, int k) {
  switch (k) {
    case KEYMAP_CURSOR_UP:
      a->promoIndex = (a->promoIndex + 3) % 4;
      return true;
    case KEYMAP_CURSOR_DOWN:
      a->promoIndex = (a->promoIndex + 1) % 4;
      return true;
    case KEYMAP_SELECT: {
      Move m;
      m.from = (uint8_t)a->selFrom;
      m.to = (uint8_t)a->promoSq;
      m.flags = FLAG_PROMO;
      m.promo = (uint8_t)kPromoOrder[a->promoIndex];
      a->screen = SCREEN_PLAY;
      if (!app_play(a, m)) {
        snprintf(a->message, sizeof(a->message), "Illegal move");
        a->screen = SCREEN_MESSAGE;
      }
      return true;
    }
    case KEYMAP_CANCEL:
      a->screen = SCREEN_PLAY;
      return true;
    default:
      return false;
  }
}

bool app_handle_key(ChessApp *a, int k) {
  if (k == KEY_NONE) return false;
  /* any key dismisses a transient message */
  if (a->screen == SCREEN_MESSAGE && k != KEYMAP_SELECT) {
    a->screen = SCREEN_PLAY;
    return true;
  }
  switch (a->screen) {
    case SCREEN_PLAY: return handle_play_key(a, k);
    case SCREEN_MENU: return handle_menu_key(a, k);
    case SCREEN_PROMO: return handle_promo_key(a, k);
    case SCREEN_CONFIRM_EXIT:
      if (k == KEYMAP_SELECT) {
        a->screen = SCREEN_GAME_OVER;
        a->g.sixteenStatus = STATUS_RESIGN;
        return true;
      }
      if (k == KEYMAP_CANCEL) {
        a->screen = SCREEN_PLAY;
        return true;
      }
      return false;
    case SCREEN_GAME_OVER:
      if (k == KEYMAP_SELECT) {
        app_new_game(a);
        return true;
      }
      return false;
    case SCREEN_MESSAGE:
      a->screen = SCREEN_PLAY;
      return true;
    default:
      return false;
  }
}

/* ------------------------------------------------------------- status text */
const char *app_status_text(const ChessApp *a) {
  static char buf[28];
  switch (a->status) {
    case STATUS_CHECKMATE:
      snprintf(buf, sizeof(buf), "Checkmate: %s wins", a->g.pos.side == WHITE ? "Black" : "White");
      break;
    case STATUS_STALEMATE: snprintf(buf, sizeof(buf), "Stalemate: draw"); break;
    case STATUS_REPETITION: snprintf(buf, sizeof(buf), "Draw: repetition"); break;
    case STATUS_FIFTY: snprintf(buf, sizeof(buf), "Draw: 50 moves"); break;
    case STATUS_MATERIAL: snprintf(buf, sizeof(buf), "Draw: material"); break;
    case STATUS_RESIGN:
      snprintf(buf, sizeof(buf), "%s resigned", a->g.pos.side == WHITE ? "White" : "Black");
      break;
    case STATUS_DRAW_AGREED: snprintf(buf, sizeof(buf), "Draw agreed"); break;
    default:
      snprintf(buf, sizeof(buf), "%s to move%s", a->g.pos.side == WHITE ? "White" : "Black",
               a->checkKingSq != NO_SQUARE ? " (check)" : "");
      break;
  }
  return buf;
}

/* ------------------------------------------------------------- persistence */
/* A compact save record. The moves are stored as (from,to,flags,promo) which
 * is exactly the Move struct, so a loaded game is replayed through
 * game_make() - the engine and the UI state are then rebuilt from scratch and
 * cannot be inconsistent with the board. */
#define SAVE_MAGIC 0x4E574348u /* "NWCH" */
#define SAVE_VERSION 2

typedef struct {
  uint32_t magic;
  uint32_t version;
  uint16_t ply;
  uint8_t humanSide; /* 0xff = two players */
  uint8_t level;
  uint8_t flip;
  uint8_t pad;
  Move moves[MAX_HISTORY];
} SaveBlob;

static SaveBlob s_blob;

bool app_save(ChessApp *a) {
  if (!a->storageOk) return false;
  s_blob.magic = SAVE_MAGIC;
  s_blob.version = SAVE_VERSION;
  s_blob.ply = (uint16_t)a->g.ply;
  s_blob.humanSide = (uint8_t)(a->humanSide < 0 ? 0xff : a->humanSide);
  s_blob.level = (uint8_t)a->level;
  s_blob.flip = (uint8_t)a->flip;
  s_blob.pad = 0;
  for (int i = 0; i < a->g.ply; i++) s_blob.moves[i] = a->g.played[i];
  return platform_storage_write(&s_blob, (int)sizeof(s_blob));
}

bool app_load(ChessApp *a) {
  if (!a->storageOk) return false;
  if (!platform_storage_read(&s_blob, (int)sizeof(s_blob))) return false;
  if (s_blob.magic != SAVE_MAGIC || s_blob.version != SAVE_VERSION) return false;
  if (s_blob.ply > MAX_HISTORY) return false;
  int ply = s_blob.ply;
  app_new_game(a);
  a->humanSide = (s_blob.humanSide == 0xff) ? -1 : s_blob.humanSide;
  a->level = s_blob.level ? s_blob.level : 3;
  if (a->level > 5) a->level = 5;
  for (int i = 0; i < ply; i++) {
    if (!game_make(&a->g, s_blob.moves[i])) return false; /* corrupt save */
  }
  a->flip = s_blob.flip;
  rebuild_derived(a);
  a->hasSelection = false;
  a->selFrom = NO_SQUARE;
  a->cursor = SQ_E2;
  return true;
}
