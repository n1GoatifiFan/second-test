/* gfx.c - software rasteriser and original piece artwork.
 * MIT licensed. Every shape below is drawn with primitives; nothing is copied.
 */
#include "gfx.h"

#include <string.h>

void canvas_clear(Canvas *c, color_t col) {
  for (int i = 0; i < c->w * c->h; i++) c->px[i] = col;
}

static inline void put(Canvas *c, int x, int y, color_t col) {
  if (x < 0 || y < 0 || x >= c->w || y >= c->h) return;
  c->px[y * c->w + x] = col;
}

static inline color_t get(Canvas *c, int x, int y) {
  if (x < 0 || y < 0 || x >= c->w || y >= c->h) return 0;
  return c->px[y * c->w + x];
}

void canvas_rect(Canvas *c, int x, int y, int w, int h, color_t col) {
  if (w <= 0 || h <= 0) return;
  int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
  int x1 = x + w > c->w ? c->w : x + w, y1 = y + h > c->h ? c->h : y + h;
  for (int yy = y0; yy < y1; yy++) {
    color_t *row = &c->px[yy * c->w];
    for (int xx = x0; xx < x1; xx++) row[xx] = col;
  }
}

void canvas_circle(Canvas *c, int cx, int cy, int r, color_t col) {
  if (r <= 0) return;
  int r2 = r * r;
  for (int dy = -r; dy <= r; dy++) {
    int dy2 = dy * dy;
    /* find the widest span on this scanline */
    int dx = 0;
    while ((dx + 1) * (dx + 1) + dy2 <= r2) dx++;
    for (int x = cx - dx; x <= cx + dx; x++) put(c, x, cy + dy, col);
  }
}

/* Filled triangle by scanline, with no floating point. */
void canvas_triangle(Canvas *c, int x0, int y0, int x1, int y1, int x2, int y2, color_t col) {
  if (y1 < y0) { int t = y0; y0 = y1; y1 = t; t = x0; x0 = x1; x1 = t; }
  if (y2 < y0) { int t = y0; y0 = y2; y2 = t; t = x0; x0 = x2; x2 = t; }
  if (y1 > y2) { int t = y1; y1 = y2; y2 = t; t = x1; x1 = x2; x2 = t; }
  /* long edge (x0,y0)-(x2,y2) split at y1 */
  if (y2 == y0) return;
  for (int y = y0; y <= y2; y++) {
    int xa = x0 + (int)((long)(x2 - x0) * (y - y0) / (y2 - y0));
    int xb;
    if (y < y1) {
      if (y1 == y0) xb = x1;
      else xb = x0 + (int)((long)(x1 - x0) * (y - y0) / (y1 - y0));
    } else {
      if (y2 == y1) xb = x2;
      else xb = x1 + (int)((long)(x2 - x1) * (y - y1) / (y2 - y1));
    }
    if (xa > xb) { int t = xa; xa = xb; xb = t; }
    for (int x = xa; x <= xb; x++) put(c, x, y, col);
  }
}

/* A trapezoid (used for pawns, bishops, king bodies). */
void canvas_trapezoid(Canvas *c, int y0, int y1, int xTopL, int xTopR, int xBotL, int xBotR,
                      color_t col) {
  if (y1 <= y0) return;
  for (int y = y0; y < y1; y++) {
    int l = xTopL + (int)((long)(xBotL - xTopL) * (y - y0) / (y1 - y0));
    int r = xTopR + (int)((long)(xBotR - xTopR) * (y - y0) / (y1 - y0));
    if (l > r) { int t = l; l = r; r = t; }
    for (int x = l; x <= r; x++) put(c, x, y, col);
  }
}

/* Piece artwork, part 2: mask-based rendering.
 *
 * Each piece is painted into a 45x45 mask with plain geometric shapes, then
 * the mask is dilated by one pixel for the outline colour and blitted in the
 * fill colour. All shapes are original to this project.
 */
#define PIECE_GRID 45

typedef struct {
  uint8_t m[PIECE_GRID * PIECE_GRID];
  int w;
  int h;
} Mask;

static void mask_clear(Mask *k) { memset(k->m, 0, sizeof(k->m)); }

static void mask_rect(Mask *k, int x, int y, int w, int h) {
  for (int yy = y; yy < y + h; yy++)
    for (int xx = x; xx < x + w; xx++)
      if (xx >= 0 && yy >= 0 && xx < PIECE_GRID && yy < PIECE_GRID) k->m[yy * PIECE_GRID + xx] = 1;
}

static void mask_circle(Mask *k, int cx, int cy, int r) {
  for (int dy = -r; dy <= r; dy++)
    for (int dx = -r; dx <= r; dx++)
      if (dx * dx + dy * dy <= r * r) mask_rect(k, cx + dx, cy + dy, 1, 1);
}

static void mask_trap(Mask *k, int y0, int y1, int tl, int tr, int bl, int br) {
  for (int y = y0; y < y1; y++) {
    int l = tl + (bl - tl) * (y - y0) / (y1 - y0);
    int r = tr + (br - tr) * (y - y0) / (y1 - y0);
    if (l > r) { int t = l; l = r; r = t; }
    mask_rect(k, l, y, r - l + 1, 1);
  }
}

static void mask_tri(Mask *k, int x0, int y0, int x1, int y1, int x2, int y2) {
  /* sort by y and fill by scanlines, integer only */
  if (y0 > y1) { int t = y0; y0 = y1; y1 = t; t = x0; x0 = x1; x1 = t; }
  if (y1 > y2) { int t = y1; y1 = y2; y2 = t; t = x1; x1 = x2; x2 = t; }
  if (y0 > y1) { int t = y0; y0 = y1; y1 = t; t = x0; x0 = x1; x1 = t; }
  if (y2 == y0) return;
  for (int y = y0; y <= y2; y++) {
    int xa = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    int xb;
    if (y < y1) xb = (y1 == y0) ? x1 : x0 + (x1 - x0) * (y - y0) / (y1 - y0);
    else xb = (y2 == y1) ? x2 : x1 + (x2 - x1) * (y - y1) / (y2 - y1);
    if (xa > xb) { int t = xa; xa = xb; xb = t; }
    mask_rect(k, xa, y, xb - xa + 1, 1);
  }
}

/* Pawn: ball head, neck, collar, flared body, two-step base. */
static void shape_pawn(Mask *k) {
  mask_circle(k, 22, 12, 6);
  mask_trap(k, 18, 24, 18, 26, 16, 28);
  mask_rect(k, 14, 24, 17, 2);          /* collar */
  mask_trap(k, 26, 34, 16, 28, 12, 32);
  mask_rect(k, 10, 34, 25, 3);
  mask_rect(k, 7, 37, 31, 3);
  mask_rect(k, 6, 40, 33, 4);
}

/* Knight: horse head facing left, ear, mane, arched neck, base. */
static void shape_knight(Mask *k) {
  mask_tri(k, 27, 3, 32, 13, 22, 13);        /* ear */
  mask_trap(k, 8, 20, 18, 32, 12, 30);       /* skull/forehead */
  mask_rect(k, 8, 14, 12, 6);                /* muzzle */
  mask_trap(k, 20, 33, 12, 30, 10, 32);      /* neck */
  mask_circle(k, 26, 26, 5);                 /* chest bulge */
  mask_rect(k, 9, 33, 27, 3);
  mask_rect(k, 7, 36, 31, 4);
  mask_rect(k, 6, 40, 33, 4);
}

/* Bishop: mitre with a ball finial, collar, base. */
static void shape_bishop(Mask *k) {
  mask_circle(k, 22, 7, 3);
  mask_trap(k, 10, 15, 19, 25, 16, 28);      /* mitre top */
  mask_circle(k, 22, 21, 8);                 /* mitre body */
  mask_trap(k, 26, 31, 15, 29, 13, 31);
  mask_rect(k, 13, 31, 19, 3);
  mask_rect(k, 9, 34, 27, 3);
  mask_rect(k, 7, 37, 31, 3);
  mask_rect(k, 6, 40, 33, 4);
}

/* Rook: crenellated top, tapering tower, two-step base. */
static void shape_rook(Mask *k) {
  mask_rect(k, 9, 5, 6, 9);
  mask_rect(k, 19, 5, 6, 9);
  mask_rect(k, 29, 5, 6, 9);
  mask_rect(k, 9, 12, 26, 4);
  mask_trap(k, 16, 30, 12, 32, 9, 35);
  mask_rect(k, 8, 30, 28, 3);
  mask_rect(k, 6, 33, 32, 3);
  mask_rect(k, 5, 36, 34, 4);
  mask_rect(k, 4, 40, 36, 4);
}

/* Queen: five-pointed coronet with pearls, band, tapering body, base. */
static void shape_queen(Mask *k) {
  static const int px[5] = {7, 15, 22, 29, 37};
  for (int i = 0; i < 5; i++) {
    mask_tri(k, px[i] - 3, 15, px[i] + 3, 15, px[i], 5);
    mask_circle(k, px[i], 4, 2);
  }
  mask_trap(k, 14, 22, 5, 39, 8, 36);        /* crown band */
  mask_trap(k, 22, 32, 8, 36, 12, 32);       /* body */
  mask_rect(k, 11, 32, 23, 3);
  mask_rect(k, 8, 35, 29, 3);
  mask_rect(k, 5, 38, 35, 3);
  mask_rect(k, 4, 41, 37, 3);
}

/* King: cross finial, crown band, body, base. */
static void shape_king(Mask *k) {
  mask_rect(k, 20, 2, 5, 12);                /* cross vertical */
  mask_rect(k, 15, 5, 15, 5);                /* cross horizontal */
  mask_trap(k, 14, 22, 9, 35, 6, 38);        /* crown */
  mask_trap(k, 22, 32, 6, 38, 11, 33);       /* body */
  mask_rect(k, 10, 32, 25, 3);
  mask_rect(k, 7, 35, 31, 3);
  mask_rect(k, 5, 38, 35, 3);
  mask_rect(k, 4, 41, 37, 3);
}

/* Interior detail: a one-pixel line across the filled span at grid row y.
 * This gives white pieces visible structure instead of a white blob. */
static void mask_detail_line(Mask *k, int y) {
  if (y < 0 || y >= PIECE_GRID) return;
  for (int x = 0; x < PIECE_GRID; x++)
    if (k->m[y * PIECE_GRID + x] & 1) k->m[y * PIECE_GRID + x] |= 2;
}

static void mask_detail_dot(Mask *k, int cx, int cy, int r) {
  for (int dy = -r; dy <= r; dy++)
    for (int dx = -r; dx <= r; dx++)
      if (dx * dx + dy * dy <= r * r) {
        int x = cx + dx, y = cy + dy;
        if (x >= 0 && y >= 0 && x < PIECE_GRID && y < PIECE_GRID && (k->m[y * PIECE_GRID + x] & 1))
          k->m[y * PIECE_GRID + x] |= 2;
      }
}

void canvas_piece(Canvas *c, int type, int side, color_t fill, color_t outline) {
  static Mask k;
  mask_clear(&k);
  switch (type) {
    case 1: shape_pawn(&k); break;
    case 2: shape_knight(&k); break;
    case 3: shape_bishop(&k); break;
    case 4: shape_rook(&k); break;
    case 5: shape_queen(&k); break;
    case 6: shape_king(&k); break;
    default: return;
  }
  /* detail rows (bit 1 of the mask) */
  switch (type) {
    case 1: mask_detail_line(&k, 24); mask_detail_line(&k, 34); mask_detail_line(&k, 37); break;
    case 2: mask_detail_line(&k, 14); mask_detail_line(&k, 33); mask_detail_line(&k, 36);
            mask_detail_dot(&k, 15, 18, 1); break;
    case 3: mask_detail_line(&k, 12); mask_detail_line(&k, 31); mask_detail_line(&k, 34);
            mask_detail_line(&k, 37); mask_detail_line(&k, 26); break;
    case 4: mask_detail_line(&k, 16); mask_detail_line(&k, 30); mask_detail_line(&k, 33);
            mask_detail_line(&k, 36); break;
    case 5: mask_detail_line(&k, 15); mask_detail_line(&k, 22); mask_detail_line(&k, 32);
            mask_detail_line(&k, 35); mask_detail_line(&k, 38); break;
    case 6: mask_detail_line(&k, 14); mask_detail_line(&k, 22); mask_detail_line(&k, 32);
            mask_detail_line(&k, 35); mask_detail_line(&k, 38); break;
    default: break;
  }
  /* the board cell is square; the design grid is 45x45 */
  const int s = c->w;
  for (int y = 0; y < PIECE_GRID; y++) {
    for (int x = 0; x < PIECE_GRID; x++) {
      if (!k.m[y * PIECE_GRID + x]) continue;
      /* fill (bit 0) or interior detail (bit 1) */
      color_t col = (k.m[y * PIECE_GRID + x] & 2) ? outline : fill;
      int x0 = x * s / PIECE_GRID, x1 = (x + 1) * s / PIECE_GRID;
      int y0 = y * s / PIECE_GRID, y1 = (y + 1) * s / PIECE_GRID;
      canvas_rect(c, x0, y0, x1 - x0, y1 - y0, col);
    }
  }
  /* outline: every empty pixel that touches the mask */
  for (int y = -1; y <= PIECE_GRID; y++) {
    for (int x = -1; x <= PIECE_GRID; x++) {
      bool inside = (x >= 0 && y >= 0 && x < PIECE_GRID && y < PIECE_GRID)
                        ? !!(k.m[y * PIECE_GRID + x] & 1)
                        : false;
      if (inside) continue;
      bool touch = false;
      for (int dy = -1; dy <= 1 && !touch; dy++)
        for (int dx = -1; dx <= 1 && !touch; dx++) {
          int nx = x + dx, ny = y + dy;
          if (nx >= 0 && ny >= 0 && nx < PIECE_GRID && ny < PIECE_GRID &&
              (k.m[ny * PIECE_GRID + nx] & 1))
            touch = true;
        }
      if (!touch) continue;
      int x0 = x * s / PIECE_GRID, x1 = (x + 1) * s / PIECE_GRID;
      int y0 = y * s / PIECE_GRID, y1 = (y + 1) * s / PIECE_GRID;
      canvas_rect(c, x0, y0, x1 - x0, y1 - y0, outline);
    }
  }
}

/* ------------------------------------------------------------------- text */
#include "font5x7.h"

/* The table is sorted by ASCII code and covers FONT5X7_FIRST..FONT5X7_LAST,
 * so lookup is a single index, not a scan. */
const uint8_t *font5x7_glyph(char c) {
  int idx = (unsigned char)c - FONT5X7_FIRST;
  /* the table stores its own ASCII code in byte 5, so the direct index is
   * verified instead of trusted */
  if (idx < 0 || idx >= font5x7_count || font5x7_data[idx * 6 + 5] != (uint8_t)c) {
    idx = (int)'?' - FONT5X7_FIRST;
    if (idx < 0 || idx >= font5x7_count || font5x7_data[idx * 6 + 5] != (uint8_t)'?')
      return font5x7_data; /* never out of bounds */
  }
  return &font5x7_data[idx * 6];
}

/* Draw one glyph at scale `sc` (1 = 5x7 pixels). */
void canvas_char(Canvas *c, int x, int y, char ch, color_t col, int sc) {
  const uint8_t *g = font5x7_glyph(ch);
  if (!g) return;
  for (int col5 = 0; col5 < 5; col5++) {
    uint8_t bits = g[col5];
    for (int row = 0; row < 7; row++) {
      if (!(bits & (1u << row))) continue;
      canvas_rect(c, x + col5 * sc, y + row * sc, sc, sc, col);
    }
  }
}

void canvas_text(Canvas *c, int x, int y, const char *s, color_t col, int sc) {
  for (; *s; s++, x += 6 * sc) canvas_char(c, x, y, *s, col, sc);
}

int canvas_text_width(const char *s, int sc) {
  int n = 0;
  while (s[n]) n++;
  return n ? (n * 6 - 1) * sc : 0;
}
