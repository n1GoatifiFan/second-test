/* game.h - UI-level game state: the chess Game plus presentation and
 * interaction state. Kept free of any platform call so it can be driven by
 * the native tests and by scripted sessions.
 */
#ifndef GAME_H
#define GAME_H

#include <stdint.h>
#include <stdbool.h>

#include "chess/chess.h"

#define MAX_PLIES MAX_HISTORY
#define SAN_MAX 10
#define MAX_MOVETEXT (MAX_PLIES * SAN_MAX)

typedef enum {
  SCREEN_PLAY = 0,
  SCREEN_MENU,
  SCREEN_PROMO,
  SCREEN_CONFIRM_EXIT,
  SCREEN_GAME_OVER,
  SCREEN_MESSAGE
} Screen;

typedef struct {
  /* game */
  Game g;
  int status;

  /* human side and levels */
  int humanSide;   /* WHITE / BLACK, or -1 for human vs human */
  int level;       /* 1..5 */
  int flip;        /* board orientation: false = white at the bottom */

  /* cursor and selection */
  int cursor;      /* square index (mailbox) */
  int selFrom;     /* selected piece square or NO_SQUARE */
  bool hasSelection;

  /* highlights */
  int lastFrom, lastTo;
  bool hasLast;
  int checkKingSq; /* king in check, or NO_SQUARE */

  /* move list */
  char movetext[MAX_MOVETEXT];
  int movetextLen;
  int movetextScroll; /* first visible line */

  /* captured pieces, as piece codes (so promotion can show the right one) */
  uint8_t capturedByWhite[16];
  int capturedByWhiteN;
  uint8_t capturedByBlack[16];
  int capturedByBlackN;

  /* material signature after the last irreversible move: repetition and
   * the 50-move rule only need to look back this far */
  uint8_t material[2][7];

  /* engine */
  bool thinking;
  bool engineToMove;
  int thinkDepth;
  int thinkScore;
  uint32_t thinkNodes;
  uint32_t thinkMillis;
  char thinkLine[16]; /* last engine move in SAN */

  /* ui state */
  Screen screen;
  int menuIndex;
  int promoIndex;   /* 0=Q,1=R,2=B,3=N */
  int promoSq;      /* destination square of the pending promotion */
  char message[24];
  char statusLine[28];
  bool storageOk;

  /* undo stack of snapshots (one per full move) */
  int undoUsed;
} ChessApp;

void app_init(ChessApp *a);
void app_new_game(ChessApp *a);
void app_flip(ChessApp *a);
void app_set_level(ChessApp *a, int level);
void app_set_side(ChessApp *a, int side); /* WHITE, BLACK or -1 */
void app_resign(ChessApp *a);
void app_agree_draw(ChessApp *a);
void app_undo_full(ChessApp *a);

/* Input handling. `k` is a logical key (see platform.h).
 * Returns true when the screen needs to be redrawn. */
bool app_handle_key(ChessApp *a, int k);

/* Called by the render loop: true when the engine should be run. */
bool app_engine_to_move(const ChessApp *a);

/* Runs the search synchronously within the level's budget and plays the move.
 * Between calls, app_request_stop_thinking() aborts the search. The platform
 * main loop slices this call from the outside by starting a bounded search;
 * see app_engine_think_limited() for the version the UI uses. */
bool app_engine_think(ChessApp *a);

/* Same, but with an explicit time budget in milliseconds: used when the app
 * wants to interleave drawing with the search. */
bool app_engine_think_limited(ChessApp *a, uint32_t millis);
/* Ask the running search to stop (it still returns its best move so far). */
void app_request_stop_thinking(void);

/* Helpers used by the renderer. */
int app_square_at(const ChessApp *a, int row, int col); /* display -> mailbox */
int app_display_pos(const ChessApp *a, int sq, int *row, int *col);
bool app_legal_dest(const ChessApp *a, int sq);
const char *app_status_text(const ChessApp *a);
int app_level_millis(int level);
int app_level_maxdepth(int level);

/* Persistence (uses platform_storage_*).
 * The saved blob holds the move list plus presentation state, which is far
 * smaller than the ChessApp struct itself; the game is replayed on load.
 * Returns false when the platform has no storage API. */
bool app_save(ChessApp *a);
bool app_load(ChessApp *a);

#endif
