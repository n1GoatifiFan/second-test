/* font5x7.h - 5x7 bitmap font (original artwork, MIT). */
#ifndef FONT5X7_H_INCLUDED
#define FONT5X7_H_INCLUDED
#include <stdint.h>

extern const uint8_t font5x7_data[];
extern const int font5x7_count;
extern const uint8_t font5x7_first;
extern const uint8_t font5x7_last;

/* The table is contiguous from ' ' (32) to '~' (126). */
#define FONT5X7_FIRST 32
#define FONT5X7_LAST 126

/* Returns a pointer to the 5 column bytes of `c`, or of '?' when unknown. */
const uint8_t *font5x7_glyph(char c);

#define FONT5X7_W 5
#define FONT5X7_HEIGHT 7
#endif
