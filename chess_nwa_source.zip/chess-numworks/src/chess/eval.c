/* eval.c - material + piece-square table evaluation. No floats.
 * MIT licensed. Original code.
 */
#include "eval.h"

/* Piece-square tables, from white's point of view, index 0 = a1.
 * These are the well-known "simplified evaluation function" tables that have
 * circulated in the public domain since the 1980s (Tomasz Michniewski's
 * simplified evaluation function). Hand-typed here, no code copied. */
static const int16_t pstPawn[64] = {
      0,  0,  0,  0,  0,  0,  0,  0,
     50, 50, 50, 50, 50, 50, 50, 50,
     10, 10, 20, 30, 30, 20, 10, 10,
      5,  5, 10, 25, 25, 10,  5,  5,
      0,  0,  0, 20, 20,  0,  0,  0,
      5, -5,-10,  0,  0,-10, -5,  5,
      5, 10, 10,-20,-20, 10, 10,  5,
      0,  0,  0,  0,  0,  0,  0,  0};

static const int16_t pstKnight[64] = {
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50};

static const int16_t pstBishop[64] = {
    -20,-10,-10,-10,-10,-10,-10,-20,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -10,  0,  5, 10, 10,  5,  0,-10,
    -10,  5,  5, 10, 10,  5,  5,-10,
    -10,  0, 10, 10, 10, 10,  0,-10,
    -10, 10, 10, 10, 10, 10, 10,-10,
    -10,  5,  0,  0,  0,  0,  5,-10,
    -20,-10,-10,-10,-10,-10,-10,-20};

static const int16_t pstRook[64] = {
      0,  0,  0,  0,  0,  0,  0,  0,
      5, 10, 10, 10, 10, 10, 10,  5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
      0,  0,  0,  5,  5,  0,  0,  0};

static const int16_t pstQueen[64] = {
    -20,-10,-10, -5, -5,-10,-10,-20,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -10,  0,  5,  5,  5,  5,  0,-10,
     -5,  0,  5,  5,  5,  5,  0, -5,
      0,  0,  5,  5,  5,  5,  0, -5,
    -10,  5,  5,  5,  5,  5,  0,-10,
    -10,  0,  5,  0,  0,  0,  0,-10,
    -20,-10,-10, -5, -5,-10,-10,-20};

static const int16_t pstKingMid[64] = {
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -20,-30,-30,-40,-40,-30,-30,-20,
    -10,-20,-20,-20,-20,-20,-20,-10,
     20, 20,  0,  0,  0,  0, 20, 20,
     20, 30, 10,  0,  0, 10, 30, 20};

static const int16_t pstKingEnd[64] = {
    -50,-40,-30,-20,-20,-30,-40,-50,
    -30,-20,-10,  0,  0,-10,-20,-30,
    -30,-10, 20, 30, 30, 20,-10,-30,
    -30,-10, 30, 40, 40, 30,-10,-30,
    -30,-10, 30, 40, 40, 30,-10,-30,
    -30,-10, 20, 30, 30, 20,-10,-30,
    -30,-30,  0,  0,  0,  0,-30,-30,
    -50,-30,-30,-30,-30,-30,-30,-50};

static const int16_t *pstFor(int type) {
  switch (type) {
    case PAWN: return pstPawn;
    case KNIGHT: return pstKnight;
    case BISHOP: return pstBishop;
    case ROOK: return pstRook;
    case QUEEN: return pstQueen;
    case KING: return pstKingMid;
    default: return pstPawn;
  }
}

static const int pieceValue[8] = {0, VAL_PAWN, VAL_KNIGHT, VAL_BISHOP,
                                  VAL_ROOK, VAL_QUEEN, VAL_KING, 0};

int eval_material(const Position *p) {
  int score = 0;
  for (int sq = 0; sq < BOARD_AREA; sq++) {
    uint8_t pc = p->board[sq];
    if (!pc) continue;
    int v = pieceValue[TYPE(pc)];
    score += (SIDE(pc) == WHITE) ? v : -v;
  }
  return score;
}

/* Is the position "endgame-ish"? Simple test: no queens, or queen + at most
 * one minor piece for each side. */
static bool isEndgame(const Position *p) {
  int majors = 0, minors = 0;
  for (int sq = 0; sq < BOARD_AREA; sq++) {
    uint8_t pc = p->board[sq];
    if (!pc) continue;
    int t = TYPE(pc);
    if (t == QUEEN || t == ROOK) majors++;
    else if (t == KNIGHT || t == BISHOP) minors++;
  }
  return majors == 0 && minors <= 4;
}

int eval_position(const Position *p) {
  int score = 0; /* white's point of view */
  int wBishops = 0, bBishops = 0;
  int wPawnFiles[8] = {0}, bPawnFiles[8] = {0};
  int phase = 0;

  for (int sq = 0; sq < BOARD_AREA; sq++) {
    uint8_t pc = p->board[sq];
    if (!pc) continue;
    int t = TYPE(pc);
    int idx = SQ64(sq);
    int v = pieceValue[t];
    int w = (SIDE(pc) == WHITE);
    if (!w) idx = (7 - (idx >> 3)) * 8 + (idx & 7); /* mirror */
    int ps;
    if (t == KING) ps = isEndgame(p) ? pstKingEnd[idx] : pstKingMid[idx];
    else ps = pstFor(t)[idx];
    if (w) score += v + ps;
    else score -= v + ps;
    if (t == BISHOP) { if (w) wBishops++; else bBishops++; }
    if (t == PAWN) { if (w) wPawnFiles[FILE_OF(sq)]++; else bPawnFiles[FILE_OF(sq)]++; }
    if (t == QUEEN || t == ROOK) phase += 2;
    else if (t == KNIGHT || t == BISHOP) phase += 1;
  }
  (void)phase;
  /* bishop pair */
  if (wBishops >= 2) score += 30;
  if (bBishops >= 2) score -= 30;
  /* doubled pawns */
  for (int f = 0; f < 8; f++) {
    if (wPawnFiles[f] > 1) score -= 12 * (wPawnFiles[f] - 1);
    if (bPawnFiles[f] > 1) score += 12 * (bPawnFiles[f] - 1);
  }
  return (p->side == WHITE) ? score : -score;
}
