/* chess.h - position, move generation, make/unmake, game state.
 *
 * Part of numworks-chess. MIT licensed, see LICENSE.
 * Written from scratch for this project (no third-party engine code).
 */
#ifndef CHESS_H
#define CHESS_H

#include <stdint.h>
#include <stdbool.h>

/* ---- board geometry ----------------------------------------------------
 * 12x16 mailbox ("10x12 style" with a full sentinel border):
 *
 *     index = 16*row + col,  row 0..11, col 0..15
 *     the real board is rows 2..9, columns 2..9  (BOARD_AREA = 192)
 *
 * Every square outside the board is permanently EMPTY, so knight/king/pawn
 * offsets can never wrap around a rank and always land inside the array.
 * Sliding pieces additionally test the array bounds (the border is only two
 * rows deep, which is not enough for a long ray).
 */
#define BOARD_AREA 192
#define NO_SQUARE 255

#define SQ_FROM64(i) ((((i) >> 3) + 2) * 16 + ((i) & 7) + 2)
#define rowOf(sq) ((sq) >> 4)
#define colOf(sq) ((sq) & 15)
#define RANK_OF(sq) (rowOf(sq) - 2) /* 0 = rank 1 (white's home) */
#define FILE_OF(sq) (colOf(sq) - 2) /* 0 = file a                */
#define SQ64(sq) ((RANK_OF(sq) * 8) + FILE_OF(sq))
/* true only for the 64 real squares (unsigned trick: sub-then-compare) */
#define ON_BOARD(sq) (((unsigned)(rowOf(sq) - 2) < 8u) && ((unsigned)(colOf(sq) - 2) < 8u))

#define SQ_A1 34
#define SQ_B1 35
#define SQ_C1 36
#define SQ_D1 37
#define SQ_E1 38
#define SQ_F1 39
#define SQ_G1 40
#define SQ_H1 41
#define SQ_A2 50
#define SQ_B2 51
#define SQ_C2 52
#define SQ_D2 53
#define SQ_E2 54
#define SQ_F2 55
#define SQ_G2 56
#define SQ_H2 57
#define SQ_A7 130
#define SQ_E7 134
#define SQ_A8 146
#define SQ_B8 147
#define SQ_C8 148
#define SQ_D8 149
#define SQ_E8 150
#define SQ_F8 151
#define SQ_G8 152
#define SQ_H8 153

/* ---- pieces ------------------------------------------------------------ */
enum { EMPTY = 0, PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6 };
/* the colour is bit 3 */
#define SIDE(p) ((p) >> 3)
#define TYPE(p) ((p) & 7)
#define WHITE 0
#define BLACK 1
#define MK(side, type) ((uint8_t)(((side) << 3) | (type)))

/* ---- one move ---------------------------------------------------------- */
typedef struct {
  uint8_t from;
  uint8_t to;
  uint8_t flags; /* FLAG_* */
  uint8_t promo; /* promoted piece TYPE, 0 if none */
} Move;

/* flags */
#define FLAG_CAPTURE 0x1
#define FLAG_EP 0x2      /* en-passant capture */
#define FLAG_CASTLE 0x4  /* castling (long side in FLAG_LONG) */
#define FLAG_LONG 0x8    /* queen-side castle */
#define FLAG_PROMO 0x10

typedef struct {
  Move m[128];
  int n;
} MoveList;

/* ---- position ---------------------------------------------------------- */
typedef struct {
  uint8_t board[BOARD_AREA];
  uint8_t side;      /* side to move: WHITE or BLACK */
  uint8_t castle;    /* C_* bitmask */
  uint8_t ep;        /* en-passant target square, or 0 */
  uint8_t kingSq[2];
  uint16_t halfmove; /* fifty-move counter, in plies */
  uint16_t fullmove;
  uint64_t hash;     /* Zobrist key over everything that matters */
} Position;

/* castling rights */
#define C_WK 0x1
#define C_WQ 0x2
#define C_BK 0x4
#define C_BQ 0x8

/* 256 plies = 128 full moves, enough for any game; keeps the game record
 * (Game is ~18 KB) small enough to snapshot for save/load. */
#define MAX_HISTORY 256

/* everything needed to take a move back */
typedef struct {
  uint8_t captured;   /* piece (with colour) removed, 0 if none */
  uint8_t capturedSq; /* square it was on - differs from `to` for e.p. */
  uint8_t castle;
  uint8_t ep;
  uint16_t halfmove;
} Undo;

typedef struct {
  Position pos;
  Undo hist[MAX_HISTORY];
  Move played[MAX_HISTORY];
  uint64_t key[MAX_HISTORY]; /* hash after each ply, for repetition */
  int ply;
  int sixteenStatus; /* STATUS_* forced by resign / draw agreement */
} Game;

extern const char PIECE_CHAR[16];

void chess_init(void);

void position_set_startpos(Position *p);
/* FEN parsing/printing. Used by the test harness and the "position" command. */
bool position_from_fen(Position *p, const char *fen);
void position_to_fen(const Position *p, char *out, int outSize);

/* Is `sq` attacked by `bySide`? */
bool square_attacked(const Position *p, int sq, int bySide);
bool in_check(const Position *p);

/* Fully legal move generation (filters out every move that would leave the
 * king in check, including the en-passant and castling special cases). */
void generate_legal(Position *p, MoveList *out);
/* Pseudo-legal generation, no legality filter. */
void generate_pseudo(const Position *p, MoveList *out);

/* Is `m` (a pseudo-legal move from a generated list) legal? */
bool move_is_legal(Position *p, Move m);

/* Null move: pass the turn. Used by the search's null-move pruning. Updates
 * the Zobrist key and clears the en-passant square (no legal e.p. capture can
 * exist after a null move). */
void make_null(Position *p);

void make_move(Position *p, Move m, Undo *u);
void unmake_move(Position *p, Move m, const Undo *u);

/* ---- game level -------------------------------------------------------- */
void game_new(Game *g);
bool game_make(Game *g, Move m); /* false (and no change) if illegal */
void game_undo(Game *g);         /* take back one ply */
void game_undo_full(Game *g);    /* take back one full move when possible */

enum {
  STATUS_PLAYING = 0,
  STATUS_CHECKMATE,
  STATUS_STALEMATE,
  STATUS_REPETITION,
  STATUS_FIFTY,
  STATUS_MATERIAL,
  STATUS_RESIGN,
  STATUS_DRAW_AGREED,
  STATUS_DRAW_OFFER /* internal, never returned by game_status() */
};

bool insufficient_material(const Position *p);
int repetition_count(const Game *g); /* occurrences of the current position */
int game_status(const Game *g);

/* Short algebraic notation ("Nf3", "exd5", "O-O", "e8=Q+", "Qh7#"). */
bool move_to_san(Position *p, Move m, char *san, int sanSize);

/* Node counter used by perft and by the engine's node accounting. */
uint64_t perft(Position *p, int depth);

#endif
