/* search.h - iterative deepening alpha-beta with quiescence.
 * MIT licensed.
 */
#ifndef SEARCH_H
#define SEARCH_H

#include <stdint.h>
#include <stdbool.h>
#include "chess.h"

/* search_platform_millis() is supplied by the platform (see
 * search_platform.h): the native build uses clock_gettime, the calculator
 * build uses eadk_timing_millis(). */
#include "search_platform.h"

/* Called periodically from inside the search so the UI can keep drawing the
 * "thinking" indicator and so the user can abort. Returning true aborts the
 * search (the best move found so far is still returned). May be NULL. */
typedef bool (*SearchCallback)(void);

typedef struct {
  int maxDepth;      /* hard depth limit                     */
  uint32_t maxMillis; /* hard time limit, 0 = none            */
  SearchCallback tick; /* called every 2048 nodes, may abort  */
} SearchLimits;

typedef struct {
  Move best;
  int score;        /* from the side to move's point of view */
  int depth;        /* depth reached                         */
  uint32_t nodes;
  uint32_t millis;
  bool mate;         /* score is a forced mate in |score| ply */
  int mateInPlies;
} SearchResult;

/* Transposition table. 1024 entries x 12 bytes = 12 KiB, which fits the
 * external-app RAM window with room for the two framebuffers' worth of UI
 * state and the game records (see BUILD_REPORT.md for the measurements). */
#define TT_BUCKETS 512

void search_init(void);
void search_set_hash_size(int buckets); /* clamp to TT_BUCKETS */

/* Think about the position in `g`. The game state is not modified. */
SearchResult search_think(const Game *g, const SearchLimits *lim);

/* Best move for a bare position (tests / self-play helper). */
SearchResult search_think_position(Position *p, const SearchLimits *lim);

/* Score a position statically, from the side to move's point of view. */
int search_eval(const Position *p);

#endif
