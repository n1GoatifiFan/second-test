/* chess.c - board, legal move generation, make/unmake, game state.
 * MIT licensed. Original code written for numworks-chess.
 */
#include "chess.h"

#include <string.h>
#include <stdio.h>

const char PIECE_CHAR[16] = {'.', 'P', 'N', 'B', 'R', 'Q', 'K', '?',
                             'x', 'p', 'n', 'b', 'r', 'q', 'k', '?'};

/* ------------------------------------------------------------------ zobrist */
static uint64_t zPiece[16][64];
static uint64_t zSide;
static uint64_t zCastle[16];
static uint64_t zEp[64];
static bool gInit = false;

/* xorshift64*: deterministic, dependency-free, no floats. */
static uint64_t rngState;
static uint64_t rnd64(void) {
  rngState ^= rngState >> 12;
  rngState ^= rngState << 25;
  rngState ^= rngState >> 27;
  return rngState * 0x2545F4914F6CDD1Dull;
}

void chess_init(void) {
  if (gInit) return;
  rngState = 0x9E3779B97F4A7C15ull;
  for (int p = 0; p < 16; p++)
    for (int s = 0; s < 64; s++) zPiece[p][s] = rnd64();
  zSide = rnd64();
  for (int i = 0; i < 16; i++) zCastle[i] = rnd64();
  for (int s = 0; s < 64; s++) zEp[s] = rnd64();
  gInit = true;
}

static uint64_t compute_hash(const Position *p) {
  uint64_t h = 0;
  for (int s = 0; s < BOARD_AREA; s++) {
    uint8_t pc = p->board[s];
    if (pc) h ^= zPiece[pc][SQ64(s)];
  }
  if (p->side == BLACK) h ^= zSide;
  h ^= zCastle[p->castle & 15];
  if (p->ep) h ^= zEp[SQ64(p->ep)];
  return h;
}

/* --------------------------------------------------------------- positions */
static void set_piece(Position *p, int sq, uint8_t piece) {
  p->board[sq] = piece;
  if (TYPE(piece) == KING) p->kingSq[SIDE(piece)] = (uint8_t)sq;
}

static void clear_board(Position *p) {
  memset(p->board, 0, sizeof(p->board));
  p->kingSq[0] = p->kingSq[1] = NO_SQUARE;
}

void position_set_startpos(Position *p) {
  chess_init();
  static const uint8_t backRank[8] = {ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK};
  clear_board(p);
  for (int f = 0; f < 8; f++) {
    set_piece(p, SQ_FROM64(0 + f), MK(WHITE, backRank[f]));
    set_piece(p, SQ_FROM64(8 + f), MK(WHITE, PAWN));
    set_piece(p, SQ_FROM64(48 + f), MK(BLACK, PAWN));
    set_piece(p, SQ_FROM64(56 + f), MK(BLACK, backRank[f]));
  }
  p->side = WHITE;
  p->castle = C_WK | C_WQ | C_BK | C_BQ;
  p->ep = 0;
  p->halfmove = 0;
  p->fullmove = 1;
  p->hash = compute_hash(p);
}

/* --------------------------------------------------------------- FEN I/O  */
static int piece_from_char(char c) {
  uint8_t type = 0, side;
  switch (c | 0x20) {
    case 'p': type = PAWN; break;
    case 'n': type = KNIGHT; break;
    case 'b': type = BISHOP; break;
    case 'r': type = ROOK; break;
    case 'q': type = QUEEN; break;
    case 'k': type = KING; break;
    default: return 0;
  }
  side = (c >= 'a' && c <= 'z') ? BLACK : WHITE;
  return MK(side, type);
}

bool position_from_fen(Position *p, const char *fen) {
  chess_init();
  clear_board(p);
  p->castle = 0;
  p->ep = 0;
  p->halfmove = 0;
  p->fullmove = 1;

  const char *c = fen;
  int rank = 7, file = 0;
  while (*c && *c != ' ') {
    if (*c == '/') {
      rank--;
      file = 0;
      if (rank < 0) return false;
      c++;
      continue;
    }
    if (*c >= '1' && *c <= '8') {
      file += *c - '0';
      c++;
      continue;
    }
    int pc = piece_from_char(*c);
    if (!pc || file > 7 || rank < 0) return false;
    set_piece(p, SQ_FROM64(rank * 8 + file), (uint8_t)pc);
    file++;
    c++;
  }
  while (*c == ' ') c++;
  if (*c == 'w') p->side = WHITE;
  else if (*c == 'b') p->side = BLACK;
  else return false;
  while (*c && *c != ' ') c++;
  while (*c == ' ') c++;
  while (*c && *c != ' ') {
    switch (*c) {
      case 'K': p->castle |= C_WK; break;
      case 'Q': p->castle |= C_WQ; break;
      case 'k': p->castle |= C_BK; break;
      case 'q': p->castle |= C_BQ; break;
      case '-': break;
      default: return false;
    }
    c++;
  }
  while (*c == ' ') c++;
  if (*c == '-') {
    c++;
  } else if (*c) {
    if (c[0] < 'a' || c[0] > 'h' || c[1] < '1' || c[1] > '8') return false;
    p->ep = (uint8_t)SQ_FROM64((c[1] - '1') * 8 + (c[0] - 'a'));
    c += 2;
  }
  while (*c == ' ') c++;
  if (*c >= '0' && *c <= '9') {
    int v = 0;
    while (*c >= '0' && *c <= '9') v = v * 10 + (*c++ - '0');
    p->halfmove = (uint16_t)v;
  }
  while (*c == ' ') c++;
  if (*c >= '0' && *c <= '9') {
    int v = 0;
    while (*c >= '0' && *c <= '9') v = v * 10 + (*c++ - '0');
    p->fullmove = (uint16_t)v;
  }
  p->hash = compute_hash(p);
  return p->kingSq[0] != NO_SQUARE && p->kingSq[1] != NO_SQUARE;
}

void position_to_fen(const Position *p, char *out, int outSize) {
  int n = 0;
  for (int r = 7; r >= 0; r--) {
    int empty = 0;
    for (int f = 0; f < 8; f++) {
      uint8_t pc = p->board[SQ_FROM64(r * 8 + f)];
      if (!pc) {
        empty++;
        continue;
      }
      if (empty && n < outSize - 1) out[n++] = (char)('0' + empty);
      empty = 0;
      /* PIECE_CHAR already holds upper case for white and lower case for
       * black, so no case conversion is needed here. */
      char ch = PIECE_CHAR[pc];
      if (n < outSize - 1) out[n++] = ch;
    }
    if (empty && n < outSize - 1) out[n++] = (char)('0' + empty);
    if (r) {
      if (n < outSize - 1) out[n++] = '/';
    }
  }
  char castle[8];
  castle[0] = 0;
  if (p->castle & C_WK) strcat(castle, "K");
  if (p->castle & C_WQ) strcat(castle, "Q");
  if (p->castle & C_BK) strcat(castle, "k");
  if (p->castle & C_BQ) strcat(castle, "q");
  if (!castle[0]) strcpy(castle, "-");
  char eps[4] = "-";
  if (p->ep) {
    eps[0] = (char)('a' + FILE_OF(p->ep));
    eps[1] = (char)('1' + RANK_OF(p->ep));
    eps[2] = 0;
  }
  if (n < outSize - 1) {
    out[n] = 0;
    snprintf(out + n, outSize - n, " %c %s %s %d %d", p->side == WHITE ? 'w' : 'b', castle, eps,
             p->halfmove, p->fullmove);
  }
}

/* ----------------------------------------------------------------- attacks */
static const int knightOff[8] = {-33, -31, -18, -14, 14, 18, 31, 33};
static const int kingOff[8] = {-17, -16, -15, -1, 1, 15, 16, 17};
static const int bishopDir[4] = {-17, -15, 15, 17};
static const int rookDir[4] = {-16, -1, 1, 16};

/* Is square `sq` attacked by `bySide`? This never produces false positives
 * because of the sentinel rows/columns. */
bool square_attacked(const Position *p, int sq, int bySide) {
  const uint8_t *b = p->board;
  /* pawns: a white pawn on sq-17 / sq-15 attacks sq */
  if (bySide == WHITE) {
    if (TYPE(b[sq - 17]) == PAWN && b[sq - 17] && SIDE(b[sq - 17]) == WHITE) return true;
    if (TYPE(b[sq - 15]) == PAWN && b[sq - 15] && SIDE(b[sq - 15]) == WHITE) return true;
  } else {
    if (b[sq + 17] && TYPE(b[sq + 17]) == PAWN && SIDE(b[sq + 17]) == BLACK) return true;
    if (b[sq + 15] && TYPE(b[sq + 15]) == PAWN && SIDE(b[sq + 15]) == BLACK) return true;
  }
  for (int i = 0; i < 8; i++) {
    int t = sq + knightOff[i];
    uint8_t pc = b[t];
    if (pc && SIDE(pc) == bySide && TYPE(pc) == KNIGHT) return true;
  }
  for (int i = 0; i < 8; i++) {
    int t = sq + kingOff[i];
    uint8_t pc = b[t];
    if (pc && SIDE(pc) == bySide && TYPE(pc) == KING) return true;
  }
  for (int i = 0; i < 4; i++) {
    int d = bishopDir[i];
    for (int t = sq + d; ON_BOARD(t); t += d) {
      uint8_t pc = b[t];
      if (!pc) continue;
      if (SIDE(pc) == bySide) {
        int ty = TYPE(pc);
        if (ty == BISHOP || ty == QUEEN) return true;
      }
      break;
    }
  }
  for (int i = 0; i < 4; i++) {
    int d = rookDir[i];
    for (int t = sq + d; ON_BOARD(t); t += d) {
      uint8_t pc = b[t];
      if (!pc) continue;
      if (SIDE(pc) == bySide) {
        int ty = TYPE(pc);
        if (ty == ROOK || ty == QUEEN) return true;
      }
      break;
    }
  }
  return false;
}

bool in_check(const Position *p) { return square_attacked(p, p->kingSq[p->side], p->side ^ 1); }

/* ------------------------------------------------------- move generation  */
static void add_move(MoveList *l, int from, int to, int flags) {
  if (l->n >= 128) return;
  Move *m = &l->m[l->n++];
  m->from = (uint8_t)from;
  m->to = (uint8_t)to;
  m->flags = (uint8_t)flags;
  m->promo = 0;
}

static void add_promo(MoveList *l, int from, int to, int flags, int promoType) {
  if (l->n >= 128) return;
  Move *m = &l->m[l->n++];
  m->from = (uint8_t)from;
  m->to = (uint8_t)to;
  m->flags = (uint8_t)(flags | FLAG_PROMO);
  m->promo = (uint8_t)promoType;
}

static void generate_pawn(const Position *p, MoveList *l, int from) {
  const int side = p->side;
  const int up = (side == WHITE) ? 16 : -16;
  const int startRank = (side == WHITE) ? 1 : 6;
  const int promoRank = (side == WHITE) ? 6 : 1; /* rank a pawn promotes *from* */
  const uint8_t *b = p->board;
  int to = from + up;
  if (ON_BOARD(to) && !b[to]) {
    if (RANK_OF(from) == promoRank) {
      add_promo(l, from, to, 0, QUEEN);
      add_promo(l, from, to, 0, ROOK);
      add_promo(l, from, to, 0, BISHOP);
      add_promo(l, from, to, 0, KNIGHT);
    } else {
      add_move(l, from, to, 0);
      if (RANK_OF(from) == startRank && ON_BOARD(to + up) && !b[to + up])
        add_move(l, from, to + up, 0);
    }
  }
  for (int s = -1; s <= 1; s += 2) {
    int t = from + up + s;
    if (!ON_BOARD(t)) continue;
    uint8_t pc = b[t];
    if (pc && SIDE(pc) != side) {
      if (RANK_OF(from) == promoRank) {
        add_promo(l, from, t, FLAG_CAPTURE, QUEEN);
        add_promo(l, from, t, FLAG_CAPTURE, ROOK);
        add_promo(l, from, t, FLAG_CAPTURE, BISHOP);
        add_promo(l, from, t, FLAG_CAPTURE, KNIGHT);
      } else {
        add_move(l, from, t, FLAG_CAPTURE);
      }
    } else if (!pc && t == p->ep) {
      add_move(l, from, t, FLAG_CAPTURE | FLAG_EP);
    }
  }
}

static void generate_piece(const Position *p, MoveList *l, int from, const int *dirs, int nDirs,
                           bool sliding) {
  const uint8_t *b = p->board;
  const int side = p->side;
  for (int i = 0; i < nDirs; i++) {
    int d = dirs[i];
    for (int t = from + d; ON_BOARD(t); t += d) {
      uint8_t pc = b[t];
      if (!pc) {
        add_move(l, from, t, 0);
        if (!sliding) break;
        continue;
      }
      if (SIDE(pc) != side) add_move(l, from, t, FLAG_CAPTURE);
      break;
    }
  }
}

static void generate_casts(const Position *p, MoveList *l) {
  const int side = p->side;
  if (side == WHITE) {
    if ((p->castle & C_WK) && !p->board[SQ_F1] && !p->board[SQ_G1] &&
        !square_attacked(p, SQ_E1, BLACK) && !square_attacked(p, SQ_F1, BLACK)) {
      add_move(l, SQ_E1, SQ_G1, FLAG_CASTLE);
    }
    if ((p->castle & C_WQ) && !p->board[SQ_B1] && !p->board[SQ_C1] && !p->board[SQ_D1] &&
        !square_attacked(p, SQ_E1, BLACK) && !square_attacked(p, SQ_D1, BLACK)) {
      add_move(l, SQ_E1, SQ_C1, FLAG_CASTLE | FLAG_LONG);
    }
  } else {
    if ((p->castle & C_BK) && !p->board[SQ_F8] && !p->board[SQ_G8] &&
        !square_attacked(p, SQ_E8, WHITE) && !square_attacked(p, SQ_F8, WHITE)) {
      add_move(l, SQ_E8, SQ_G8, FLAG_CASTLE);
    }
    if ((p->castle & C_BQ) && !p->board[SQ_B8] && !p->board[SQ_C8] && !p->board[SQ_D8] &&
        !square_attacked(p, SQ_E8, WHITE) && !square_attacked(p, SQ_D8, WHITE)) {
      add_move(l, SQ_E8, SQ_C8, FLAG_CASTLE | FLAG_LONG);
    }
  }
}

void generate_pseudo(const Position *p, MoveList *out) {
  out->n = 0;
  const uint8_t *b = p->board;
  const int side = p->side;
  for (int sq = 0; sq < BOARD_AREA; sq++) {
    uint8_t pc = b[sq];
    if (!pc || SIDE(pc) != side) continue;
    switch (TYPE(pc)) {
      case PAWN: generate_pawn(p, out, sq); break;
      case KNIGHT: generate_piece(p, out, sq, knightOff, 8, false); break;
      case BISHOP: generate_piece(p, out, sq, bishopDir, 4, true); break;
      case ROOK: generate_piece(p, out, sq, rookDir, 4, true); break;
      case QUEEN:
        generate_piece(p, out, sq, bishopDir, 4, true);
        generate_piece(p, out, sq, rookDir, 4, true);
        break;
      case KING: generate_piece(p, out, sq, kingOff, 8, false); break;
      default: break;
    }
  }
  /* Castling legality (king not in check, path not attacked) is checked here;
   * the "does not move through check" part is fully covered above, and the
   * "does not end in check" part is covered by the legality filter. */
  generate_casts(p, out);
}

/* ----------------------------------------------------------------- make    */
static void update_castle_rights(Position *p, int from, int to, uint8_t moved, uint8_t captured) {
  /* king moves */
  if (TYPE(moved) == KING) {
    if (SIDE(moved) == WHITE) p->castle &= (uint8_t)~(C_WK | C_WQ);
    else p->castle &= (uint8_t)~(C_BK | C_BQ);
  }
  /* rook moves off its original square */
  if (from == SQ_A1) p->castle &= (uint8_t)~C_WQ;
  if (from == SQ_H1) p->castle &= (uint8_t)~C_WK;
  if (from == SQ_A8) p->castle &= (uint8_t)~C_BQ;
  if (from == SQ_H8) p->castle &= (uint8_t)~C_BK;
  /* rook captured on its original square */
  if (captured) {
    if (to == SQ_A1) p->castle &= (uint8_t)~C_WQ;
    if (to == SQ_H1) p->castle &= (uint8_t)~C_WK;
    if (to == SQ_A8) p->castle &= (uint8_t)~C_BQ;
    if (to == SQ_H8) p->castle &= (uint8_t)~C_BK;
  }
}

void make_null(Position *p) {
  if (p->ep) {
    p->hash ^= zEp[SQ64(p->ep)];
    p->ep = 0;
  }
  p->side ^= 1;
  p->hash ^= zSide;
}

void make_move(Position *p, Move m, Undo *u) {
  const int from = m.from, to = m.to;
  const uint8_t moved = p->board[from];
  u->castle = p->castle;
  u->ep = p->ep;
  u->halfmove = p->halfmove;

  /* remove the old ep from the hash, and the old castle+side */
  if (p->ep) p->hash ^= zEp[SQ64(p->ep)];
  p->hash ^= zCastle[p->castle & 15];
  p->hash ^= zPiece[moved][SQ64(from)];

  uint8_t captured = 0;
  int capturedSq = to;
  if (m.flags & FLAG_EP) {
    capturedSq = (p->side == WHITE) ? to - 16 : to + 16;
    captured = p->board[capturedSq];
    p->board[capturedSq] = 0;
    p->hash ^= zPiece[captured][SQ64(capturedSq)];
  } else if (p->board[to]) {
    captured = p->board[to];
    p->hash ^= zPiece[captured][SQ64(to)];
  }
  u->captured = captured;
  u->capturedSq = (uint8_t)capturedSq;

  p->board[from] = 0;
  uint8_t placed = moved;
  if (m.flags & FLAG_PROMO) placed = MK(p->side, m.promo);
  p->board[to] = placed;
  p->hash ^= zPiece[placed][SQ64(to)];

  if (TYPE(moved) == KING) p->kingSq[p->side] = (uint8_t)to;

  /* castling rook */
  if (m.flags & FLAG_CASTLE) {
    if (m.flags & FLAG_LONG) {
      /* king e1->c1, rook a1->d1 ; e8->c8, a8->d8 */
      int rf = (p->side == WHITE) ? SQ_A1 : SQ_A8;
      int rt = (p->side == WHITE) ? SQ_D1 : SQ_D8;
      uint8_t rook = p->board[rf];
      p->board[rf] = 0;
      p->board[rt] = rook;
      p->hash ^= zPiece[rook][SQ64(rf)] ^ zPiece[rook][SQ64(rt)];
    } else {
      int rf = (p->side == WHITE) ? SQ_H1 : SQ_H8;
      int rt = (p->side == WHITE) ? SQ_F1 : SQ_F8;
      uint8_t rook = p->board[rf];
      p->board[rf] = 0;
      p->board[rt] = rook;
      p->hash ^= zPiece[rook][SQ64(rf)] ^ zPiece[rook][SQ64(rt)];
    }
  }

  update_castle_rights(p, from, to, moved, captured);
  p->hash ^= zCastle[p->castle & 15];

  /* en-passant target */
  p->ep = 0;
  if (TYPE(moved) == PAWN && ((from - to) == 32 || (to - from) == 32)) {
    p->ep = (uint8_t)((from + to) / 2);
    p->hash ^= zEp[SQ64(p->ep)];
  }

  /* clocks */
  if (TYPE(moved) == PAWN || captured) p->halfmove = 0;
  else p->halfmove++;
  if (p->side == BLACK) p->fullmove++;

  p->side ^= 1;
  p->hash ^= zSide;
}

void unmake_move(Position *p, Move m, const Undo *u) {
  const int from = m.from, to = m.to;
  p->side ^= 1;
  uint8_t placed = p->board[to];
  uint8_t moved = placed;
  if (m.flags & FLAG_PROMO) moved = MK(p->side, PAWN);
  p->board[from] = moved;
  p->board[to] = 0;
  if (TYPE(moved) == KING) p->kingSq[p->side] = (uint8_t)from;

  if (u->captured) p->board[u->capturedSq] = u->captured;

  if (m.flags & FLAG_CASTLE) {
    if (m.flags & FLAG_LONG) {
      int rf = (p->side == WHITE) ? SQ_A1 : SQ_A8;
      int rt = (p->side == WHITE) ? SQ_D1 : SQ_D8;
      p->board[rf] = p->board[rt];
      p->board[rt] = 0;
    } else {
      int rf = (p->side == WHITE) ? SQ_H1 : SQ_H8;
      int rt = (p->side == WHITE) ? SQ_F1 : SQ_F8;
      p->board[rf] = p->board[rt];
      p->board[rt] = 0;
    }
  }
  p->castle = u->castle;
  p->ep = u->ep;
  p->halfmove = u->halfmove;
  if (p->side == BLACK) p->fullmove--;
  p->hash = compute_hash(p); /* simple + always correct */
}

bool move_is_legal(Position *p, Move m) {
  const int us = p->side;
  const uint8_t moved = p->board[m.from];
  /* cannot castle out of check is already handled, but verify king safety
   * after the move for every move including castling and e.p. */
  Undo u;
  make_move(p, m, &u);
  bool ok = !square_attacked(p, p->kingSq[us], us ^ 1);
  unmake_move(p, m, &u);
  (void)moved;
  return ok;
}

void generate_legal(Position *p, MoveList *out) {
  MoveList pseudo;
  generate_pseudo(p, &pseudo);
  out->n = 0;
  const int us = p->side;
  for (int i = 0; i < pseudo.n; i++) {
    Move m = pseudo.m[i];
    Undo u;
    make_move(p, m, &u);
    bool ok = !square_attacked(p, p->kingSq[us], us ^ 1);
    unmake_move(p, m, &u);
    if (ok && out->n < 128) out->m[out->n++] = m;
  }
}

/* ------------------------------------------------------------- game level */
void game_new(Game *g) {
  chess_init();
  memset(g, 0, sizeof(*g));
  position_set_startpos(&g->pos);
  g->ply = 0;
  g->key[0] = g->pos.hash;
  g->sixteenStatus = STATUS_PLAYING;
}

bool game_make(Game *g, Move m) {
  MoveList legal;
  generate_legal(&g->pos, &legal);
  bool found = false;
  for (int i = 0; i < legal.n; i++) {
    if (legal.m[i].from == m.from && legal.m[i].to == m.to && legal.m[i].promo == m.promo) {
      m = legal.m[i];
      found = true;
      break;
    }
  }
  if (!found) return false;
  if (g->ply >= MAX_HISTORY - 1) return false;
  g->played[g->ply] = m;
  make_move(&g->pos, m, &g->hist[g->ply]);
  g->ply++;
  g->key[g->ply] = g->pos.hash;
  return true;
}

void game_undo(Game *g) {
  if (g->ply <= 0) return;
  g->ply--;
  unmake_move(&g->pos, g->played[g->ply], &g->hist[g->ply]);
  g->sixteenStatus = STATUS_PLAYING;
}

void game_undo_full(Game *g) {
  if (g->ply <= 0) return;
  game_undo(g);
  /* take back the opponent's reply as well, unless we are at the start */
  if (g->ply > 0) game_undo(g);
}

int repetition_count(const Game *g) {
  int count = 0;
  int limit = (int)g->pos.halfmove;
  for (int i = g->ply; i >= 0; i--) {
    if (g->key[i] == g->pos.hash) count++;
    if (g->ply - i >= limit) break;
  }
  return count;
}

bool insufficient_material(const Position *p) {
  int knights[2] = {0, 0}, bishops[2] = {0, 0}, others = 0;
  int bishopSqColor[2][2] = {{0, 0}, {0, 0}};
  for (int sq = 0; sq < BOARD_AREA; sq++) {
    uint8_t pc = p->board[sq];
    if (!pc) continue;
    int s = SIDE(pc);
    switch (TYPE(pc)) {
      case PAWN:
      case ROOK:
      case QUEEN: others++; break;
      case KNIGHT: knights[s]++; break;
      case BISHOP:
        bishops[s]++;
        bishopSqColor[s][(RANK_OF(sq) + FILE_OF(sq)) & 1]++;
        break;
      default: break;
    }
  }
  if (others) return false;
  int wm = knights[0] + bishops[0];
  int bm = knights[1] + bishops[1];
  if (wm == 0 && bm == 0) return true;            /* K vs K */
  if (wm <= 1 && bm == 0) return true;            /* K+minor vs K */
  if (bm <= 1 && wm == 0) return true;            /* K vs K+minor */
  if (wm == 0 && bm == 2 && knights[1] == 0 && bishops[1] == 2) {
    /* two bishops of the same colour cannot mate */
    if (bishopSqColor[1][0] == 2 || bishopSqColor[1][1] == 2) return true;
  }
  if (bm == 0 && wm == 2 && knights[0] == 0 && bishops[0] == 2) {
    if (bishopSqColor[0][0] == 2 || bishopSqColor[0][1] == 2) return true;
  }
  /* K+N vs K+N with more material is not an automatic draw; keep it simple */
  return false;
}

int game_status(const Game *g) {
  if (g->sixteenStatus != STATUS_PLAYING) return g->sixteenStatus;
  MoveList legal;
  Position *p = (Position *)&g->pos;
  generate_legal(p, &legal);
  if (legal.n == 0) return in_check(p) ? STATUS_CHECKMATE : STATUS_STALEMATE;
  if (g->pos.halfmove >= 100) return STATUS_FIFTY;
  if (repetition_count(g) >= 3) return STATUS_REPETITION;
  if (insufficient_material(p)) return STATUS_MATERIAL;
  return STATUS_PLAYING;
}

/* ------------------------------------------------------------------- SAN  */
static const char *sanPiece = " PNBRQK";

bool move_to_san(Position *p, Move m, char *san, int sanSize) {
  MoveList legal;
  generate_legal(p, &legal);
  bool found = false;
  for (int i = 0; i < legal.n; i++) {
    if (legal.m[i].from == m.from && legal.m[i].to == m.to && legal.m[i].promo == m.promo) {
      m = legal.m[i];
      found = true;
      break;
    }
  }
  if (!found) {
    if (sanSize > 1) {
      san[0] = '?';
      san[1] = 0;
    }
    return false;
  }
  const uint8_t moved = p->board[m.from];
  const int ty = TYPE(moved);
  int n = 0;
  const bool isCapture = (m.flags & FLAG_CAPTURE) != 0;

  if (m.flags & FLAG_CASTLE) {
    const char *s = (m.flags & FLAG_LONG) ? "O-O-O" : "O-O";
    while (*s && n < sanSize - 1) san[n++] = *s++;
  } else if (ty == PAWN) {
    if (isCapture) {
      san[n++] = (char)('a' + FILE_OF(m.from));
      san[n++] = 'x';
    }
    san[n++] = (char)('a' + FILE_OF(m.to));
    san[n++] = (char)('1' + RANK_OF(m.to));
    if (m.flags & FLAG_PROMO) {
      san[n++] = '=';
      san[n++] = sanPiece[m.promo];
    }
  } else {
    san[n++] = sanPiece[ty];
    /* disambiguation */
    int sameFile = 0, sameRank = 0, ambiguous = 0;
    for (int i = 0; i < legal.n; i++) {
      const Move *o = &legal.m[i];
      if (o->to != m.to || o->from == m.from) continue;
      if (TYPE(p->board[o->from]) != ty) continue;
      ambiguous++;
      if (FILE_OF(o->from) == FILE_OF(m.from)) sameFile++;
      if (RANK_OF(o->from) == RANK_OF(m.from)) sameRank++;
    }
    if (ambiguous) {
      if (!sameFile) san[n++] = (char)('a' + FILE_OF(m.from));
      else if (!sameRank) san[n++] = (char)('1' + RANK_OF(m.from));
      else {
        san[n++] = (char)('a' + FILE_OF(m.from));
        san[n++] = (char)('1' + RANK_OF(m.from));
      }
    }
    if (isCapture) san[n++] = 'x';
    san[n++] = (char)('a' + FILE_OF(m.to));
    san[n++] = (char)('1' + RANK_OF(m.to));
  }

  /* check / mate suffix */
  Undo u;
  make_move(p, m, &u);
  MoveList reply;
  generate_legal(p, &reply);
  bool givesCheck = in_check(p);
  unmake_move(p, m, &u);
  if (givesCheck) san[n++] = (reply.n == 0) ? '#' : '+';

  if (n > sanSize - 1) n = sanSize - 1;
  san[n] = 0;
  return true;
}

/* ----------------------------------------------------------------- perft  */
uint64_t perft(Position *p, int depth) {
  if (depth == 0) return 1;
  MoveList list;
  generate_legal(p, &list);
  if (depth == 1) return (uint64_t)list.n;
  uint64_t nodes = 0;
  for (int i = 0; i < list.n; i++) {
    Undo u;
    make_move(p, list.m[i], &u);
    nodes += perft(p, depth - 1);
    unmake_move(p, list.m[i], &u);
  }
  return nodes;
}
