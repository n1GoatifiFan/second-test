/* search_platform.h - the one thing the search needs from the platform. */
#ifndef SEARCH_PLATFORM_H
#define SEARCH_PLATFORM_H
#include <stdint.h>
uint32_t search_platform_millis(void);
#endif
