/* eval.h - material + piece-square-table evaluation, no floats.
 * MIT licensed.
 */
#ifndef EVAL_H
#define EVAL_H

#include <stdint.h>
#include "chess.h"

/* Centipawn values, tuned for a small program: material weight dominates,
 * PSTs are the classic "simplified evaluation function" shapes from the
 * public domain chess-programming literature. */
#define VAL_PAWN 100
#define VAL_KNIGHT 320
#define VAL_BISHOP 330
#define VAL_ROOK 500
#define VAL_QUEEN 900
#define VAL_KING 20000
#define INFINITE 30000
#define MATE 20000        /* mate score, |mate| >= MATE - MAX_PLY */

/* Score from the point of view of the side to move. */
int eval_position(const Position *p);

/* Material-only score (used by "captured pieces" display and by tests). */
int eval_material(const Position *p);

#endif
