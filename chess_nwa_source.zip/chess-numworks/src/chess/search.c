/* search.c - iterative deepening alpha-beta, quiescence, move ordering.
 *
 * Design notes (small CPU / little RAM friendly):
 *  - no floats anywhere, all scores are integers in centipawns
 *  - no dynamic allocation: the transposition table is a fixed static array,
 *    the search stack lives in one static array
 *  - search depth is capped at MAX_PLY = 64 so the worst case stack usage is
 *    bounded and measurable (see BUILD_REPORT.md)
 *  - the game move list is passed in so the engine can detect repetitions
 *    and avoid drawing when it is ahead / seek a draw when it is behind
 *
 * MIT licensed. Original code.
 */
#include "search.h"
#include "eval.h"
#include "search_platform.h"

#include <string.h>

/* Stack budget. The N0120 userland stack is 32 KiB (Epsilon
 * shared/ion/src/device/include/n0120/config/board.h: UserlandStackLength =
 * 0x8000) and the app shares it with the UI. Measured with
 * arm-none-eabi-gcc -fstack-usage: one search frame was 1104-1152 bytes with
 * 128-entry move/score arrays. With the sizes below a frame is ~500 bytes, so
 * the worst case is roughly 12 KB (see BUILD_REPORT.md):
 *    root_search  1 frame
 *    alphabeta    at most MAX_PLY-2 frames
 *    qsearch      at most QS_EXTRA frames
 * The move lists inside the search are smaller than the 218 legal-move
 * maximum. A position with more than MAX_MOVES moves is astronomically rare,
 * and truncating an interior node only costs accuracy, never legality: the
 * root and the game layer always use full 128-entry lists. */
#define MAX_PLY 24
#define QS_EXTRA 10
#define MAX_MOVES 80
#define PATH_CAP (MAX_PLY + 64 + 8)
#define INF INFINITE

/* ------------------------------------------------------------------- TT   */
typedef struct {
  uint32_t key;   /* upper 32 bits of the zobrist key */
  int16_t score;
  uint8_t depth;
  uint8_t flag;   /* 1 = exact, 2 = lower bound, 3 = upper bound */
  uint16_t move;  /* packed from | to | promo */
} TTEntry;

static TTEntry gTT[TT_BUCKETS];
static int gTTBuckets = TT_BUCKETS;

static inline uint16_t pack_move(Move m) {
  return (uint16_t)((m.from & 0x7F) | ((m.to & 0x7F) << 7) |
                    ((m.promo ? (m.promo << 3) : 0) << 14));
}

static inline Move unpack_move(uint16_t v) {
  Move m;
  m.from = (uint8_t)(v & 0x7F);
  m.to = (uint8_t)((v >> 7) & 0x7F);
  m.promo = (uint8_t)((v >> 14) >> 3);
  m.flags = 0;
  return m;
}

void search_init(void) { memset(gTT, 0, sizeof(gTT)); }

void search_set_hash_size(int buckets) {
  if (buckets < 16) buckets = 16;
  if (buckets > TT_BUCKETS) buckets = TT_BUCKETS;
  gTTBuckets = buckets;
}

/* --------------------------------------------------------------- context  */
typedef struct {
  const Game *game;   /* may be NULL */
  Position *pos;
  SearchLimits lim;
  uint32_t nodes;
  uint32_t start;
  bool aborted;
  Move killers[MAX_PLY + 2][2];
  int history[2][BOARD_AREA]; /* from-square history table */
  /* path of hashes for repetition detection inside the search */
  uint64_t pathKeys[PATH_CAP];
  int pathLen;
  int rootDepth;
} Ctx;

static Ctx gCtx;

static inline bool timeUp(Ctx *c) {
  if (c->aborted) return true;
  if ((c->nodes & 2047u) == 0) {
    if (c->lim.tick && c->lim.tick()) {
      c->aborted = true;
      return true;
    }
    if (c->lim.maxMillis) {
      uint32_t el = search_platform_millis() - c->start;
      if (el >= c->lim.maxMillis) {
        c->aborted = true;
        return true;
      }
    }
  }
  return false;
}

/* Twofold repetition inside the search: treat as a draw. */
static bool is_repetition(Ctx *c) {
  uint64_t h = c->pos->hash;
  int limit = c->pos->halfmove;
  if (limit > c->pathLen) limit = c->pathLen;
  /* pathKeys[pathLen-1] is the current position itself: start at i=1 behind it */
  for (int i = 2; i <= limit + 1 && i <= c->pathLen; i++) {
    if (c->pathKeys[c->pathLen - i] == h) return true;
  }
  return false;
}

int pieceVal(int type) {
  static const int v[7] = {0, 100, 320, 330, 500, 900, 20000};
  return (type >= 0 && type < 7) ? v[type] : 0;
}

/* ------------------------------------------------------------- ordering   */
static void score_moves(Ctx *c, const MoveList *l, int16_t *scores, Move ttMove, int ply) {
  for (int i = 0; i < l->n; i++) {
    const Move *m = &l->m[i];
    int s = 0;
    if (ttMove.from == m->from && ttMove.to == m->to && ttMove.promo == m->promo) {
      s = 1 << 28;
    } else if (m->flags & FLAG_PROMO) {
      s = (1 << 24) + m->promo;
    } else if (m->flags & FLAG_CAPTURE) {
      uint8_t victim = c->pos->board[m->to];
      if (m->flags & FLAG_EP) victim = MK(c->pos->side ^ 1, PAWN);
      uint8_t attacker = c->pos->board[m->from];
      int vv = TYPE(victim) == 0 ? 1 : pieceVal(TYPE(victim));
      int av = pieceVal(TYPE(attacker));
      s = (1 << 20) + vv * 32 - av; /* MVV-LVA */
    } else if (ply < MAX_PLY &&
               ((c->killers[ply][0].from == m->from && c->killers[ply][0].to == m->to) ||
                (c->killers[ply][1].from == m->from && c->killers[ply][1].to == m->to))) {
      s = (1 << 18);
    } else {
      s = c->history[m->from & 1][m->from];
      if (s > 16000) s = 16000;
    }
    scores[i] = (int16_t)s;
  }
}

static void pick_next(MoveList *l, int16_t *scores, int i) {
  int best = i;
  for (int j = i + 1; j < l->n; j++)
    if (scores[j] > scores[best]) best = j;
  if (best != i) {
    Move tm = l->m[i];
    l->m[i] = l->m[best];
    l->m[best] = tm;
    int16_t ts = scores[i];
    scores[i] = scores[best];
    scores[best] = ts;
  }
}

/* ------------------------------------------------------------ quiescence  */
static int qsearch(Ctx *c, int alpha, int beta, int ply) {
  if (timeUp(c)) return 0;
  c->nodes++;
  int stand = search_eval(c->pos);
  if (stand >= beta) return stand;
  if (stand > alpha) alpha = stand;
  if (ply >= MAX_PLY + QS_EXTRA) return alpha;

  MoveList l;
  generate_pseudo(c->pos, &l);
  if (l.n > MAX_MOVES) l.n = MAX_MOVES;
  int16_t scores[MAX_MOVES];
  score_moves(c, &l, scores, (Move){0, 0, 0, 0}, ply);
  const int us = c->pos->side;
  int tried = 0;
  for (int i = 0; i < l.n; i++) {
    pick_next(&l, scores, i);
    Move m = l.m[i];
    if (!(m.flags & FLAG_CAPTURE) && !(m.flags & FLAG_PROMO)) continue;
    /* futility-ish pruning: skip obviously losing captures low down */
    if (m.flags & FLAG_CAPTURE) {
      uint8_t victim = c->pos->board[m.to];
      if (m.flags & FLAG_EP) victim = MK(us ^ 1, PAWN);
      int gain = pieceVal(TYPE(victim)) - pieceVal(TYPE(c->pos->board[m.from]));
      if (stand + gain + 200 < alpha && !(m.flags & FLAG_PROMO)) continue;
    }
    Undo u;
    make_move(c->pos, m, &u);
    if (square_attacked(c->pos, c->pos->kingSq[us], us ^ 1)) {
      unmake_move(c->pos, m, &u);
      continue;
    }
    tried++;
    int score = -qsearch(c, -beta, -alpha, ply + 1);
    unmake_move(c->pos, m, &u);
    if (c->aborted) return alpha;
    if (score >= beta) return score;
    if (score > alpha) alpha = score;
    if (tried > 24) break; /* bounded effort per node */
  }
  return alpha;
}

/* ---------------------------------------------------------------- search  */
static int alphabeta(Ctx *c, int alpha, int beta, int depth, int ply, bool canNull) {
  if (timeUp(c)) return 0;

  if (ply > 0) {
    /* draw detection */
    if (is_repetition(c)) return 0;
    if (c->pos->halfmove >= 100) return 0;
    if (insufficient_material(c->pos)) return 0;

    /* mate distance pruning */
    int mateLo = -MATE + ply, mateHi = MATE - ply - 1;
    if (alpha < mateLo) alpha = mateLo;
    if (beta > mateHi) beta = mateHi;
    if (alpha >= beta) return alpha;
  }

  const bool isPv = (beta - alpha) > 1;
  const bool checked = in_check(c->pos);

  if (depth <= 0) return qsearch(c, alpha, beta, ply);
  if (ply >= MAX_PLY - 2) return search_eval(c->pos);

  /* --- transposition table probe ------------------------------------- */
  uint32_t key32 = (uint32_t)(c->pos->hash >> 32);
  TTEntry *tt = &gTT[(uint32_t)(c->pos->hash % (uint64_t)gTTBuckets)];
  Move ttMove = {0, 0, 0, 0};
  if (tt->key == key32) {
    ttMove = unpack_move(tt->move);
    if (ply > 0 && tt->depth >= depth && !isPv) {
      int sc = tt->score;
      if (sc > MATE - MAX_PLY) sc -= ply;
      else if (sc < -MATE + MAX_PLY) sc += ply;
      if (tt->flag == 1) return sc;
      if (tt->flag == 2 && sc >= beta) return sc;
      if (tt->flag == 3 && sc <= alpha) return sc;
    }
  }

  /* --- null move pruning --------------------------------------------- */
  if (canNull && !isPv && !checked && depth >= 3 && ply > 0 && c->pos->halfmove < 90) {
    int staticEval = search_eval(c->pos);
    /* non-pawn material check: don't try null move in pawn endgames */
    bool hasPieces = false;
    for (int sq = 0; sq < BOARD_AREA; sq++) {
      uint8_t pc = c->pos->board[sq];
      if (pc && SIDE(pc) == c->pos->side && TYPE(pc) != PAWN && TYPE(pc) != KING) {
        hasPieces = true;
        break;
      }
    }
    if (hasPieces && staticEval >= beta) {
      uint8_t savedEp = c->pos->ep, savedSide = c->pos->side;
      uint64_t savedHash = c->pos->hash;
      make_null(c->pos); /* keeps the Zobrist key consistent */
      if (c->pathLen < PATH_CAP) {
        c->pathLen++;
        c->pathKeys[c->pathLen - 1] = c->pos->hash;
      }
      int R = 2 + (depth > 6 ? 1 : 0);
      int score = -alphabeta(c, -beta, -beta + 1, depth - 1 - R, ply + 1, false);
      if (c->pathLen > 0) c->pathLen--;
      c->pos->side = savedSide;
      c->pos->ep = savedEp;
      c->pos->hash = savedHash;
      if (c->aborted) return alpha;
      if (score >= beta) {
        if (score > MATE - MAX_PLY) score = beta; /* avoid returning bogus mate */
        return score;
      }
    }
  }

  MoveList l;
  generate_pseudo(c->pos, &l);
  if (l.n > MAX_MOVES) l.n = MAX_MOVES;
  int16_t scores[MAX_MOVES];
  score_moves(c, &l, scores, ttMove, ply > 0 ? ply : 0);

  const int us = c->pos->side;
  const int oldAlpha = alpha;
  Move bestMove = {0, 0, 0, 0};
  int best = -INF;
  int legal = 0;

  for (int i = 0; i < l.n; i++) {
    pick_next(&l, scores, i);
    Move m = l.m[i];
    Undo u;
    make_move(c->pos, m, &u);
    if (square_attacked(c->pos, c->pos->kingSq[us], us ^ 1)) {
      unmake_move(c->pos, m, &u);
      continue;
    }
    legal++;
    if (c->pathLen < PATH_CAP) {
      c->pathLen++;
      c->pathKeys[c->pathLen - 1] = c->pos->hash;
    }

    int score;
    bool givesCheck = in_check(c->pos);
    if (legal == 1) {
      score = -alphabeta(c, -beta, -alpha, depth - 1, ply + 1, true);
    } else {
      /* late move reduction: quiet moves late in the list get a shallower
       * search first, and are re-searched only when they beat alpha */
      int red = 0;
      if (depth >= 3 && legal > 3 && !isPv && !(m.flags & FLAG_CAPTURE) &&
          !(m.flags & FLAG_PROMO) && !givesCheck && !checked) {
        red = (legal > 8) ? 2 : 1;
        if (red >= depth) red = depth - 1;
      }
      score = -alphabeta(c, -alpha - 1, -alpha, depth - 1 - red, ply + 1, true);
      if (score > alpha && red) {
        score = -alphabeta(c, -alpha - 1, -alpha, depth - 1, ply + 1, true);
      }
      if (score > alpha && score < beta) {
        score = -alphabeta(c, -beta, -alpha, depth - 1, ply + 1, true);
      }
    }
    if (c->pathLen > 0) c->pathLen--;
    unmake_move(c->pos, m, &u);
    if (c->aborted) return best > -INF ? best : alpha;

    if (score > best) {
      best = score;
      bestMove = m;
    }
    if (score > alpha) {
      alpha = score;
      if (score >= beta) {
        /* killer + history */
        if (!(m.flags & FLAG_CAPTURE) && ply < MAX_PLY) {
          if (c->killers[ply][0].from != m.from || c->killers[ply][0].to != m.to) {
            c->killers[ply][1] = c->killers[ply][0];
            c->killers[ply][0] = m;
          }
          c->history[us][m.from] += depth * depth;
          if (c->history[us][m.from] > 1 << 20) {
            for (int s = 0; s < BOARD_AREA; s++) c->history[us][s] >>= 1;
          }
        }
        break;
      }
    }
  }

  if (legal == 0) {
    /* no legal move: mate or stalemate */
    return checked ? (-MATE + ply) : 0;
  }

  /* store in the TT */
  if (!c->aborted) {
    int storeScore = best;
    if (storeScore > MATE - MAX_PLY) storeScore += ply;
    else if (storeScore < -MATE + MAX_PLY) storeScore -= ply;
    uint8_t flag = 1;
    if (best <= oldAlpha) flag = 3;
    else if (best >= beta) flag = 2;
    if (tt->key != key32 || depth >= tt->depth) {
      tt->key = key32;
      tt->score = (int16_t)storeScore;
      tt->depth = (uint8_t)(depth > 255 ? 255 : depth);
      tt->flag = flag;
      tt->move = pack_move(bestMove);
    }
  }
  return best;
}

/* ----------------------------------------------------------------- root   */
static void prep_ctx(Ctx *c, const Game *g) {
  memset(c, 0, sizeof(*c));
  c->game = g;
  c->pos = (Position *)&g->pos;
  c->start = search_platform_millis();
  c->nodes = 0;
  c->aborted = false;
  /* seed the repetition path with the game history (bounded) */
  int from = g->ply - 40;
  if (from < 0) from = 0;
  for (int i = from; i <= g->ply && c->pathLen < PATH_CAP - MAX_PLY - 2; i++) {
    c->pathKeys[c->pathLen++] = g->key[i];
  }
}

static SearchResult root_search(Ctx *c) {
  SearchResult res;
  memset(&res, 0, sizeof(res));
  res.score = 0;
  c->pathLen = 0;
  c->nodes = 0;
  c->aborted = false;
  c->start = search_platform_millis();

  MoveList legal;
  generate_legal(c->pos, &legal);
  if (legal.n == 0) return res;
  res.best = legal.m[0];

  int maxDepth = c->lim.maxDepth;
  if (maxDepth < 1) maxDepth = 1;
  if (maxDepth > MAX_PLY - 4) maxDepth = MAX_PLY - 4;

  int alpha = -INF, beta = INF;
  for (int depth = 1; depth <= maxDepth; depth++) {
    c->rootDepth = depth;
    MoveList l;
    generate_legal(c->pos, &l);
    int16_t scores[MAX_MOVES];
    score_moves(c, &l, scores, res.best, 0);
    const int us = c->pos->side;
    int best = -INF;
    Move bestMove = res.best;
    for (int i = 0; i < l.n; i++) {
      pick_next(&l, scores, i);
      Move m = l.m[i];
      Undo u;
      make_move(c->pos, m, &u);
      c->pathLen = 0;
      /* rebuild the repetition path for the root position */
      {
        int from = c->game->ply - 40;
        if (from < 0) from = 0;
        for (int k = from; k <= c->game->ply && c->pathLen < PATH_CAP - MAX_PLY - 2; k++)
          c->pathKeys[c->pathLen++] = c->game->key[k];
      }
      if (c->pathLen < PATH_CAP) {
        c->pathLen++;
        c->pathKeys[c->pathLen - 1] = c->pos->hash;
      }
      int score;
      if (i == 0) {
        score = -alphabeta(c, -beta, -alpha, depth - 1, 1, true);
      } else {
        score = -alphabeta(c, -alpha - 1, -alpha, depth - 1, 1, true);
        if (score > alpha) score = -alphabeta(c, -beta, -alpha, depth - 1, 1, true);
      }
      if (c->pathLen > 0) c->pathLen--;
      unmake_move(c->pos, m, &u);
      (void)us;
      if (c->aborted) break;
      if (score > best) {
        best = score;
        bestMove = m;
        if (score > alpha) alpha = score;
      }
    }
    if (!c->aborted) {
      res.best = bestMove;
      res.score = best;
      res.depth = depth;
      /* a forced mate was found: no point searching deeper */
      if (best > MATE - MAX_PLY || best < -MATE + MAX_PLY) break;
      /* stop if we have used most of the allotted time */
      if (c->lim.maxMillis && search_platform_millis() - c->start > c->lim.maxMillis * 3 / 4) break;
    } else {
      /* keep the result of the last completed depth */
      break;
    }
  }
  res.nodes = c->nodes;
  res.millis = search_platform_millis() - c->start;
  if (res.score > MATE - MAX_PLY) {
    res.mate = true;
    res.mateInPlies = MATE - res.score;
  } else if (res.score < -MATE + MAX_PLY) {
    res.mate = true;
    res.mateInPlies = -(MATE + res.score);
  }
  return res;
}

SearchResult search_think(const Game *g, const SearchLimits *lim) {
  prep_ctx(&gCtx, g);
  gCtx.lim = *lim;
  return root_search(&gCtx);
}

SearchResult search_think_position(Position *p, const SearchLimits *lim) {
  /* wrap the position in a game record with a single entry */
  static Game g;
  memset(&g, 0, sizeof(g));
  g.pos = *p;
  g.ply = 0;
  g.key[0] = p->hash;
  return search_think(&g, lim);
}

int search_eval(const Position *p) { return eval_position(p); }
