/* platform_nwa.c - NumWorks N0120 platform layer (EADK / .nwa external app).
 *
 * API facts, verified in the Epsilon sources (github.com/numworks/epsilon,
 * epsilon/eadk/src/simulator.cpp and epsilon/eadk/include/eadk/eadk.h):
 *   - input must be read with eadk_event_get(&timeout): it returns key events
 *     with the kernel's repeat handling. eadk_keyboard_scan() returns the raw
 *     physical key state, which the simulator's event replay never touches.
 *   - Home TERMINATES an external app (preemptive_termination() exits when it
 *     sees Ion::Events::Home). Home is therefore not usable as the menu key;
 *     the menu is on EXE.
 *   - display: eadk_display_push_rect(rect, rgb565) and wait_for_vblank()
 *   - timing: eadk_timing_millis() / eadk_timing_msleep()
 *   - there is no file/flash storage API for external apps -> save/load is
 *     reported unavailable (platform_storage_available() == false).
 *
 * MIT licensed.
 */
#include <eadk.h>

#include "platform.h"
#include "../chess/search_platform.h"

static Canvas s_screen;
static eadk_color_t s_pixels[SCREEN_W * SCREEN_H];


Canvas *platform_screen(void) {
  s_screen.px = (color_t *)s_pixels;
  s_screen.w = SCREEN_W;
  s_screen.h = SCREEN_H;
  return &s_screen;
}

/* Push the whole frame. RAM is the scarce resource on this target (the app
 * gets a bounded window inside Epsilon's userland RAM), so no second
 * framebuffer is kept; the panel is small enough that a full 153 600-byte
 * push is fast (measured, see BUILD_REPORT.md). */
void platform_present(void) { eadk_display_push_rect(eadk_screen_rect, s_pixels); }
void platform_present_full(void) { platform_present(); }

uint32_t platform_millis(void) { return (uint32_t)eadk_timing_millis(); }
uint32_t search_platform_millis(void) { return (uint32_t)eadk_timing_millis(); }
void platform_delay_ms(uint32_t ms) { eadk_timing_msleep(ms); }

/* eadk_event_t -> logical key. */
static Key map_event(eadk_event_t e) {
  switch (e) {
    case eadk_event_left: return KEY_LEFT;
    case eadk_event_right: return KEY_RIGHT;
    case eadk_event_up: return KEY_UP;
    case eadk_event_down: return KEY_DOWN;
    case eadk_event_ok: return KEY_OK;
    case eadk_event_back: return KEY_BACK;
    case eadk_event_exe: return KEY_MENU;
    default: return KEY_NONE;
  }
}

Key platform_poll_key(void) {
  int32_t timeout = 0; /* do not block */
  return map_event(eadk_event_get(&timeout));
}

Key platform_wait_key(uint32_t timeoutMs) {
  /* eadk_event_get blocks up to `timeout` ms and returns 0 on timeout */
  int32_t timeout = (int32_t)timeoutMs;
  for (;;) {
    Key k = map_event(eadk_event_get(&timeout));
    if (k != KEY_NONE) return k;
    if (timeoutMs && timeout <= 0) return KEY_NONE;
    if (timeoutMs == 0 && timeout <= 0) return KEY_NONE; /* timeout==0 means 0 ms */
  }
}

/* The EADK exposes no persistent storage to external apps. */
bool platform_storage_available(void) { return false; }
bool platform_storage_read(void *dst, int len) {
  (void)dst;
  (void)len;
  return false;
}
bool platform_storage_write(const void *src, int len) {
  (void)src;
  (void)len;
  return false;
}

void platform_debug_flush(void) {}
bool platform_should_quit(void) { return false; }
