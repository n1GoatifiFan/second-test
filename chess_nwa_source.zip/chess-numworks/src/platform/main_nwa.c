/* main_nwa.c - entry point of the .nwa external app.
 *
 * The EADK expects:
 *   const char eadk_app_name[]      in .rodata.eadk_app_name
 *   const uint32_t eadk_api_level   in .rodata.eadk_api_level
 *   const uint32_t eadk_app_icon[]  (provided by icon.o, built from the PNG)
 *   int main()
 *
 * The whole game loop lives in main(): returning from main ends the app, so
 * "Menu -> Exit -> OK" returns.
 *
 * MIT licensed.
 */
#include <eadk.h>

#include "app/game.h"
#include "app/ui.h"
#include "platform.h"

const char eadk_app_name[] __attribute__((section(".rodata.eadk_app_name"))) = "Chess";
const uint32_t eadk_api_level __attribute__((section(".rodata.eadk_api_level"))) = 0;

static ChessApp s_app; /* ~60 KB: one instance, in .bss */

static void present(void) {
  ui_render(platform_screen(), &s_app);
  platform_present();
}

/* Show the "thinking" screen while the search runs. The search is started
 * with the level's time budget; because the search polls a callback every
 * 2048 nodes, BACK can abort it without any threading. */
static void run_engine_turn(void) {
  uint32_t t0 = platform_millis();
  ui_render(platform_screen(), &s_app); /* draws the "Thinking" header */
  platform_present();
  /* The search itself handles the time budget; we only need to let the user
   * abort. We therefore run it and let it finish, redrawing afterwards. A
   * BACK press that arrives during the search is picked up by the next
   * platform_wait_key() and cancels nothing else. */
  app_engine_think(&s_app);
  uint32_t dt = platform_millis() - t0;
  (void)dt;
  present();
}

int main(int argc, char *argv[]) {
  (void)argc;
  (void)argv;

  app_init(&s_app);
  present();

  for (;;) {
    if (app_engine_to_move(&s_app) && s_app.screen == SCREEN_PLAY) {
      run_engine_turn();
      continue;
    }
    Key k = platform_wait_key(500);
    if (k == KEY_NONE) continue;
    if (k == KEY_QUIT) break;
    if (s_app.screen == SCREEN_CONFIRM_EXIT && k == KEY_OK) return 0;
    if (app_handle_key(&s_app, k)) present();
  }
  return 0;
}
