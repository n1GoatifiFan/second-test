/* platform_native.c - host implementation of the platform layer.
 *
 * Used by the native UI harness (tests/ui_main.c): renders frames to PNG/PPM
 * files and takes key input from a script, so the exact same UI code that
 * runs on the calculator can be inspected and regression-tested on a PC.
 */
#define _POSIX_C_SOURCE 200809L
#include "platform.h"
#include "../chess/search_platform.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define FB_W SCREEN_W
#define FB_H SCREEN_H

static Canvas s_screen;
static color_t s_pixels[FB_W * FB_H];
static int s_initialised;

static uint32_t s_start;
static uint32_t now_ms(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (uint32_t)(t.tv_sec * 1000ull + t.tv_nsec / 1000000ull);
}

Canvas *platform_screen(void) {
  if (!s_initialised) {
    s_screen.px = s_pixels;
    s_screen.w = FB_W;
    s_screen.h = FB_H;
    s_start = now_ms();
    s_initialised = 1;
  }
  return &s_screen;
}

void platform_present(void) {}
void platform_present_full(void) {}

uint32_t platform_millis(void) { return now_ms() - s_start; }
uint32_t search_platform_millis(void) { return now_ms() - s_start; }
void platform_delay_ms(uint32_t ms) { (void)ms; }

/* ---- scripted input ----------------------------------------------------- */
#define MAX_SCRIPT 512
static int s_script[MAX_SCRIPT];
static int s_scriptLen, s_scriptPos;
static bool s_quit;

void native_set_script(const int *keys, int n) {
  if (n > MAX_SCRIPT) n = MAX_SCRIPT;
  memcpy(s_script, keys, sizeof(int) * (size_t)n);
  s_scriptLen = n;
  s_scriptPos = 0;
  s_quit = false;
}

Key platform_poll_key(void) {
  if (s_scriptPos >= s_scriptLen) {
    s_quit = true;
    return KEY_NONE;
  }
  return (Key)s_script[s_scriptPos++];
}

Key platform_wait_key(uint32_t timeoutMs) {
  (void)timeoutMs;
  return platform_poll_key();
}

bool platform_should_quit(void) { return s_quit; }

/* ---- storage: a file next to the harness, so save/load can be tested ---- */
#define NATIVE_SAVE "build/native_save.bin"
bool platform_storage_available(void) { return true; }
bool platform_storage_read(void *dst, int len) {
  FILE *f = fopen(NATIVE_SAVE, "rb");
  if (!f) return false;
  size_t n = fread(dst, 1, (size_t)len, f);
  fclose(f);
  return (int)n == len;
}
bool platform_storage_write(const void *src, int len) {
  FILE *f = fopen(NATIVE_SAVE, "wb");
  if (!f) return false;
  size_t n = fwrite(src, 1, (size_t)len, f);
  fclose(f);
  return (int)n == len;
}

void platform_debug_flush(void) { fflush(stdout); }
