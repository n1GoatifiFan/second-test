/* native_platform.c - host implementation of the platform hooks used by the
 * native (PC) build. The calculator equivalents live in nwa_platform.c
 * (millis) and are wired in the .nwa Makefile.
 */
#define _POSIX_C_SOURCE 200809L
#include <time.h>
#include <stdint.h>
#include "../chess/search_platform.h"

uint32_t search_platform_millis(void) {
  static struct timespec t0;
  static int init = 0;
  struct timespec t;
  if (!init) {
    clock_gettime(CLOCK_MONOTONIC, &t0);
    init = 1;
  }
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (uint32_t)((t.tv_sec - t0.tv_sec) * 1000 + (t.tv_nsec - t0.tv_nsec) / 1000000);
}
