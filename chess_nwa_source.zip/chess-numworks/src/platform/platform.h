/* platform.h - the narrow interface the chess app needs from its host.
 *
 * Two implementations exist:
 *   src/platform/platform_nwa.c   NumWorks N0120, via the EADK (eadk.h)
 *   src/platform/platform_native.c host PC, for rendering/UI tests
 *
 * Keeping this to one small header is what lets the exact same UI code be
 * exercised on a PC and on the calculator.
 */
#ifndef PLATFORM_H
#define PLATFORM_H

#include <stdint.h>
#include <stdbool.h>

#include "app/gfx.h"

#define SCREEN_W 320
#define SCREEN_H 240

/* ---- keys (logical, mapped per platform) -------------------------------- */
typedef enum {
  KEY_NONE = 0,
  KEY_LEFT,
  KEY_RIGHT,
  KEY_UP,
  KEY_DOWN,
  KEY_OK,     /* OK / EXE: select, confirm, toggle */
  KEY_BACK,   /* Back: cancel, undo selection, leave menu */
  KEY_HOME,   /* Home: opens the in-game menu                */
  KEY_MENU,   /* convenience alias used by the UI            */
  KEY_CANCEL, /* Escape/Backspace: same as BACK              */
  KEY_QUIT    /* native only: close the harness              */
} Key;

/* Keys that produce edge-triggered events (repeat enabled for arrows). */
Key platform_poll_key(void);

/* Blocking wait for a key, with a timeout in ms (0 = wait forever).
 * Returns KEY_NONE on timeout. */
Key platform_wait_key(uint32_t timeoutMs);

uint32_t platform_millis(void);
void platform_delay_ms(uint32_t ms);

/* Canvas whose pixel buffer is the screen. */
Canvas *platform_screen(void);
/* Send the canvas to the display. On the calculator this pushes only the
 * rows that changed when `full` is false (dirty-rectangle optimisation). */
void platform_present(void);
void platform_present_full(void);

/* Optional persistence. Returns false when unavailable. */
bool platform_storage_available(void);
bool platform_storage_read(void *dst, int len);
bool platform_storage_write(const void *src, int len);

/* Optional host hooks (native build only; no-ops on the calculator). */
void platform_debug_flush(void);
bool platform_should_quit(void);

#endif
